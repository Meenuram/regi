import { Component, OnInit, ViewEncapsulation, ElementRef, NgZone,ViewChild, ANALYZE_FOR_ENTRY_COMPONENTS } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray,FormControl, } from '@angular/forms';
import { FileInput } from 'ngx-material-file-input';
import * as _ from 'underscore';
import { UserService } from 'app/shared/services/user.service';
import { UtilityService } from 'app/shared/services/utility.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { EMPTY } from 'rxjs';
import { tap, distinctUntilChanged, switchMap, startWith } from 'rxjs/operators';
import { sample } from 'lodash';
import { MapsAPILoader,MouseEvent } from '@agm/core';
import { OnboardmobilemodalComponent } from '../onboardmobilemodal/onboardmobilemodal.component';
import { OnboardemailmodalComponent } from '../onboardemailmodal/onboardemailmodal.component';
import { DatePipe } from '@angular/common';
// import { google } from '@agm/core/services/google-maps-types';
declare var google: any;

interface Address {
    current_addressLine1: string;
    current_addressLine2: string;
    current_city: string;
    current_pincode: string;
    current_state: string;
    current_country: string;
    permanent_addressLine1: string;
    permanent_addressLine2: string;
    permanent_city: string;
    permanent_pincode: string;
    permanent_state: string;
    permanent_country: string;
  }

@Component({
    selector     : 'employee-onboarding',
    templateUrl  : './employee-onboarding.component.html',
    styleUrls    : ['./employee-onboarding.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class EmployeeOnboardingComponent implements OnInit
{
  public experienceselect = 'Select Type';
  title: string = 'AGM project';
  latitude: number;
  longitude: number;
  zoom: number;
  address: string;
  private geoCoder;
  google: any;
  

    horizontalStepperForm: FormGroup;
    verticalStepperForm: FormGroup;
    displayingexperience: boolean = false;
    experienceinfo:any;
    experienceform:any;
    experience:any;
    exuploaddocuments:any;
    attrval:any;
    dynamicForm: FormGroup;
    experiencedocuments: FormGroup;
    educatinForm: FormGroup;
    userForm: FormGroup;
    submitted = false;
    onbordingform:any;
    empinformation:any;
    firstname:any;
    middlename:any;
    lastName:any;
    fathername:any;
    officialemail:any;
    personalemail:any;
    dob:any;
    mobilenumber:any;
    blood:any;
    residential:any;
    country:any;
    religion:any;
    gender:any;
    maritalstatus:any;
    mothername:any;
    uanpfnumber:any;
    placeofbirth:any;
    nationality:any;
    Languages:any;
    emergencycontact:any;
    emgcontactperson:any;
    relationship:any;
    mobileNumber:any;
    phoneNumber:any;
    whatsappNumber:any;
    emailAddress:any;
    faxNumber:any;
    alternativemobile:any;
    initialName:any;
    current_addressline1:any;
    current_addressline2:any;
    current_city:any;
    current_pincode:any;
    current_state:any;
    current_country:any;
    permanent_addressline1:any;
    permanent_addressline2:any;
    permanent_city:any;
    permanent_pincode:any;
    permanent_state:any;
    permanent_country:any;
    addressinfo:any;
    qualification:any;
    highestqualification:any;
    pro_institutionname:any;
    pro_professional:any;
    pro_city:any;
    pro_state:any;
    pro_degree:any;
    pro_measuretype:any;
    pro_marks:any;
    pro_startdate:any;
    pro_enddate:any;
    pro_achievements:any;

    pg_institutionname:any;
    pg_professional:any;
    pg_city:any;
    pg_state:any;
    pg_degree:any;
    pg_measuretype:any;
    pg_marks:any;
    pg_startdate:any;
    pg_enddate:any;
    pg_achievements:any;

    ug_institutionname:any;
    ug_professional:any;
    ug_city:any;
    ug_state:any;
    ug_degree:any;
    ug_measuretype:any;
    ug_marks:any;
    ug_startdate:any;
    ug_enddate:any;
    ug_achievements:any;

    highersec_institutionname:any;
    highersec_professional:any;
    highersec_city:any;
    highersec_state:any;
    highersec_major:any;
    highersec_measuretype:any;
    highersec_marks:any;
    highersec_startdate:any;
    highersec_enddate:any;
    highersec_achievements:any;
    highschool_institutionname:any;
    highschool_professional:any;
    highschool_city:any;
    highschool_state:any;
    highschool_major:any;
    highschool_measuretype:any;
    highschool_marks:any;
    highschool_startdate:any;
    highschool_enddate:any;
    highschool_achievements:any;
    HighestQualification = [
        {value: 'Professional', viewValue: 'Professional'},
        {value: 'PG', viewValue: 'PG'},
        {value: 'UG', viewValue: 'UG'},
        {value: 'Higher Secondary', viewValue: 'Higher Secondary'},
        {value: 'High School', viewValue: 'High School'},
        {value: 'Other Qualification', viewValue: 'Other Qualification'}
      ];
    professional:boolean;
    pg:boolean;
    ug:boolean;
    highersecondary:boolean;
    highschool:boolean;
    selectlanguage:string;
    languages = new FormControl();
    languageList = ['Tamil', 'English', 'Hindi', 'Telugu', 'Bengali', 'Marathi','Urdu', 'Kannada', 'Gujarati', 'Odia', 'Malayalam', 'Dongri','Konkani', 'Kashmiri','Manipuri', 'Nepali', 'Punjabi', 'Sanskrit', 'Santali', 'Sindhi'];
    nationalityList = ['Afghan','Albanian','Algerian','American','Andorran','Angolan','Antiguans','Argentinean','Armenian','Australian','Austrian','Azerbaijani','Bahamian','Bahraini','Bangladeshi','Barbadian','Barbudans','Batswana','Belarusian','Belgian','Belizean','Beninese','Bhutanese','Bolivian','Bosnian','Brazilian','British','Bruneian','Bulgarian','Burkinabe','Burmese','Burundian','Cambodian','Cameroonian','Canadian','Cape Verdean','Central African','Chadian','Chilean','Chinese','Colombian','Comoran','Congolese','Costa Rican','Croatian','Cuban','Cypriot','Czech','Danish','Djibouti','Dominican','Dutch','East Timorese','Ecuadorean','Egyptian','Emirian','Equatorial Guinean','Eritrean','Estonian','Ethiopian','Fijian','Filipino','Finnish','French','Gabonese','Gambian','Georgian','German','Ghanaian','Greek','Grenadian','Guatemalan','Guinea-Bissauan','Guinean','Guyanese','Haitian','Herzegovinian','Honduran','Hungarian','Icelander','Indian','Indonesian','Iranian','Iraqi','Irish','Israeli','Italian','Ivorian','Jamaican','Japanese','Jordanian','Kazakhstani','Kenyan','Kittian and Nevisian','Kuwaiti','Kyrgyz','Laotian','Latvian','Lebanese','Liberian','Libyan','Liechtensteiner','Lithuanian','Luxembourger','Macedonian','Malagasy','Malawian','Malaysian','Maldivan','Malian','Maltese','Marshallese','Mauritanian','Mauritian','Mexican','Micronesian','Moldovan','Monacan','Mongolian','Moroccan','Mosotho','Motswana','Mozambican','Namibian','Nauruan','Nepalese','New Zealander','Ni-Vanuatu','Nicaraguan','Nigerien','North Korean','Northern Irish','Norwegian','Omani','Pakistani','Palauan','Panamanian','Papua New Guinean','Paraguayan','Peruvian','Polish','Portuguese','Qatari','Romanian','Russian','Rwandan','Saint Lucian','Salvadoran','Samoan','San Marinese','Sao Tomean','Saudi','Scottish','Senegalese','Serbian','Seychellois','Sierra Leonean','Singaporean','Slovakian','Slovenian','Solomon Islander','Somali','South African','South Korean','Spanish','Sri Lankan','Sudanese','Surinamer','Swazi','Swedish','Swiss','Syrian','Taiwanese','Tajik','Tanzanian','Thai','Togolese','Tongan','Trinidadian or Tobagonian','Tunisian','Turkish','Tuvaluan','Ugandan','Ukrainian','Uruguayan','Uzbekistani','Venezuelan','Vietnamese','Welsh','Yemenite','Zambian','Zimbabwean'];
    countryList = ['Afghanistan','Aland Islands','Albania','Algeria','American Samoa','Andorra','Angola','Anguilla','Antarctica','Antigua And Barbuda','Argentina','Armenia','Aruba','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Belize','Benin','Bermuda','Bhutan','Bolivia','Bosnia And Herzegovina','Botswana','Bouvet Island','Brazil','British Indian Ocean Territory','Brunei Darussalam','Bulgaria','Burkina Faso','Burundi','Cambodia','Cameroon','Canada','Cape Verde','Cayman Islands','Central African Republic','Chad','Chile','China','Christmas Island','Cocos (Keeling) Islands','Colombia','Comoros','Congo','Congo, Democratic Republic','Cook Islands','Costa Rica','Cote D\'Ivoire','Croatia','Cuba','Cyprus','Czech Republic','Denmark','Djibouti','Dominica','Dominican Republic','Ecuador','Egypt','El Salvador','Equatorial Guinea','Eritrea','Estonia','Ethiopia','Falkland Islands (Malvinas)','Faroe Islands','Fiji','Finland','France','French Guiana','French Polynesia','French Southern Territories','Gabon','Gambia','Georgia','Germany','Ghana','Gibraltar','Greece','Greenland','Grenada','Guadeloupe','Guam','Guatemala','Guernsey','Guinea','Guinea-Bissau','Guyana','Haiti','Heard Island & Mcdonald Islands','Holy See (Vatican City State)','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran, Islamic Republic Of','Iraq','Ireland','Isle Of Man','Israel','Italy','Jamaica','Japan','Jersey','Jordan','Kazakhstan','Kenya','Kiribati','Korea','Kuwait','Kyrgyzstan','Lao People\'s Democratic Republic','Latvia','Lebanon','Lesotho','Liberia','Libyan Arab Jamahiriya','Liechtenstein','Lithuania','Luxembourg','Macao','Macedonia','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Marshall Islands','Martinique','Mauritania','Mauritius','Mayotte','Mexico','Micronesia, Federated States Of','Moldova','Monaco','Mongolia','Montenegro','Montserrat','Morocco','Mozambique','Myanmar','Namibia','Nauru','Nepal','Netherlands','Netherlands Antilles','New Caledonia','New Zealand','Nicaragua','Niger','Nigeria','Niue','Norfolk Island','Northern Mariana Islands','Norway','Oman','Pakistan','Palau','Palestinian Territory, Occupied','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Pitcairn','Poland','Portugal','Puerto Rico','Qatar','Reunion','Romania','Russian Federation','Rwanda','Saint Barthelemy','Saint Helena','Saint Kitts And Nevis','Saint Lucia','Saint Martin','Saint Pierre And Miquelon','Saint Vincent And Grenadines','Samoa','San Marino','Sao Tome And Principe','Saudi Arabia','Senegal','Serbia','Seychelles','Sierra Leone','Singapore','Slovakia','Slovenia','Solomon Islands','Somalia','South Africa','South Georgia And Sandwich Isl.','Spain','Sri Lanka','Sudan','Suriname','Svalbard And Jan Mayen','Swaziland','Sweden','Switzerland','Syrian Arab Republic','Taiwan','Tajikistan','Tanzania','Thailand','Timor-Leste','Togo','Tokelau','Tonga','Trinidad And Tobago','Tunisia','Turkey','Turkmenistan','Turks And Caicos Islands','Tuvalu','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States','United States Outlying Islands','Uruguay','Uzbekistan','Vanuatu','Venezuela','Viet Nam','Virgin Islands, British','Virgin Islands, U.S.','Wallis And Futuna','Western Sahara','Yemen','Zambia','Zimbabwe'];
    stateList = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jammu and Kashmir','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands','Chandigarh','Dadra and Nagar Haveli','Daman and Diu','Lakshadweep','National Capital Territory of Delhi','Puducherry','Other'];
    removebtn:boolean= false;
    productForm: FormGroup;
    addresschecked:any;
    addresssamecheck:any;
    documentsdetails:any;
    fileToUpload: File = null;
    professional_education:boolean= false;
    pg_education:boolean= false;
    ug_education:boolean= false;
    highersecondary_education:boolean= false;
    higherschool_education:boolean= false;
    others_education:boolean= false;
    getexpdocuments:any;
    finalexperiencedocs:any;
    finalpanaadhaar:any;
    ifexperience:boolean=false;
    iffresher:boolean=true;
    finalexpletter:any;
    finalrelievingletter:any;
    finalresume:any;
    empinfomobileverify:any;
    aadhaar:any;
    pan:any;
    basicinfo:any;
    empaddressinfo:any;
    contactjson:any;
    educjson:any;
    expjson:any;
    emaildata:any;
    message:any;
    getmobileverify:any;
    getemailverify:any;
    panupload:any;
    aadhaarfiles: any;
    panfiles: File[] = [];
    getresumefiles: File[] = [];
    proffile: File[] = [];
    pgfile: any;
    ugfile: File[] = [];
    highersecondaryfile: File[] = [];
    higherschoolfile: File[] = [];
    experiencefile: File[] = [];
    getnoofcompany:any;
    aadhaarupload:any;
    resumeupload:any;
    profupload:any;
    pgupload:any;
    ugupload:any;
    highersecondaryupload:any;
    higherschoolupload:any;
    experienceupload:any;
    abcde:any;
    finaleducationdocs:any;
    allproffiles:any;	
    allpgfiles:any;
    allugfiles:any;
    allhighersecfiles:any;
    allhighschoolfiles:any;
    reldocupload:any;
    expdocupload:any;
    alleducationfiles:any;
    experiencesection:boolean= false;
    sendpanaahar:any;
    sendeducation:any;
    sendreleaving:any;
    sendresume:any;
    sendexperience:any;
    allexperience:any;
    allreaving:any;
    emailmobileverify:boolean= false;
    empinfoemailverify:any;
    aadhaarspinner:boolean=false;
    panspinner:boolean=false;
    resumespinner:boolean=false;
    educationspinner:boolean=false;
    experiencespinner:boolean=false;
    languagedata:any;
    abcd:any;
    efgh:any;
    getotpmsg:any;
    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    public contacts: any[] = [{
        id: 1,
        emgcontactperson: '',
        relationship: '',
        mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        phoneNumber: '',
        whatsappNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        emailAddress: '',
        faxNumber: '',
        alternativemobile: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]]
      }];
      
      mergedValue:[];
      @ViewChild('search')
  public searchElementRef: ElementRef;
    constructor(
      // private mapsAPILoader: MapsAPILoader,
      // private ngZone: NgZone,
      private datePipe: DatePipe,private fb11:FormBuilder,private _formBuilder: FormBuilder,private userService:UserService,public util:UtilityService,private formBuilder: FormBuilder,private fb: FormBuilder,public matDialog: MatDialog,public dialog: MatDialog
    )
    {
      this.util.invokeMobileotpPage.subscribe(value =>{
        this.getverifiedbtnmobile();
        console.log("hi")
    });
    this.util.invokeEmailotpPage.subscribe(value =>{
      this.getverifiedbtnemail();
      console.log("hi")
  });
         // Vertical stepper form
         this.verticalStepperForm = this._formBuilder.group({
            step1: this._formBuilder.group({
                firstName: ['', Validators.required],
                middleName : [''],
                lastName : [''],
                initialName: [''],
                fatherName : ['', Validators.required],
                officialemail   : ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
                personalemail   : ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
                dob: ['', Validators.required],
                mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
                blood: ['', Validators.required],
                residential: [''],
                country : [''],
                religion : ['', Validators.required],
                gender: ['', Validators.required],
                maritalStatus: ['', Validators.required],
                motherName: ['', Validators.required],
                uanpfNumber : [''],
                placeofBirth : [''],
                nationality: ['', Validators.required],
                languages: [''],
                // firstName: [''],
                // middleName : [''],
                // lastName : [''],
                // initialName: [''],
                // fatherName : [''],
                // officialemail   : [''],
                // personalemail   : [''],
                // dob: [''],
                // mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
                // blood: [''],
                // residential: [''],
                // country : [''],
                // religion : [''],
                // gender: [''],
                // maritalStatus: [''],
                // motherName: [''],
                // uanpfNumber : [''],
                // placeofBirth : [''],
                // nationality: [''],
                // languages: ['']
            }),
            step2: this._formBuilder.group({
                current_addressLine1: ['', Validators.required],
                current_addressLine2 : ['', Validators.required],
                current_city : ['', Validators.required],
                current_pincode : ['', Validators.required],
                current_state : [''],
                current_country : [''],
                permanent_addressLine1: ['', Validators.required],
                permanent_addressLine2 : ['', Validators.required],
                permanent_city : ['', Validators.required],
                permanent_pincode : ['', Validators.required],
                permanent_state : [''],
                permanent_country : ['']
                // current_addressLine1: [''],
                // current_addressLine2 : [''],
                // current_city : [''],
                // current_pincode : [''],
                // current_state : [''],
                // current_country : [''],
                // permanent_addressLine1: [''],
                // permanent_addressLine2 : [''],
                // permanent_city : [''],
                // permanent_pincode : [''],
                // permanent_state : [''],
                // permanent_country : ['']
            }),
            step3: this._formBuilder.group({
                // emgcontactperson: [''],
                // relationship : [''],
                // mobileNumber : [''],
                // phoneNumber : [''],
                // whatsappNumber : [''],
                // emailAddress : [''],
                // faxNumber : [''],
                // alternativemobile : ['']
            }),
            step4: this._formBuilder.group({
                // highestqualification: [''],
                // pro_institutionname: [''],
                // pro_professional : [''],
                // pro_city : [''],
                // pro_state : [''],
                // pro_degree : [''],
                // pro_measuretype : [''],
                // pro_marks : [''],
                // pro_startdate : [''],
                // pro_enddate : [''],
                // pro_achievements : [''],
                // pg_institutionname : [''],
                // pg_professional : [''],
                // pg_city : [''],
                // pg_state : [''],
                // pg_degree : [''],
                // pg_measuretype : [''],
                // pg_marks : [''],
                // pg_startdate : [''],
                // pg_enddate : [''],
                // pg_achievements : [''],
                // ug_institutionname : [''],
                // ug_professional : [''],
                // ug_city : [''],
                // ug_state : [''],
                // ug_degree : [''],
                // ug_measuretype : [''],
                // ug_marks : [''],
                // ug_startdate : [''],
                // ug_enddate : [''],
                // ug_achievements : [''],
                // highersec_institutionname: [''],
                // highersec_professional : [''],
                // highersec_city : [''],
                // highersec_state : [''],
                // highersec_major : [''],
                // highersec_measuretype : [''],
                // highersec_marks : [''],
                // highersec_startdate : [''],
                // highersec_enddate : [''],
                // highersec_achievements : [''],
                // highschool_institutionname: [''],
                // highschool_professional : [''],
                // highschool_city : [''],
                // highschool_state : [''],
                // highschool_major : [''],
                // highschool_measuretype : [''],
                // highschool_marks : [''],
                // highschool_startdate : [''],
                // highschool_enddate : [''],
                // highschool_achievements : ['']

                highestqualification: ['', Validators.required],
                pro_institutionname: ['', Validators.required],
                pro_professional : ['', Validators.required],
                pro_city : ['', Validators.required],
                pro_state : ['', Validators.required],
                pro_degree : ['', Validators.required],
                pro_measuretype : ['', Validators.required],
                pro_marks : ['', Validators.required],
                pro_startdate : ['', Validators.required],
                pro_enddate : [''],
                pro_achievements : ['', Validators.required],
                pg_institutionname : ['', Validators.required],
                pg_professional : ['', Validators.required],
                pg_city : ['', Validators.required],
                pg_state : ['', Validators.required],
                pg_degree : ['', Validators.required],
                pg_measuretype : ['', Validators.required],
                pg_marks : ['', Validators.required],
                pg_startdate : ['', Validators.required],
                pg_enddate : [''],
                pg_achievements : ['', Validators.required],
                ug_institutionname : ['', Validators.required],
                ug_professional : ['', Validators.required],
                ug_city : ['', Validators.required],
                ug_state : ['', Validators.required],
                ug_degree : ['', Validators.required],
                ug_measuretype : ['', Validators.required],
                ug_marks : ['', Validators.required],
                ug_startdate : ['', Validators.required],
                ug_enddate : [''],
                ug_achievements : ['', Validators.required],
                highersec_institutionname: ['', Validators.required],
                highersec_professional : ['', Validators.required],
                highersec_city : ['', Validators.required],
                highersec_state : ['', Validators.required],
                highersec_major : ['', Validators.required],
                highersec_measuretype : ['', Validators.required],
                highersec_marks : ['', Validators.required],
                highersec_startdate : ['', Validators.required],
                highersec_enddate : [''],
                highersec_achievements : ['', Validators.required],
                highschool_institutionname: ['', Validators.required],
                highschool_professional : ['', Validators.required],
                highschool_city : ['', Validators.required],
                highschool_state : ['', Validators.required],
                highschool_major : ['', Validators.required],
                highschool_measuretype : ['', Validators.required],
                highschool_marks : ['', Validators.required],
                highschool_startdate : ['', Validators.required],
                highschool_enddate : [''],
                highschool_achievements : ['', Validators.required]
            }),
            step5: this._formBuilder.group({
                // employername: ['', Validators.required],
                // designation : ['', Validators.required],
                // supervisorname : ['', Validators.required],
                // supervisorphone: ['', Validators.required],
                // jobdescription : ['', Validators.required],
                // achievements : ['', Validators.required],
                // lastdrawnCTC: ['', Validators.required],
                // takehomesalary : ['', Validators.required],
                // startdate : ['', Validators.required],
                // enddate : ['', Validators.required],
                // reasonsforleaving : ['', Validators.required]
            }),
            step6: this._formBuilder.group({
              aadhaarfile: [''],
              panfile: [''],
              resume: [''],
              // experience: [''],
              // relieving: [''],
              pro_certificate: [''],
              pg_certificate: [''],
              ug_certificate: [''],
              higersec_certificate: [''],
              highschool_certificate: ['']

            }),
            step7: this._formBuilder.group({
              pushNotifications: ['everything', Validators.required]
            })
        });

        this.professional = false;
        this.highersecondary = false;
        this.highschool = false;
        this.iffresher=true;

        this.experiencesection=false;
        //////
        this.productForm = this.fb11.group({
            // name: '',
            quantities: this.fb11.array([]) ,
          });
        //////
    }


    

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    comboChange(event) {
        if(!event) {
          this.selectlanguage = this.languages.value;
          this.languagedata = this.selectlanguage.toString().split(', ');
        }
      }
      mobileNoNotVerfied(){
        alert("Plesae verify your mobile number and Email!")
      }
    /**
     * On init
     */
    ngOnInit(): void
    {
      // var testdata = {0: "9087654321", 1: "7897897877"}
      // var testdata = ["9087654321", "7897897877"]; 
      // var object = testdata.split(', ');
      // console.log(object);
      
      this.onbordingform = this.verticalStepperForm.value;
      this.empinformation = this.onbordingform.step1;
      this.empinfomobileverify = localStorage.getItem('emponbordingmobilenum');
      this.verticalStepperForm.patchValue({step1: {mobileNumber: this.empinfomobileverify}})
      this.empinfoemailverify = localStorage.getItem('emponbordingemailverify');
      this.verticalStepperForm.patchValue({step1: {personalemail: this.empinfoemailverify}})
      this.addQuantity();
      this.getmobileverify = localStorage.getItem('mobileverify'); 
      this.getemailverify = localStorage.getItem('emailverify');
      if(this.getmobileverify == "verified" && this.getemailverify == "verified"){
        this.emailmobileverify=true;
      }else{
        this.emailmobileverify=false;
      }
/////////////////

//load Places Autocomplete

// this.mapsAPILoader.load().then(() => {
//   this.setCurrentLocation();
//   this.geoCoder = new google.maps.Geocoder;

//   let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement);
//   autocomplete.addListener("place_changed", () => {
//     this.ngZone.run(() => {
//       //get the place result
//       let place: google.maps.places.PlaceResult = autocomplete.getPlace();

//       //verify result
//       if (place.geometry === undefined || place.geometry === null) {
//         return;
//       }

//       //set latitude, longitude and zoom
//       this.latitude = place.geometry.location.lat();
//       this.longitude = place.geometry.location.lng();
//       this.zoom = 12;
//     });
//   });
// });

///////////////////



      
        this.util.profileHeader('hai..');
        this.dynamicForm = this.formBuilder.group({
            emloyeetype: ['', Validators.required],
            numberofcompany: ['', Validators.required],
            experiences: new FormArray([])
        });
        this.experiencedocuments = this.formBuilder.group({
          experience: ['', Validators.required],
          relieving : ['', Validators.required],
          expdocument: new FormArray([])
      });
      
//-------
        this.onbordingform = this.verticalStepperForm.value;
        this.empinformation = this.onbordingform.step1;
        this.addressinfo = this.onbordingform.step2;
        this.emergencycontact = this.onbordingform.step3;
        this.qualification = this.onbordingform.step4;
        
        //step1
        this.firstname = this.empinformation.firstName;
        this.verticalStepperForm.patchValue({step1: {firstName: this.firstname}})
        this.middlename = this.empinformation.middleName;
        this.verticalStepperForm.patchValue({step1: {middleName: this.middlename}})
        this.lastName = this.empinformation.lastName;
        this.verticalStepperForm.patchValue({step1: {lastName: this.lastName}})
        this.initialName = this.empinformation.initialName;
        this.verticalStepperForm.patchValue({step1: {initialName: this.initialName}})
        this.fathername = this.empinformation.fatherName;
        this.verticalStepperForm.patchValue({step1: {fatherName: this.fathername}})
        this.officialemail = this.empinformation.officialemail;
        this.verticalStepperForm.patchValue({step1: {officialemail: this.officialemail}})
        this.personalemail = this.empinformation.personalemail;
        this.verticalStepperForm.patchValue({step1: {personalemail: this.personalemail}})
        this.dob = this.empinformation.dob;
        this.verticalStepperForm.patchValue({step1: {dob: this.dob}})
        this.mobilenumber = this.empinformation.mobileNumber;
        this.verticalStepperForm.patchValue({step1: {mobileNumber: this.mobilenumber}})
        this.blood = this.empinformation.blood;
        this.verticalStepperForm.patchValue({step1: {blood: this.blood}})
        this.residential = this.empinformation.residential;
        this.verticalStepperForm.patchValue({step1: {residential: this.residential}})
        this.country = this.empinformation.country;
        this.verticalStepperForm.patchValue({step1: {country: this.country}})
        this.religion = this.empinformation.religion;
        this.verticalStepperForm.patchValue({step1: {religion: this.religion}})
        this.gender = this.empinformation.gender;
        this.verticalStepperForm.patchValue({step1: {gender: this.gender}})
        this.maritalstatus = this.empinformation.maritalStatus;
        this.verticalStepperForm.patchValue({step1: {maritalstatus: this.maritalstatus}})
        this.mothername = this.empinformation.motherName;
        this.verticalStepperForm.patchValue({step1: {motherName: this.mothername}})
        this.uanpfnumber = this.empinformation.uanpfNumber;
        this.verticalStepperForm.patchValue({step1: {uanpfNumber: this.uanpfnumber}})
        this.placeofbirth = this.empinformation.placeofBirth;
        this.verticalStepperForm.patchValue({step1: {placeofBirth: this.placeofbirth}})
        this.nationality = this.empinformation.nationality;
        this.verticalStepperForm.patchValue({step1: {nationality: this.nationality}})
        this.Languages = this.empinformation.languages;
        this.verticalStepperForm.patchValue({step1: {languages: this.Languages}})
        //step2
        this.current_addressline1 = this.addressinfo.current_addressLine1;
        this.verticalStepperForm.patchValue({step3: {current_addressline1: this.current_addressline1}})
        this.current_addressline2 = this.addressinfo.current_addressLine2;
        this.verticalStepperForm.patchValue({step3: {current_addressline2: this.current_addressline2}})
        this.current_city = this.addressinfo.current_city;
        this.verticalStepperForm.patchValue({step3: {current_city: this.current_city}})
        this.current_pincode = this.addressinfo.current_pincode;
        this.verticalStepperForm.patchValue({step3: {current_pincode: this.current_pincode}})
        this.current_state = this.addressinfo.current_state;
        this.verticalStepperForm.patchValue({step3: {current_state: this.current_state}})
        this.current_country = this.addressinfo.current_country;
        this.verticalStepperForm.patchValue({step3: {current_country: this.current_country}})
        this.permanent_addressline1 = this.addressinfo.permanent_addressLine1;
        this.verticalStepperForm.patchValue({step3: {permanent_addressline1: this.permanent_addressline1}})
        this.permanent_addressline2 = this.addressinfo.permanent_addressLine2;
        this.verticalStepperForm.patchValue({step3: {permanent_addressline2: this.permanent_addressline2}})
        this.permanent_city = this.addressinfo.permanent_city;
        this.verticalStepperForm.patchValue({step3: {permanent_city: this.permanent_city}})
        this.permanent_pincode = this.addressinfo.permanent_pincode;
        this.verticalStepperForm.patchValue({step3: {permanent_pincode: this.permanent_pincode}})
        this.permanent_state = this.addressinfo.current_state;
        this.verticalStepperForm.patchValue({step3: {permanent_state: this.permanent_state}})
        this.permanent_country = this.addressinfo.permanent_country;
        this.verticalStepperForm.patchValue({step3: {permanent_country: this.permanent_country}})
        //step3
        this.emgcontactperson = this.emergencycontact.emgcontactperson;
        this.verticalStepperForm.patchValue({step3: {emgcontactperson: this.emgcontactperson}})
        this.relationship = this.emergencycontact.relationship;
        this.verticalStepperForm.patchValue({step3: {relationship: this.relationship}})
        this.mobileNumber = this.emergencycontact.mobileNumber;
        this.verticalStepperForm.patchValue({step3: {mobileNumber: this.mobileNumber}})
        this.phoneNumber = this.emergencycontact.phoneNumber;
        this.verticalStepperForm.patchValue({step3: {phoneNumber: this.phoneNumber}})
        this.whatsappNumber = this.emergencycontact.whatsappNumber;
        this.verticalStepperForm.patchValue({step3: {whatsappNumber: this.whatsappNumber}})
        this.emailAddress = this.emergencycontact.emailAddress;
        this.verticalStepperForm.patchValue({step3: {emailAddress: this.emailAddress}})
        this.faxNumber = this.emergencycontact.faxNumber;
        this.verticalStepperForm.patchValue({step3: {faxNumber: this.faxNumber}})
        this.alternativemobile = this.emergencycontact.alternativemobile;
        this.verticalStepperForm.patchValue({step3: {alternativemobile: this.alternativemobile}})
        //step4
        this.highestqualification = this.qualification.highestqualification;
        this.verticalStepperForm.patchValue({step4: {highestqualification: this.highestqualification}})
        this.pro_institutionname = this.qualification.pro_institutionname;
        this.verticalStepperForm.patchValue({step4: {pro_institutionname: this.pro_institutionname}})
        this.pro_professional = this.qualification.pro_professional;
        this.verticalStepperForm.patchValue({step4: {pro_professional: this.pro_professional}})
        this.pro_city = this.qualification.pro_city;
        this.verticalStepperForm.patchValue({step4: {pro_city: this.pro_city}})
        this.pro_state = this.qualification.pro_state;
        this.verticalStepperForm.patchValue({step4: {pro_state: this.pro_state}})
        this.pro_degree = this.qualification.pro_degree;
        this.verticalStepperForm.patchValue({step4: {pro_degree: this.pro_degree}})
        this.pro_measuretype = this.qualification.pro_measuretype;
        this.verticalStepperForm.patchValue({step4: {pro_measuretype: this.pro_measuretype}})
        this.pro_marks = this.qualification.pro_marks;
        this.verticalStepperForm.patchValue({step4: {pro_marks: this.pro_marks}})
        this.pro_startdate = this.qualification.pro_startdate;
        this.verticalStepperForm.patchValue({step4: {pro_startdate: this.pro_startdate}})
        this.pro_enddate = this.qualification.pro_enddate;
        this.verticalStepperForm.patchValue({step4: {pro_enddate: this.pro_enddate}})
        this.pro_achievements = this.qualification.pro_achievements;
        this.verticalStepperForm.patchValue({step4: {pro_achievements: this.pro_achievements}})

        this.pg_institutionname = this.qualification.pg_institutionname;
        this.verticalStepperForm.patchValue({step4: {pg_institutionname: this.pg_institutionname}})
        this.pg_professional = this.qualification.pg_professional;
        this.verticalStepperForm.patchValue({step4: {pg_professional: this.pg_professional}})
        this.pg_city = this.qualification.pro_city;
        this.verticalStepperForm.patchValue({step4: {pg_city: this.pg_city}})
        this.pg_state = this.qualification.pro_state;
        this.verticalStepperForm.patchValue({step4: {pg_state: this.pg_state}})
        this.pg_degree = this.qualification.pro_degree;
        this.verticalStepperForm.patchValue({step4: {pg_degree: this.pg_degree}})
        this.pg_measuretype = this.qualification.pro_measuretype;
        this.verticalStepperForm.patchValue({step4: {pg_measuretype: this.pg_measuretype}})
        this.pg_marks = this.qualification.pro_marks;
        this.verticalStepperForm.patchValue({step4: {pg_marks: this.pg_marks}})
        this.pg_startdate = this.qualification.pro_startdate;
        this.verticalStepperForm.patchValue({step4: {pg_startdate: this.pg_startdate}})
        this.pg_enddate = this.qualification.pro_enddate;
        this.verticalStepperForm.patchValue({step4: {pro_enddate: this.pg_enddate}})
        this.pg_achievements = this.qualification.pg_achievements;
        this.verticalStepperForm.patchValue({step4: {pg_achievements: this.pg_achievements}})

        this.ug_institutionname = this.qualification.ug_institutionname;
        this.verticalStepperForm.patchValue({step4: {ug_institutionname: this.ug_institutionname}})
        this.ug_professional = this.qualification.ug_professional;
        this.verticalStepperForm.patchValue({step4: {ug_professional: this.ug_professional}})
        this.ug_city = this.qualification.ug_city;
        this.verticalStepperForm.patchValue({step4: {ug_city: this.ug_city}})
        this.ug_state = this.qualification.ug_state;
        this.verticalStepperForm.patchValue({step4: {ug_state: this.ug_state}})
        this.ug_degree = this.qualification.ug_degree;
        this.verticalStepperForm.patchValue({step4: {ug_degree: this.ug_degree}})
        this.ug_measuretype = this.qualification.ug_measuretype;
        this.verticalStepperForm.patchValue({step4: {ug_measuretype: this.ug_measuretype}})
        this.ug_marks = this.qualification.ug_marks;
        this.verticalStepperForm.patchValue({step4: {ug_marks: this.ug_marks}})
        this.ug_startdate = this.qualification.ug_startdate;
        this.verticalStepperForm.patchValue({step4: {ug_startdate: this.ug_startdate}})
        this.ug_enddate = this.qualification.ug_enddate;
        this.verticalStepperForm.patchValue({step4: {ug_enddate: this.ug_enddate}})
        this.ug_achievements = this.qualification.ug_achievements;
        this.verticalStepperForm.patchValue({step4: {ug_achievements: this.ug_achievements}})

        this.highersec_institutionname = this.qualification.highersec_institutionname;
        this.verticalStepperForm.patchValue({step4: {highersec_institutionname: this.highersec_institutionname}})
        this.highersec_professional = this.qualification.highersec_professional;
        this.verticalStepperForm.patchValue({step4: {highersec_professional: this.highersec_professional}})
        this.highersec_city = this.qualification.highersec_city;
        this.verticalStepperForm.patchValue({step4: {highersec_city: this.highersec_city}})
        this.highersec_state = this.qualification.highersec_state;
        this.verticalStepperForm.patchValue({step4: {highersec_state: this.highersec_state}})
        this.highersec_major = this.qualification.highersec_major;
        this.verticalStepperForm.patchValue({step4: {highersec_major: this.highersec_major}})
        this.highersec_measuretype = this.qualification.highersec_measuretype;
        this.verticalStepperForm.patchValue({step4: {highersec_measuretype: this.highersec_measuretype}})
        this.highersec_marks = this.qualification.highersec_marks;
        this.verticalStepperForm.patchValue({step4: {highersec_marks: this.highersec_marks}})
        this.highersec_startdate = this.qualification.highersec_startdate;
        this.verticalStepperForm.patchValue({step4: {highersec_startdate: this.highersec_startdate}})
        this.highersec_enddate = this.qualification.highersec_enddate;
        this.verticalStepperForm.patchValue({step4: {highersec_enddate: this.highersec_enddate}})
        this.highersec_achievements = this.qualification.highersec_achievements;
        this.verticalStepperForm.patchValue({step4: {highersec_achievements: this.highersec_achievements}})

        this.highschool_institutionname = this.qualification.highschool_institutionname;
        this.verticalStepperForm.patchValue({step4: {highschool_institutionname: this.highschool_institutionname}})
        this.highschool_professional = this.qualification.highschool_professional;
        this.verticalStepperForm.patchValue({step4: {highschool_professional: this.highschool_professional}})
        this.highschool_city = this.qualification.highschool_city;
        this.verticalStepperForm.patchValue({step4: {highschool_city: this.highschool_city}})
        this.highschool_state = this.qualification.highschool_state;
        this.verticalStepperForm.patchValue({step4: {highschool_state: this.highschool_state}})
        this.highschool_major = this.qualification.highschool_major;
        this.verticalStepperForm.patchValue({step4: {highschool_major: this.highschool_major}})
        this.highschool_measuretype = this.qualification.highschool_measuretype;
        this.verticalStepperForm.patchValue({step4: {highschool_measuretype: this.highschool_measuretype}})
        this.highschool_marks = this.qualification.highschool_marks;
        this.verticalStepperForm.patchValue({step4: {highschool_marks: this.highschool_marks}})
        this.highschool_startdate = this.qualification.highschool_startdate;
        this.verticalStepperForm.patchValue({step4: {highschool_startdate: this.highschool_startdate}})
        this.highschool_enddate = this.qualification.highschool_enddate;
        this.verticalStepperForm.patchValue({step4: {highschool_enddate: this.highschool_enddate}})
        this.highschool_achievements = this.qualification.highschool_achievements;
        this.verticalStepperForm.patchValue({step4: {highschool_achievements: this.highschool_achievements}})

    }
    getverifiedbtnmobile(){
      this.getmobileverify = localStorage.getItem('mobileverify'); 
      if(this.getmobileverify == "verified" && this.getemailverify == "verified"){
        this.emailmobileverify=true;
      }else{
        this.emailmobileverify=false;
      }
    }
    getverifiedbtnemail(){
      this.getemailverify = localStorage.getItem('emailverify');
      if(this.getmobileverify == "verified" && this.getemailverify == "verified"){
        this.emailmobileverify=true;
      }else{
        this.emailmobileverify=false;
      } 
    }
    //step1 info
    emailVerify(){
      this.emaildata=[];
      this.onbordingform = this.verticalStepperForm.value;
      this.empinformation = this.onbordingform.step1;
      var firstname = this.empinformation.firstName;
      var personalemail = this.empinformation.personalemail;
      localStorage.setItem('emponbordingemailverify',personalemail);
      // this.emaildata = {firstname,personalemail};
      this.emaildata.push({name:firstname,email:personalemail});
      var empotpvalemail = Math.floor(1000 + Math.random() * 9000);
      this.message="<!DOCTYPE html><html><body><p>&nbsp;</p><p class='c1'><span style='overflow: hidden; display: inline-block; margin: -6px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 172.00px; height: 24.50px;'><img alt='Logo' src='https://conqhr.com/assets/images/logo.png' style='margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);'></span><span class='c14'>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></p><hr><p class='c1'><span class='c14'>&nbsp;</span></p><p style='color: #000;font-family: Arial;'>Your OTP,&emsp; "+''+empotpvalemail+''+"</b>.</p><p>&nbsp;</p></body></html>";
        const postData = {
          "to":this.emaildata,
          "bcc":[],
          "cc":[],
          "subject":"Notification message",
          "message":this.message,
          "notification":true,
          "from":{"value":[{"address":"conqhr@indiafilings.com", "name":"ConqHR"}]},
          "save":false
        }
        this.userService.getnotification(postData)
        .subscribe((res) =>{
          // if(res.type=="success"){
          // const dialogConfig = new MatDialogConfig();
          // dialogConfig.disableClose = true;
          // dialogConfig.id = "modal-component";
          // dialogConfig.height = "350px";
          // dialogConfig.width = "600px";
          // const modalDialog = this.matDialog.open(OnboardemailmodalComponent, dialogConfig);
          // }
      })
      const dialogConfig = new MatDialogConfig();
          dialogConfig.disableClose = true;
          dialogConfig.id = "modal-component";
          dialogConfig.height = "350px";
          dialogConfig.width = "600px";
          const modalDialog = this.matDialog.open(OnboardemailmodalComponent, dialogConfig);
      localStorage.setItem('empgetemailotp',JSON.stringify(empotpvalemail));
    }
    mobileVerify(){
      this.onbordingform = this.verticalStepperForm.value;
      this.empinformation = this.onbordingform.step1;
      this.empinfomobileverify = this.empinformation.mobileNumber;
      localStorage.setItem('emponbordingmobilenum',this.empinfomobileverify);
      var empotpval = Math.floor(1000 + Math.random() * 9000);
      this.getotpmsg="Employment application: "+''+empotpval+''+" is the verification code.";
        const postData = {
            "mobile":this.empinfomobileverify,
            "otp": this.getotpmsg
        };
        var otpresult = this.userService.onboardingotp(postData)
        .subscribe((res) =>{
        })
        if(otpresult){
          localStorage.setItem('empgetotp',JSON.stringify(empotpval));
        }else{
            alert("error");
        }
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.id = "modal-component";
        dialogConfig.height = "350px";
        dialogConfig.width = "600px";
        const modalDialog = this.matDialog.open(OnboardmobilemodalComponent, dialogConfig);
    }
   
    employerinfo(){
      // this.getmobileverify = localStorage.getItem('mobileverify'); 
      // this.getemailverify = localStorage.getItem('emailverify');
      // if(this.getmobileverify == "verified"){
        
      // }else{
      //   alert('Please check your mobile number')
      //   return
      // }
        this.onbordingform = this.verticalStepperForm.value;
        this.empinformation = this.onbordingform.step1;
        this.basicinfo = {
            "firstname": this.empinformation.firstName,
            "middlename" : this.empinformation.middleName,
            "lastname" : this.empinformation.lastName,
            "salutation": this.empinformation.initialName,
            "fathername" : this.empinformation.fatherName,
            "email" : this.empinformation.officialemail,
            "personalemail" : this.empinformation.personalemail,
            "dob": this.empinformation.dob,
            "mobile": this.empinformation.mobileNumber,
            "bloodgroup": this.empinformation.blood,
            "residential": this.empinformation.residential,
            "country" : this.empinformation.country,
            "religion" : this.empinformation.religion,
            "gender": this.empinformation.gender,
            "maritalstatus": this.empinformation.maritalStatus,
            "motherorspouse": this.empinformation.motherName,
            "uan" : this.empinformation.uanpfNumber,
            "birthplace" : this.empinformation.placeofBirth,
            "origin_country": this.empinformation.nationality,
            "languages":this.languagedata
        }
        console.log(this.basicinfo);
    }
    //step2
    sameAddress(e){
      if(e.checked){
        this.addresschecked = "yes";
      }else{
        this.addresschecked = "no";
      }
      this.onbordingform = this.verticalStepperForm.value;
      this.addressinfo = this.onbordingform.step2;
      if(e.checked){
          this.permanent_addressline1 = this.addressinfo.current_addressLine1;
          this.verticalStepperForm.patchValue({step2: {permanent_addressLine1: this.permanent_addressline1}})
          this.permanent_addressline2 = this.addressinfo.current_addressLine2;
          this.verticalStepperForm.patchValue({step2: {permanent_addressLine2: this.permanent_addressline2}})
          this.permanent_city = this.addressinfo.current_city;
          this.verticalStepperForm.patchValue({step2: {permanent_city: this.permanent_city}})
          this.permanent_pincode = this.addressinfo.current_pincode;
          this.verticalStepperForm.patchValue({step2: {permanent_pincode: this.permanent_pincode}})
          this.permanent_state = this.addressinfo.current_state;
          this.verticalStepperForm.patchValue({step2: {permanent_state: this.permanent_state}})
          this.permanent_country = this.addressinfo.current_country;
          this.verticalStepperForm.patchValue({step2: {permanent_country: this.permanent_country}})
      }else{
          this.verticalStepperForm.patchValue({step2: {permanent_addressline1: ""}})
          this.verticalStepperForm.patchValue({step2: {permanent_addressline2: ""}})
          this.verticalStepperForm.patchValue({step2: {permanent_city: ""}})
          this.verticalStepperForm.patchValue({step2: {permanent_pincode: ""}})
          this.verticalStepperForm.patchValue({step2: {permanent_state: ""}})
          this.verticalStepperForm.patchValue({step2: {permanent_country: ""}})
      }
    }
    //step2 submit
    addressDetails(){
      if(this.addresschecked){
        this.addresssamecheck = "yes";
      }else{
        this.addresssamecheck = "no";
      }
      this.onbordingform = this.verticalStepperForm.value;
      this.addressinfo = this.onbordingform.step2;
      this.empaddressinfo = [];
      // this.empaddressinfo = {
          // "samecheck":this.addresssamecheck,
          // "presentaddress1":this.addressinfo.current_addressLine1,
          // "presentaddress2" :this.addressinfo.current_addressLine2,
          // "presentcity" :this.addressinfo.current_city,
          // "presentpincode" :this.addressinfo.current_pincode,
          // "presentstate" :this.addressinfo.current_state,
          // "presentcountry" :this.addressinfo.current_country,
          // "permananetaddress1" :this.addressinfo.permanent_addressLine1,
          // "permananetaddress2" :this.addressinfo.permanent_addressLine2,
          // "permananetcity" :this.addressinfo.permanent_city,
          // "permananetpincode" :this.addressinfo.permanent_pincode,
          // "permananetstate" :this.addressinfo.permanent_state,
          // "permananetcountry" :this.addressinfo.permanent_country
      // }
      this.abcd = Object.assign({"presentaddress1":this.addressinfo.current_addressLine1,"presentaddress2" :this.addressinfo.current_addressLine2,"presentcity" :this.addressinfo.current_city,"presentpincode" :this.addressinfo.current_pincode,"presentstate" :this.addressinfo.current_state, "presentcountry" :this.addressinfo.current_country});
      this.efgh = Object.assign({"permananetaddress1" :this.addressinfo.permanent_addressLine1,"permananetaddress2" :this.addressinfo.permanent_addressLine2,"permananetcity" :this.addressinfo.permanent_city,"permananetpincode" :this.addressinfo.permanent_pincode,"permananetstate" :this.addressinfo.permanent_state,"permananetcountry" :this.addressinfo.permanent_country});
      this.empaddressinfo.push(this.abcd,this.efgh)
      console.log(this.empaddressinfo);
  }

    ///step3
    
    //////
    quantities() : FormArray {
        return this.productForm.get("quantities") as FormArray
      }
       
      newQuantity(): FormGroup {
        return this.fb.group({
            emer_contact_person: ['', Validators.required],
            relationship : ['', Validators.required],
            cont_mobile_number : ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
            cont_phone_number :'',
            cont_whatsapp_number : ["", Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")],
            cont_email_address : '',
            cont_fax_number : '',
            alter_mobile_number : ["", Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")],
        })
      }

      keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
          event.preventDefault();
        }
      }
       
      addQuantity() {
        this.quantities().push(this.newQuantity());
      }
       
      removeQuantity(i:number) {
        this.quantities().removeAt(i);
      }
       
      onSubmit11() {
          var contactdetails = this.productForm.value;
          var getcontactdata = contactdetails.quantities;
          this.contactjson = []; 
          for(var i=0;i<getcontactdata.length;i++){
            this.contactjson.push({mobile:getcontactdata[i].cont_mobile_number.toString(),faxnumber:getcontactdata[i].cont_fax_number,phonenumber:getcontactdata[i].cont_phone_number.toString(),emailaddress:getcontactdata[i].cont_email_address,relationship:getcontactdata[i].relationship,contactperson:getcontactdata[i].emer_contact_person,whatsappnumber:getcontactdata[i].cont_whatsapp_number,altermobilenumber:getcontactdata[i].alter_mobile_number})
          }
          console.log(this.contactjson);
      }
    //////
    
    emptype(e){
      var getemptype = e;
      if(getemptype=="Fresher"){
        this.dynamicForm.get("numberofcompany").setValue("null");
        
        this.ifexperience=false;
        this.iffresher=true;
      }else{
        this.dynamicForm.get("numberofcompany").setValue("");
        this.ifexperience=true;
        this.iffresher=false;
      }
    }

    //form experience
    // convenience getters for easy access to form fields
    get f() { return this.dynamicForm.controls; }
    get t() { return this.f.experiences as FormArray; }

    onChangeExperiences(e) {
        this.displayingexperience = true;
        const numberofcompany = e.target.value || 0;
        if (this.t.length < numberofcompany) {
            for (let i = this.t.length; i < numberofcompany; i++) {
                this.t.push(this.formBuilder.group({
                    empr_name: ['', Validators.required],
                    empr_designation : ['', Validators.required],
                    supervisorname : ['', Validators.required],
                    empr_supervisor_phone: ['', Validators.required],
                    empr_job_description : ['', Validators.required],
                    empr_achievements : ['', Validators.required],
                    empr_last_drawn_ctc: ['', Validators.required],
                    empr_take_home_monthly_salary : ['', Validators.required],
                    empr_job_sdate : ['', Validators.required],
                    empr_job_edate : ['', Validators.required],
                    empr_job_reasons_leaving : ['', Validators.required],

                }));
            }
        } else {
            for (let i = this.t.length; i >= numberofcompany; i--) {
                this.t.removeAt(i);
            }
        }
        this.experiencesDocuemnts(numberofcompany);
    }
//

    get a() { return this.experiencedocuments.controls; }
    get b() { return this.a.expdocument as FormArray; }
    experiencesDocuemnts(e) {
      this.experiencesection=true;
      const numberofcompany = e;
      this.getnoofcompany = numberofcompany * 2;
      if (this.b.length < numberofcompany) {
          for (let i = this.b.length; i < numberofcompany; i++) {
              this.b.push(this.formBuilder.group({
                experience: ['', Validators.required],
                relieving : ['', Validators.required],
              }));
          }
      } else {
          for (let i = this.b.length; i >= numberofcompany; i--) {
              this.b.removeAt(i);
          }
      }
      
  }

    onSubmit() {
        this.submitted = true;
        // stop here if form is invalid
        if (this.dynamicForm.invalid) {
            return;
        }
        var sampledata = this.dynamicForm.value;
        var sampledataexp = sampledata.experiences;
        var exptititle = sampledata.emloyeetype;
        this.expjson = []; 
        if(exptititle == "Experience"){
          for(var i=0;i<sampledataexp.length;i++){
            this.expjson.push({enddate:sampledataexp[i].empr_job_edate.replaceAll("-","/"),startdate:sampledataexp[i].empr_job_sdate.replaceAll("-","/"),designation:sampledataexp[i].empr_designation,achievements:sampledataexp[i].empr_achievements,employername:sampledataexp[i].empr_name,lastdrawnctc:sampledataexp[i].empr_last_drawn_ctc,monthlysalary:sampledataexp[i].empr_take_home_monthly_salary,jobdescription:sampledataexp[i].empr_job_description,supervisorname:sampledataexp[i].supervisorname,relieveingreason:sampledataexp[i].empr_job_reasons_leaving,supervisormobile:sampledataexp[i].empr_supervisor_phone})
          }
          this.expjson.push({type:exptititle,numberofcompany: sampledata.numberofcompany})
          console.log(this.expjson);
        }else if(exptititle == "Fresher") {
          this.expjson.push({type:exptititle})
          console.log(this.expjson);
        }
       
    }
    //end




    addAddress() {
        this.removebtn = true;
        this.contacts.push({
            id: this.contacts.length + 1,
            emgcontactperson: '',
            relationship: '',
            mobileNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
            phoneNumber: '',
            whatsappNumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
            emailAddress: '',
            faxNumber: '',
            alternativemobile: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]]
          });
      }
    
      removeAddress(i: number) {
        this.contacts.splice(i, 1);
      }

      //step4
      // this.educatinForm
      changeHighestQualification(e){
        this.onbordingform = this.verticalStepperForm.value;
        this.qualification = this.onbordingform.step4;
        var changedHighestQualification = e;
        if(changedHighestQualification == 'Professional'){
            this.verticalStepperForm.patchValue({step4: {pro_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_city: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_state: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_degree: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_achievements: ""}})
             this.verticalStepperForm.patchValue({step4: {highersec_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_achievements: "null"}})

            //
            //
          this.professional = true;
          this.pg = false;
          this.ug = false;
          this.highersecondary = true;
          this.highschool = true;
          //
          this.others_education=true;
          this.professional_education=true;
          this.pg_education=false;
          this.ug_education=false;
          this.highersecondary_education=false;
          this.higherschool_education=false;
          
          //
        }else if(changedHighestQualification == 'PG'){
          this.verticalStepperForm.patchValue({step4: {pg_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_city: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_state: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_degree: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {pg_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_achievements: "null"}})
            
          this.professional = false;
          this.pg = true;
          this.ug = false;
          this.highersecondary = true;
          this.highschool = true;
          //
          this.others_education=true;
          this.professional_education=false;
          this.pg_education=true;
          this.ug_education=false;
          this.highersecondary_education=false;
          this.higherschool_education=false;
          //
        }else if(changedHighestQualification == 'UG'){
          this.verticalStepperForm.patchValue({step4: {ug_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_city: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_state: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_degree: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {ug_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_achievements: "null"}})

          this.professional = false;
          this.pg = false;
          this.ug = true;
          this.highersecondary = true;
          this.highschool = true;
          //
          this.others_education=true;
          this.professional_education=false;
          this.pg_education=false;
          this.ug_education=true;
          this.highersecondary_education=false;
          this.higherschool_education=false;
          //
        }else if(changedHighestQualification == 'Higher Secondary'){
          this.verticalStepperForm.patchValue({step4: {highersec_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highersec_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_achievements: "null"}})
            
          this.professional = false;
          this.pg = false;
          this.ug = false;
          this.highersecondary = true;
          this.highschool = true;
          //
          this.others_education=true;
          this.professional_education=false;
          this.pg_education=false;
          this.ug_education=false;
          this.highersecondary_education=true;
          this.higherschool_education=false;
          //
        }else if(changedHighestQualification == 'High School'){
          this.verticalStepperForm.patchValue({step4: {highschool_institutionname: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_professional: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_city: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_state: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_major: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_measuretype: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_marks: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_startdate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_enddate: ""}})
            this.verticalStepperForm.patchValue({step4: {highschool_achievements: ""}})
            this.verticalStepperForm.patchValue({step4: {pro_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_major: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_achievements: "null"}})


          this.professional = false;
          this.pg = false;
          this.ug = false;
          this.highersecondary = false;
          this.highschool = true;
          //
          this.others_education=true;
          this.professional_education=false;
          this.pg_education=false;
          this.ug_education=false;
          this.highersecondary_education=false;
          this.higherschool_education=true;
          //
        }else if(changedHighestQualification == 'Other Qualification'){
            this.verticalStepperForm.patchValue({step4: {pro_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pro_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {pg_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_degree: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {ug_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_major: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {highersec_achievements: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_institutionname: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_professional: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_city: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_state: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_major: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_measuretype: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_marks: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_startdate: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_enddate: "null"}})
            this.verticalStepperForm.patchValue({step4: {highschool_achievements: "null"}})
          this.professional = false;
          this.pg = false;
          this.ug = false;
          this.highersecondary = false;
          this.highschool = false;
          //
          this.others_education=true;
          //
        }
      }

      //step3 info submit
    educationinfo(){
        this.onbordingform = this.verticalStepperForm.value;
        this.qualification = this.onbordingform.step4;
        var subhigherqual=this.qualification.highestqualification;
        if(subhigherqual =="Professional"){
          this.educjson = [];
          this.educjson.push({degmark:this.qualification.pro_marks,degname:this.qualification.pro_degree,enddate:this.qualification.pro_enddate.replaceAll("-","/"),instcity:this.qualification.pro_city,instname:this.qualification.pro_institutionname,inststate:this.qualification.pro_state,startdate:this.qualification.pro_startdate.replaceAll("-","/"),degmarktype:this.qualification.pro_measuretype,instcategory:this.qualification.pro_professional,degachievements:this.qualification.pro_achievements})
          this.educjson.push({degmark:this.qualification.highersec_marks,degname:this.qualification.highersec_major,enddate:this.qualification.highersec_enddate.replaceAll("-","/"),instcity:this.qualification.highersec_city,instname:this.qualification.highersec_institutionname,inststate:this.qualification.highersec_state,startdate:this.qualification.highersec_startdate.replaceAll("-","/"),degmarktype:this.qualification.highersec_measuretype,instcategory:this.qualification.highersec_professional,degachievements:this.qualification.highersec_achievements})
          this.educjson.push({degmark:this.qualification.highschool_marks,degname:this.qualification.highschool_major,enddate:this.qualification.highschool_enddate.replaceAll("-","/"),instcity:this.qualification.highschool_city,instname:this.qualification.highschool_institutionname,inststate:this.qualification.highschool_state,startdate:this.qualification.highschool_startdate.replaceAll("-","/"),degmarktype:this.qualification.highschool_measuretype,instcategory:this.qualification.highschool_professional,degachievements:this.qualification.highschool_achievements})
          this.educjson.push({highest_qualification:subhigherqual})
          console.log(this.educjson);
        }else if(subhigherqual =="UG"){
          this.educjson = [];
          this.educjson.push({degmark:this.qualification.ug_marks,degname:this.qualification.ug_degree,enddate:this.qualification.ug_enddate.replaceAll("-","/"),instcity:this.qualification.ug_city,instname:this.qualification.ug_institutionname,inststate:this.qualification.ug_state,startdate:this.qualification.ug_startdate.replaceAll("-","/"),degmarktype:this.qualification.ug_measuretype,instcategory:this.qualification.ug_professional,degachievements:this.qualification.ug_achievements})
          this.educjson.push({degmark:this.qualification.highersec_marks,degname:this.qualification.highersec_major,enddate:this.qualification.highersec_enddate.replaceAll("-","/"),instcity:this.qualification.highersec_city,instname:this.qualification.highersec_institutionname,inststate:this.qualification.highersec_state,startdate:this.qualification.highersec_startdate.replaceAll("-","/"),degmarktype:this.qualification.highersec_measuretype,instcategory:this.qualification.highersec_professional,degachievements:this.qualification.highersec_achievements})
          this.educjson.push({degmark:this.qualification.highschool_marks,degname:this.qualification.highschool_major,enddate:this.qualification.highschool_enddate.replaceAll("-","/"),instcity:this.qualification.highschool_city,instname:this.qualification.highschool_institutionname,inststate:this.qualification.highschool_state,startdate:this.qualification.highschool_startdate.replaceAll("-","/"),degmarktype:this.qualification.highschool_measuretype,instcategory:this.qualification.highschool_professional,degachievements:this.qualification.highschool_achievements})
          this.educjson.push({highest_qualification:subhigherqual})
          console.log(this.educjson);
          
        }else if(subhigherqual =="PG"){
          this.educjson = [];
          this.educjson.push({degmark:this.qualification.pg_marks,degname:this.qualification.pg_degree,enddate:this.qualification.pg_enddate.replaceAll("-","/"),instcity:this.qualification.pg_city,instname:this.qualification.pg_institutionname,inststate:this.qualification.pg_state,startdate:this.qualification.pg_startdate.replaceAll("-","/"),degmarktype:this.qualification.pg_measuretype,instcategory:this.qualification.pg_professional,degachievements:this.qualification.pg_achievements})
          this.educjson.push({degmark:this.qualification.highersec_marks,degname:this.qualification.highersec_major,enddate:this.qualification.highersec_enddate.replaceAll("-","/"),instcity:this.qualification.highersec_city,instname:this.qualification.highersec_institutionname,inststate:this.qualification.highersec_state,startdate:this.qualification.highersec_startdate.replaceAll("-","/"),degmarktype:this.qualification.highersec_measuretype,instcategory:this.qualification.highersec_professional,degachievements:this.qualification.highersec_achievements})
          this.educjson.push({degmark:this.qualification.highschool_marks,degname:this.qualification.highschool_major,enddate:this.qualification.highschool_enddate.replaceAll("-","/"),instcity:this.qualification.highschool_city,instname:this.qualification.highschool_institutionname,inststate:this.qualification.highschool_state,startdate:this.qualification.highschool_startdate.replaceAll("-","/"),degmarktype:this.qualification.highschool_measuretype,instcategory:this.qualification.highschool_professional,degachievements:this.qualification.highschool_achievements})
          this.educjson.push({highest_qualification:subhigherqual})
          console.log(this.educjson);

        }else if(subhigherqual =="Higher Secondary"){
          this.educjson = [];
          this.educjson.push({degmark:this.qualification.highersec_marks,degname:this.qualification.highersec_major,enddate:this.qualification.highersec_enddate.replaceAll("-","/"),instcity:this.qualification.highersec_city,instname:this.qualification.highersec_institutionname,inststate:this.qualification.highersec_state,startdate:this.qualification.highersec_startdate.replaceAll("-","/"),degmarktype:this.qualification.highersec_measuretype,instcategory:this.qualification.highersec_professional,degachievements:this.qualification.highersec_achievements})
          this.educjson.push({degmark:this.qualification.highschool_marks,degname:this.qualification.highschool_major,enddate:this.qualification.highschool_enddate.replaceAll("-","/"),instcity:this.qualification.highschool_city,instname:this.qualification.highschool_institutionname,inststate:this.qualification.highschool_state,startdate:this.qualification.highschool_startdate.replaceAll("-","/"),degmarktype:this.qualification.highschool_measuretype,instcategory:this.qualification.highschool_professional,degachievements:this.qualification.highschool_achievements})
          this.educjson.push({highest_qualification:subhigherqual})
          console.log(this.educjson);

        }else if(subhigherqual =="High School"){
          this.educjson = [];
          this.educjson.push({degmark:this.qualification.highschool_marks,degname:this.qualification.highschool_major,enddate:this.qualification.highschool_enddate.replaceAll("-","/"),instcity:this.qualification.highschool_city,instname:this.qualification.highschool_institutionname,inststate:this.qualification.highschool_state,startdate:this.qualification.highschool_startdate.replaceAll("-","/"),degmarktype:this.qualification.highschool_measuretype,instcategory:this.qualification.highschool_professional,degachievements:this.qualification.highschool_achievements})
          this.educjson.push({highest_qualification:subhigherqual})
          console.log(this.educjson);
        }else if(subhigherqual =="Other Qualification"){
          this.educjson = [];
          this.educjson.push({highest_qualification:subhigherqual})
          console.log(this.educjson);
        }
    }

//document upload
panUpload(){
  if(localStorage.getItem('aadhaaruploadfile')){
    if(localStorage.getItem('aadhaaruploadfile') == "success"){
      this.onbordingform = this.verticalStepperForm.value;
      this.documentsdetails = this.onbordingform.step6;
      if(this.documentsdetails.panfile._files[0]){
      var panfile = this.documentsdetails.panfile._files[0];
      this.panspinner=true;
      let input = new FormData();
      input = new FormData();
      input.append("process", "DocumentUpload");
      input.append("request","encrypt");
      input.append("document_type","pan");
      input.append("bid", localStorage.getItem('feedpagebid'));
      input.append("gid",localStorage.getItem('feedpagegid'));
      input.append("file",panfile);
      input.append("module","hronboarding");
      this.userService.feedsimageupload(input)
      .subscribe((res) =>{
        this.panupload = res;
        if(this.panupload){
          if(this.panupload.status == true && this.panupload.message == "Document Uploaded successfully"){
        localStorage.setItem('panuploadfile',"success");
          }
        }
        this.panspinner=false;
      })
    }
    }else{
      alert("please wait a moment upload aadhaar first");
    }
  }else{
    alert("please upload aadhar");
  }
}
aadharUpload(){
    this.onbordingform = this.verticalStepperForm.value;
    this.documentsdetails = this.onbordingform.step6;
    var aadhaarfile = this.documentsdetails.aadhaarfile._files[0];
    this.aadhaarspinner=true;
    let input = new FormData();
    input = new FormData();
    input.append("process", "DocumentUpload");
    input.append("request","encrypt");
    input.append("document_type","aadhaar");
    input.append("bid", localStorage.getItem('feedpagebid'));
    input.append("gid",localStorage.getItem('feedpagegid'));
    input.append("file",aadhaarfile);
    input.append("module","hronboarding");
    this.userService.feedsimageupload(input)
    .subscribe((res) =>{
      this.aadhaarupload = res;
      if(this.aadhaarupload){
        if(this.aadhaarupload.status == true && this.aadhaarupload.message == "Document Uploaded successfully"){
          localStorage.setItem('aadhaaruploadfile',"success");
        }
      }
      this.aadhaarspinner=false;
    })
}
resumeUpload(){
  if(localStorage.getItem('aadhaaruploadfile') && localStorage.getItem('panuploadfile')){
    if(localStorage.getItem('panuploadfile') == "success" && localStorage.getItem('panuploadfile') == "success"){
    this.onbordingform = this.verticalStepperForm.value;
    this.documentsdetails = this.onbordingform.step6;
    var resumefile = this.documentsdetails.resume._files[0];
    this.resumespinner=true;
    let input = new FormData();
    input = new FormData();
    input.append("process", "DocumentUpload");
    input.append("request","encrypt");
    input.append("document_type","resume");
    input.append("bid", localStorage.getItem('feedpagebid'));
    input.append("gid",localStorage.getItem('feedpagegid'));
    input.append("file",resumefile);
    input.append("module","hronboarding");
    this.userService.feedsimageupload(input)
    .subscribe((res) =>{
      this.resumeupload = res;
      if(this.resumeupload){
        if(this.resumeupload.status == true && this.resumeupload.message == "Document Uploaded successfully"){
          localStorage.setItem('resumeuploadfile',"success");
        }
      }
      this.resumespinner=false;
    })
  }else{
    alert("please wait a moment upload aadhaar first");
  }
}else{
  alert("please upload aadhar and pan documents");
}
}
educationUpload(){
  if(localStorage.getItem('aadhaaruploadfile') && localStorage.getItem('panuploadfile') && localStorage.getItem('resumeuploadfile') ){
    if(localStorage.getItem('panuploadfile') == "success" && localStorage.getItem('panuploadfile') == "success" && localStorage.getItem('resumeuploadfile') == "success"){
  this.onbordingform = this.verticalStepperForm.value;
  this.documentsdetails = this.onbordingform.step6;
  this.qualification = this.onbordingform.step4;
  var subhigherqual=this.qualification.highestqualification;
  this.alleducationfiles = [];
  if(subhigherqual =="Professional"){
    var profcertificate=[];
    var higerseccertificate=[];
    var highschoolcertificate=[];
    profcertificate.push(this.documentsdetails.pro_certificate._files[0]);
    higerseccertificate.push(this.documentsdetails.higersec_certificate._files[0]);
    highschoolcertificate.push(this.documentsdetails.highschool_certificate._files[0]);
    this.allproffiles = [...profcertificate,...higerseccertificate,...highschoolcertificate];
    this.educationspinner=true;
    if(this.allproffiles.length==3){
      for(var i=0;i<this.allproffiles.length;i++){
        var input = new FormData();
        input = new FormData();
        input.append("process", "DocumentUpload");
        input.append("request","encrypt");
        input.append("document_type","education");
        input.append("bid", localStorage.getItem('feedpagebid'));
        input.append("gid",localStorage.getItem('feedpagegid'));
        input.append("file",this.allproffiles[i]);
        input.append("module","hronboarding");
        this.userService.feedsimageupload(input)
        .subscribe((res) =>{
          var profdocupload = res;
          this.alleducationfiles.push(profdocupload);
          if(this.alleducationfiles){
            // if(this.alleducationfiles.status == true && this.alleducationfiles.message == "Document Uploaded successfully"){
              localStorage.setItem('alleducationfilesupload',"success");
            // }
          }
          this.educationspinner=false;
        })
      }
    }else{
      alert("please upload 3 files");
    }
  }else if(subhigherqual =="PG"){
    var pgcertificate=[];
    var higerseccertificate=[];
    var highschoolcertificate=[];
    pgcertificate.push(this.documentsdetails.pg_certificate._files[0]);
    higerseccertificate.push(this.documentsdetails.higersec_certificate._files[0]);
    highschoolcertificate.push(this.documentsdetails.highschool_certificate._files[0]);
    this.allpgfiles = [...pgcertificate,...higerseccertificate,...highschoolcertificate];
    this.educationspinner=true;
    if(this.allpgfiles.length==3){
      var expfiles = [];
      for(var i=0;i<this.allpgfiles.length;i++){
        var input = new FormData();
        input = new FormData();
        input.append("process", "DocumentUpload");
        input.append("request","encrypt");
        input.append("document_type","education");
        input.append("bid", localStorage.getItem('feedpagebid'));
        input.append("gid",localStorage.getItem('feedpagegid'));
        input.append("file",this.allpgfiles[i]);
        input.append("module","hronboarding");
        this.userService.feedsimageupload(input)
        .subscribe((res) =>{
          var pgdocupload = res;
          this.alleducationfiles.push(pgdocupload);
          if(this.alleducationfiles){
            // if(this.alleducationfiles.status == true && this.alleducationfiles.message == "Document Uploaded successfully"){
              localStorage.setItem('alleducationfilesupload',"success");
            // }
          }
          this.educationspinner=false;
        })
      }
    }else{
      alert("please upload 3 documents");
    }
  }else if(subhigherqual =="UG"){
    var ugcertificate=[];
    var higerseccertificate=[];
    var highschoolcertificate=[];
    ugcertificate.push(this.documentsdetails.ug_certificate._files[0]);
    higerseccertificate.push(this.documentsdetails.higersec_certificate._files[0]);
    highschoolcertificate.push(this.documentsdetails.highschool_certificate._files[0]);
    this.allugfiles = [...ugcertificate,...higerseccertificate,...highschoolcertificate];
    this.educationspinner=true;
    if(this.allugfiles.length==3){
      var expfiles = [];
      for(var i=0;i<this.allugfiles.length;i++){
        var input = new FormData();
        input = new FormData();
        input.append("process", "DocumentUpload");
        input.append("request","encrypt");
        input.append("document_type","education");
        input.append("bid", localStorage.getItem('feedpagebid'));
        input.append("gid",localStorage.getItem('feedpagegid'));
        input.append("file",this.allugfiles[i]);
        input.append("module","hronboarding");
        this.userService.feedsimageupload(input)
        .subscribe((res) =>{
          var ugdocupload = res;
          this.alleducationfiles.push(ugdocupload);
          if(this.alleducationfiles){
          //   if(this.alleducationfiles.status == true && this.alleducationfiles.message == "Document Uploaded successfully"){
              localStorage.setItem('alleducationfilesupload',"success");
          //   }
          }
          this.educationspinner=false;
        })
      }
    }else{
      alert("please upload 3 documents");
    }
  }else if(subhigherqual =="Higher Secondary"){
    var higerseccertificate=[];
    var highschoolcertificate=[];
    higerseccertificate.push(this.documentsdetails.higersec_certificate._files[0]);
    highschoolcertificate.push(this.documentsdetails.highschool_certificate._files[0]);
    this.allhighersecfiles = [...higerseccertificate,...highschoolcertificate];
    this.educationspinner=true;
    if(this.allhighersecfiles.length==2){
      var expfiles = [];
      for(var i=0;i<this.allhighersecfiles.length;i++){
        var input = new FormData();
        input = new FormData();
        input.append("process", "DocumentUpload");
        input.append("request","encrypt");
        input.append("document_type","education");
        input.append("bid", localStorage.getItem('feedpagebid'));
        input.append("gid",localStorage.getItem('feedpagegid'));
        input.append("file",this.allhighersecfiles[i]);
        input.append("module","hronboarding");
        this.userService.feedsimageupload(input)
        .subscribe((res) =>{
          var highersecdocupload = res;
          this.alleducationfiles.push(highersecdocupload);
          if(this.alleducationfiles){
            // if(this.alleducationfiles.status == true && this.alleducationfiles.message == "Document Uploaded successfully"){
              localStorage.setItem('alleducationfilesupload',"success");
            // }
          }
          this.educationspinner=false;
        })
      }
    }else{
      alert("please upload 2 Documents");
    }
  }else if(subhigherqual =="High School"){
    this.allhighschoolfiles=[];
    this.allhighschoolfiles.push(this.documentsdetails.highschool_certificate._files[0]);
    // this.allhighschoolfiles = [...highschoolcertificate];
    this.educationspinner=true;
      var input = new FormData();
      input = new FormData();
      input.append("process", "DocumentUpload");
      input.append("request","encrypt");
      input.append("document_type","education");
      input.append("bid", localStorage.getItem('feedpagebid'));
      input.append("gid",localStorage.getItem('feedpagegid'));
      input.append("file",this.documentsdetails.highschool_certificate._files[0]);
      input.append("module","hronboarding");
      this.userService.feedsimageupload(input)
      .subscribe((res) =>{
        var highschooldocupload = res;
        this.alleducationfiles.push(highschooldocupload);
        if(this.alleducationfiles){
          // if(this.alleducationfiles.status == true && this.alleducationfiles.message == "Document Uploaded successfully"){
            localStorage.setItem('alleducationfilesupload',"success");
          // }
        }
        this.educationspinner=false;
      })
  }
}else{
  alert("please wait a moment upload aadhaar first");
}
}else{
alert("please upload aadhar,pan and resume documents");
}
  
}
//education
experienceUpload(){
  // console.log(localStorage.getItem('aadhaaruploadfile'));
  // console.log(localStorage.getItem('panuploadfile'));
  // console.log(localStorage.getItem('resumeuploadfile'));
  // console.log(localStorage.getItem('alleducationfilesupload'));
  this.allexperience = [];
  this.allreaving = [];
  if(localStorage.getItem('aadhaaruploadfile') && localStorage.getItem('panuploadfile') && localStorage.getItem('resumeuploadfile') && localStorage.getItem('alleducationfilesupload') ){
    if(localStorage.getItem('aadhaaruploadfile') == "success" && localStorage.getItem('panuploadfile') == "success" && localStorage.getItem('resumeuploadfile') == "success" && localStorage.getItem('alleducationfilesupload') == "success"){
      var noofcomapnycount = this.getnoofcompany;
      this.getexpdocuments = this.experiencedocuments.value;
      var getdocuments = this.getexpdocuments.expdocument;
      // if(noofcomapnycount >0){
        var expdocuments = [];
        var releavingdocuments = [];
        for(var i=0;i<getdocuments.length;i++){
          expdocuments.push(getdocuments[i].experience._files[0]);
          releavingdocuments.push(getdocuments[i].relieving._files[0]);
          this.experiencespinner=true;
          var input = new FormData();
          input = new FormData();
          input.append("process", "DocumentUpload");
          input.append("request","encrypt");
          input.append("document_type","experience");
          input.append("bid", localStorage.getItem('feedpagebid'));
          input.append("gid",localStorage.getItem('feedpagegid'));
          input.append("file",expdocuments[i]);
          input.append("module","hronboarding");
          this.userService.feedsimageupload(input)
          .subscribe((res) =>{
            this.allexperience.push(res);
            if(this.allexperience){
              // if(this.expdocupload.status == true && this.expdocupload.message == "Document Uploaded successfully"){
                localStorage.setItem('expdocuploadfiles',"success");
              // }
            }
            this.experiencespinner=false;
          })
          //
          this.experiencespinner=true;
          var input = new FormData();
          input = new FormData();
          input.append("process", "DocumentUpload");
          input.append("request","encrypt");
          input.append("document_type","relieving");
          input.append("bid", localStorage.getItem('feedpagebid'));
          input.append("gid",localStorage.getItem('feedpagegid'));
          input.append("file",releavingdocuments[i]);
          input.append("module","hronboarding");
          this.userService.feedsimageupload(input)
          .subscribe((res) =>{
            this.allreaving.push(res);
            if(this.allreaving){
              // if(this.reldocupload.status == true && this.reldocupload.message == "Document Uploaded successfully"){
                localStorage.setItem('reldocuploadfiles',"success");
              // }
            }
            this.experiencespinner=false;
          })
        }
      // }
    }else{
      alert("please wait a moment upload aadhaar first");
    }
    }else{
    alert("please upload aadhar,pan,resume and education documents");
    }
}
//document upload end
    documentinfo(){
      // this.educationUpload();
      this.finalexperiencedocs=[];
      this.finaleducationdocs=[];
      this.finalpanaadhaar=[];
      this.finalexpletter=[];
      this.finalrelievingletter=[];
      this.finalresume = [];
      var currenttimestamp = new Date().toISOString();
      this.onbordingform = this.verticalStepperForm.value;
      this.documentsdetails = this.onbordingform.step6;
      var panaadhaardatacheck={};
      //pan and aadhaar
        var pan = {
            "path": this.panupload, 
            "status": 0, 
            "updateby": localStorage.getItem('gid'), 
            "updateon": currenttimestamp, 
            "createdon": currenttimestamp
        }
        var aadhaar = {
          "path": this.aadhaarupload, 
          "status": 0, 
          "updateby": localStorage.getItem('gid'), 
          "updateon": currenttimestamp, 
          "createdon": currenttimestamp
        }
        this.pan = pan;
        this.aadhaar = aadhaar;
        // var document = {pan,aadhaar}
        // this.finalpanaadhaar.push({document:document});
        
        panaadhaardatacheck = {pan,aadhaar};
        this.finalpanaadhaar = {document:panaadhaardatacheck}
      //agreements
      var resumedatacheck={};
      var resume = {
        "path": this.resumeupload, 
        "status": 0, 
        "updateby": localStorage.getItem('gid'), 
        "updateon": currenttimestamp, 
        "createdon": currenttimestamp
      }
      // var agreements = {resume}
      // this.finalresume.push({agreements:agreements});
      resumedatacheck = resume;
      this.finalresume = {agreements:resumedatacheck}
      //agreements end
//education
      if(this.alleducationfiles){
        var educationdatacheck={};
        for(var i=0;i<this.alleducationfiles.length;i++){
          var value = 'edu'+ i;
          var valuess = {
              "path": this.alleducationfiles[i], 
              "status": 0, 
              "updateby": localStorage.getItem('gid'), 
              "updateon": currenttimestamp, 
              "createdon": currenttimestamp
              }
          // var education = {[value]:valuess}
          // this.finaleducationdocs.push({education:education});
          educationdatacheck[value] = valuess;
        }
        this.finaleducationdocs = {education:educationdatacheck}
      }

      //experience
      
      // this.getexpdocuments = this.experiencedocuments.value;
      if(this.allexperience){
      // var getexperiencedocuments = this.getexpdocuments.expdocument;
      // var files = getexperiencedocuments[0].experience._files;
      var expdatacheck={};
      for(var i=0;i<this.allexperience.length;i++){
        var expvalue = 'exp'+ i;
        var expvaluess = {
            "path": this.allexperience[i], 
            "status": 0, 
            "updateby": localStorage.getItem('gid'), 
            "updateon": currenttimestamp, 
            "createdon": currenttimestamp
            }
        expdatacheck[expvalue] = expvaluess;
      }
      this.finalexpletter = {experience:expdatacheck}
    }
      //experience doc end
      //relieving doc
      if(this.allreaving){
      var reldatacheck={};
      for(var i=0;i<this.allreaving.length;i++){
        var expvalue = 'rev'+ i;
        var expvaluess = {
            "path": this.allreaving[i], 
            "status": 0, 
            "updateby": localStorage.getItem('gid'), 
            "updateon": currenttimestamp, 
            "createdon": currenttimestamp
            }
        // var relieving = {[expvalue]:expvaluess}
        // this.finalrelievingletter.push({relieving:relieving});
        reldatacheck[expvalue] = expvaluess;
      }
      this.finalrelievingletter = {relieving:reldatacheck}
      }
      //relieving doc end
      //experience end

      //education
      // this.getexpdocuments = this.experiencedocuments.value;
      // console.log(this.getexpdocuments)
      
      // console.log(getdocuments)
      
    }
    
      allDone(){
        var subhigherqual=this.qualification.highestqualification;
        if(subhigherqual =="Other Qualification"){
          this.educjson=Object.assign({
              "applicanteducation":subhigherqual
          });
          console.log(this.educjson)
        }
        // var alldocumentvalue = [...this.finalpanaadhaar,...this.finaleducationdocs,...this.finalrelievingletter,...this.finalresume,...this.finalexpletter];
        var alldocumentvalue = Object.assign(this.finalpanaadhaar,this.finaleducationdocs,this.finalrelievingletter,this.finalresume,this.finalexpletter);
        var currenttimedate = this.datePipe.transform(new Date(),"y-MM-d H:mm:ss");
        var showbid = parseInt(localStorage.getItem('bid'));
        var showgid = parseInt(localStorage.getItem('gid'));
        const postData = {
          request:"onboarding",
          "bid":showbid,
          "gid":showgid,
          "applicantinformation":this.basicinfo,
          "applicantaddress":this.empaddressinfo,
          "applicantcontact":this.contactjson,
          "applicanteducation":this.educjson,
          "applicantexperience":this.expjson,
          "nda":0,
          "aadhar":0,
          "pan":0,
          "status":0,
          "created_by":showgid,
          "created_on":currenttimedate,
          "updated_by":showgid,
          "updated_on":currenttimedate,
          "applicantdocuments":alldocumentvalue
        }
        console.log(postData)
        this.userService.beginonboarding(postData)
        .subscribe((res) =>{
          console.log(res)
          if(res.status == '1'){
            alert('Data Inserted Successfully');
          }else if(res.status == '0'){
            alert('Already Exist');
          }
        })
      }
     
}
