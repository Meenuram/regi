import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit, Inject,ElementRef ,HostListener } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { Router,ActivatedRoute } from '@angular/router';
import { TeamComponent } from 'app/modules/admin/ui/content-layouts/common/demo-content/team.component';
import { ModernLayoutComponent } from 'app/layout/layouts/horizontal/modern/modern.component';
import {FormsLayoutsComponent} from 'app/modules/admin/ui/forms/layouts/layouts.component';
import { UtilityService } from 'app/shared/services/utility.service';
import { DatePipe } from '@angular/common';
import * as _ from 'underscore';
import { environment } from 'environments/environment';
import { FormControl, FormGroup ,FormBuilder,Validators } from '@angular/forms';

@Component({
    selector       : 'profile',
    templateUrl    : './profile.component.html',
    styleUrls      : ['./profile.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class ProfileComponent implements OnInit{
    leftscrollvalue:any;
    @HostListener("window:scroll", ["$event"])
    onWindowScroll() {
        // console.log('hai'+document.documentElement.scrollTop)
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
     if(pos == max )   {
     //Do your action here
     }
        if (document.documentElement.scrollTop > 370) {
            this.leftscrollvalue = "abcd" ;
        } else {
            this.leftscrollvalue = "" ;
        }
    }
    /**
     * Constructor
     */
     userProfile :any;
     userTeam : any;
     following:any;
     userfollowingTeam : any;
    usertotalemp : any;
    useratoff : any;
    usernotoff : any;
     public data:any=[];
     userSession:any;
     UserTeamimage:any;
     userimgs:any;
     dataCheck:any;
     allMemberTeams: any;
     teammebergid:any;
     userid:any;
     leaveapproval:any;
     department:any;
     branch:any;
     dob:any;
     AddressLine2:any;
     Mobile:any;
     adress:any;
     MyShift:any;
     profilecredit:any;
   // storage: any;
   userTeam11:any;
   myteammember:any;
   myTeamsMember:any;
   

   userTeamMember:any;
   gettopsales:any;
   first_date:any;
   current_date:any;
   yesterday:any;
   support:any;
   sendotpmobile:any;
   personalsendotp:any;
   otpverifyform:any;
   personalnumber:any;
   officialnumber:any;
   otpvarification:any;
   mobileverified:any;
   verifiedstatus:any;
   //
   salaryDatas:any;
    salaryleaves:any;
    salaryattendance:any;
    salarykeyvalues:any;
    salaryctcbreakup:any;
    salaryunset:any;
    salarydeductions:any;
    daysworked:any;
    sundays:any;
    holiday:any;
    totalleaves:any;
    paidleave:any;
    unpaidleaves:any;
    monthlyctc:any;
    grossbasics:any;
    earnings:any;
    salarypaiddeductions:any;
    netpay:any;
    ctcbreak:any;
    netpayable:any;
    monthlybasic:any;
    mbhouserent:any;
    mbmediacal:any;
    mbconveyence:any;
    mbtotal:any;
    monthearning:any;
    earninghra:any;
    earningmedical:any;
    earningconveyance:any;
    earningtotals:any;
    deductionpt:any;
    deductionvvpf:any;
    deductionvpf:any;
    deductionvesi:any;
    deductionvgmonthly:any;
    deductionvcumulative:any;
    deductionvmonthly:any;
    deductionvprept:any;
    deductionvtds:any;
    deductionvsecdeposit:any;
    deductionvintax:any;
    deductionvprotax:any;
    adddeductions:any;
    workingdays:any;
    deductiontotal:any;
    noofdays:any;
    prevmonth:any;
    paidsalaryyear:any;
    paidsalarymonth:any;
    leavenetpayable:any;
    paidunpaidLeaves:any;
   
    constructor(
        @Inject(SESSION_STORAGE) private storage: StorageService,public elementRef: ElementRef,private activatedRoute: ActivatedRoute,
    private userService:UserService,private router: Router,public util:UtilityService,private datePipe: DatePipe, private formBuilder: FormBuilder)
    {
        this.otpvarification = this.formBuilder.group({
            mobilenumber: [null, [ Validators.required ]],
            otp: [null, [ Validators.required ]]
        });
        this.util.profileHeader('hai');
    }
    
ngOnInit() { 
    this.activatedRoute.queryParams.subscribe(params => {
        var profilecheck_modal = atob(params['p']);
        // console.log(profilecheck_modal); // Print the parameter to the console. 
        if(profilecheck_modal=="profile_image"){
            // console.log("inside")
            this.util.crmupdateProfile('hai');
        }
    }); 

    var el = document.querySelector('div');

// get scroll position in px
    // console.log(el.scrollLeft, el.scrollTop);
    this.userid = localStorage.getItem('gid');
    localStorage.setItem('teammebergid',this.userid);
    this.teammebergid = localStorage.getItem('teammebergid');
    // this.userTeam = JSON.parse(localStorage.getItem("profileteamimage"));
    this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
    // localStorage.setItem("teamleadlist", JSON.stringify(res));
    this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    // this.myTeamsMember = setInterval(() => { 
    //     this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    //     if(this.UserTeamimage == null){
            
    //     }else{
    //         this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    //         this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
    //         clearInterval(this.myTeamsMember)
    //     }
    // },500);
    
    //salary
    var years = new Date().getFullYear();
    var month = new Date().getMonth()+1;
    this.noofdays = new Date(years, month, 0).getDate();
    var todaydate = new Date().toLocaleString();
    this.salaryDatas = JSON.parse(localStorage.getItem("salaryData"));
        
    if(this.salaryDatas){
        this.getSalaryDetails();
    }
    
    this.userProfile = JSON.parse(localStorage.getItem("myProfile"));
    // console.log(this.userProfile);
    this.userProfile = this.userProfile[0];
    // console.log(this.userProfile);
    // console.log( _.isArray(this.userProfile))
        this.department = this.userProfile.department;
        this.branch = this.userProfile.branch;
        this.dob = this.userProfile.dob;
        this.adress = this.userProfile.AddressLine2;
        this.Mobile = this.userProfile.Mobile;
        this.otpvarification.controls['mobilenumber'].setValue(this.Mobile);
        this.MyShift = this.userProfile.myshifttime;
        this.verifiedstatus = this.userProfile.isverified;
        if(this.verifiedstatus==1){
           this.mobileverified=true;
        }else{
            this.mobileverified=false;
        }
        // this.userService.getUserTeamimage()
        // .subscribe((res) =>{
        //     localStorage.setItem("teamimage",  JSON.stringify(res.data));
        //     this.UserTeamimage =  JSON.stringify(res.data);
        // }, err => {
        //     console.log('Error', err);
            
        // })
    
        this.getUserProfile();
        // //this.getUserTeamimageFunction();
        // this.getTeamImage();

        //topsales
        this.gettopsales = JSON.parse(localStorage.getItem("topthreesales"));
        // console.log(this.gettopsales)
        // this.gettopsales = [];
        var date = new Date(); 
        var firstDay = new Date(date.getFullYear(),date.getMonth(), 1);
        this.first_date = this.datePipe.transform(firstDay,"MMMM, yyyy");
        // this.current_date = this.datePipe.transform(salesdate,"MMMM d, yyyy");
        this.current_date = localStorage.getItem("salesdate");

        this.support=true;
        this.sendotpmobile=true;
        this.personalsendotp=true;
        this.personalnumber=true;
        this.officialnumber=true;
}


// getTeamImage(){
//     const postData = {
//         "bid":localStorage.getItem('bid'),
//         "empgid":localStorage.getItem('gid'),
//         "api-key":"steams"
//     };
//     this.userService.getProfileteam(postData)
//     .subscribe((res) =>{
//         this.ProfileTeamimage = res.data;
//         console.log(this.ProfileTeamimage);
//         localStorage.setItem("profileteamimage", JSON.stringify(this.ProfileTeamimage));
//     })
// }

getUserProfile() {
    const postData = {
        // "gid":usersession.gid,
        // "bid":usersession.bid,
        "gid":localStorage.getItem('gid'),
        "bid":localStorage.getItem('bid'),
        // "key":"getEmpData"
        "operation": btoa(localStorage.getItem('gid') + 'TXhfVjJ4amVHUXhTa2hTYWtKYVZWUXdPUT09'),
        // "secret": localStorage.getItem('secret')
        "secret": environment.ANOTHER_API_SECRET
        };
    this.userService.getUserProfile(postData)
    .subscribe((res) =>{
        localStorage.setItem('userimage', res.data[0].image);
        localStorage.setItem('myprofileimg', res.data[0].image);
        localStorage.setItem('name', res.data[0].name);
        localStorage.setItem('mydepartment', res.data[0].department);
        localStorage.setItem('myname', res.data[0].name);
        localStorage.setItem('mybranch', res.data[0].branch);
        localStorage.setItem('FatherName', res.data[0].FatherName);
        localStorage.setItem('Mobile', res.data[0].Mobile);
        localStorage.setItem('dob', res.data[0].dob);
        localStorage.setItem('personalemail', res.data[0].personalemail);
        localStorage.setItem('Gender', res.data[0].Gender);
        localStorage.setItem('MaritalStatus', res.data[0].MaritalStatus);
        localStorage.setItem('Nationality', res.data[0].Nationality);
        localStorage.setItem('LanguageKnown', res.data[0].LanguageKnown);
        localStorage.setItem('Blood', res.data[0].Blood);
        localStorage.setItem('aadhaar', res.data[0].aadhaar);
        localStorage.setItem('pan', res.data[0].pan);
        localStorage.setItem('AddressLine1', res.data[0].AddressLine1);
        localStorage.setItem('AddressLine2', res.data[0].AddressLine2);
        localStorage.setItem('ZipCode', res.data[0].ZipCode);
        localStorage.setItem('City', res.data[0].City);
        localStorage.setItem('State', res.data[0].State);
        localStorage.setItem('Country', res.data[0].Country);
        localStorage.setItem('employee_id', res.data[0].employee_id);
        localStorage.setItem('designation', res.data[0].designation);
        localStorage.setItem('doj', res.data[0].doj);
        localStorage.setItem('reporting_to', res.data[0].reporting_to);
        localStorage.setItem('extention', res.data[0].extention);
        localStorage.setItem('officeemail', res.data[0].officeemail);
        localStorage.setItem('personalmobile', res.data[0].personalmobile);
        localStorage.setItem('officemobile', res.data[0].officemobile);
        localStorage.setItem('shift', res.data[0].myshifttime);
        localStorage.setItem('branch', res.data[0].branch);
        localStorage.setItem('branch', res.data[0].branch);
        localStorage.setItem('accountnumber', res.data[0].accountnumber);
        localStorage.setItem('accountname', res.data[0].accountname);
        localStorage.setItem('bankname', res.data[0].bankname);
        localStorage.setItem('bankbranch', res.data[0].bankbranch);
        localStorage.setItem('ifsccode', res.data[0].ifsccode);
        localStorage.setItem('pfno', res.data[0].pfno);
        localStorage.setItem('uanno', res.data[0].uanno);
        localStorage.setItem('esino', res.data[0].esino);
        localStorage.setItem('following', res.following);
        localStorage.setItem('team', res.team.length);
        localStorage.setItem('teamgid', res.team.gid);
        
        this.userProfile = res.data;
        this.util.profileHeader('hai');
        // this.userTeam = res.team;
        localStorage.setItem('teampagevalues', JSON.stringify(res.team));
        this.userTeam11 = JSON.parse(localStorage.getItem('teampagevalues'));
        
        this.following = res.following;
        this.userfollowingTeam = res.followingarray;
        this.usertotalemp = res.totalEmp;
        this.useratoff = res.atoffc;
        this.usernotoff = res.notoffc;
        this.leaveapproval = res.approvals;
        localStorage.setItem("myProfile", JSON.stringify(this.userProfile));
        localStorage.setItem("leaveapproval", JSON.stringify(this.leaveapproval));
        
        localStorage.setItem("userimgssec", JSON.stringify(this.userimgs));
  

this.allMemberTeams = setInterval(() => { 
    this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    if(this.UserTeamimage){
        if(this.usertotalemp){
        for(var i=0;i<this.usertotalemp.length;i++){
            for(var j=0;j<this.UserTeamimage.length;j++){
                if(this.usertotalemp[i].gid == this.UserTeamimage[j].gid){
                    this.usertotalemp[i]['profileImg'] = this.UserTeamimage[j].image
                    this.usertotalemp[i]['gender'] = this.UserTeamimage[j].gender
                }
            }
         }
        }
        // console.log(this.usertotalemp)
         if(this.useratoff){
         for(var i=0;i<this.useratoff.length;i++){
             for(var j=0;j<this.UserTeamimage.length;j++){
                 if(this.useratoff[i].gid == this.UserTeamimage[j].gid){
                     this.useratoff[i]['profileImg'] = this.UserTeamimage[j].image
                     this.useratoff[i]['gender'] = this.UserTeamimage[j].gender
                 }
  
             }
          }
        }
        if(this.usernotoff){
          for(var i=0;i<this.usernotoff.length;i++){
             for(var j=0;j<this.UserTeamimage.length;j++){
                 if(this.usernotoff[i].gid == this.UserTeamimage[j].gid){
                     this.usernotoff[i]['profileImg'] = this.UserTeamimage[j].image
                     this.usernotoff[i]['gender'] = this.UserTeamimage[j].gender
                 }
  
             }
          }
        }
         localStorage.setItem("totalempls", JSON.stringify(this.usertotalemp));
         localStorage.setItem("atoffice", JSON.stringify(this.useratoff));
      localStorage.setItem("notoffice", JSON.stringify(this.usernotoff));
      clearInterval(this.allMemberTeams);
    }else{
       
    }
}, 500);


// localStorage.setItem("follweteam", JSON.stringify(this.userfollowingTeam));

// let myCompOneObj = new ModernLayoutComponent(null,null,null,null,null);
//     myCompOneObj.ChangeDoCheck();
        
    }, err => {
        console.log('Error', err);
        
    })
}

viewTeam(gid){
    //console.log(gid);
    localStorage.setItem("teammebergid", gid);
    // this.util.profileHeader('hai');
    this.router.navigate(['/ui/content-layouts/left-sidebar/fullheight/basic/team']);
    // let myCompOneObj = new TeamComponent(null,null,null);
    // myCompOneObj.hellofunction();   
}
teamsNAmeChange(names){
    var changedname = names.split(" ", 1);
    return changedname[0];
}

//salary
getSalaryDetails() {
    this.salaryDatas = JSON.parse(localStorage.getItem("salaryData"));
    // console.log(this.salaryDatas)
    this.salaryleaves = this.salaryDatas.leaves[0];
    if(this.salaryleaves){
    this.totalleaves = this.salaryleaves.Total_No_of_Leaves_Taken;
    if(this.totalleaves == null){
        this.totalleaves = 'NA';
    }else{
        this.totalleaves = this.salaryDatas.Total_No_of_Leaves_Taken;
    }
    // console.log(this.salaryleaves.Paid_Leave, this.salaryleaves.Unpaid_Leaves)
    this.paidleave = this.salaryleaves.Paid_Leave;
    // if(this.paidleave == null || this.paidleave == 0){
    //     this.paidleave = 'NA';
    // }else{
    //     this.paidleave = this.salaryleaves.Paid_Leave;
    // }
    this.unpaidleaves = this.salaryleaves.Unpaid_Leaves;
    // if(this.unpaidleaves == null || this.unpaidleaves == 0){
    //     this.unpaidleaves = 'NA';
    // }else{
    //     this.unpaidleaves = this.salaryleaves.Unpaid_Leaves;
    // }
    if(this.paidleave == null && this.unpaidleaves == null){
        this.paidunpaidLeaves = "NA";   
    }else if(this.paidleave > 0 && this.unpaidleaves == 0){
        this.paidunpaidLeaves = Number(this.paidleave) + Number(0);
    }else if(this.paidleave == 0 && this.unpaidleaves > 0){
        this.paidunpaidLeaves = Number(0) + Number(this.unpaidleaves);
    }else if(this.paidleave == 0 && this.unpaidleaves == 0){
        this.paidunpaidLeaves = "NA";  
    }else{
        this.paidunpaidLeaves = Number(this.paidleave) + Number(this.unpaidleaves);
    }
    // console.log(this.paidunpaidLeaves)
   }

   //paid salary month and data
   this.paidsalarymonth = this.salaryDatas.month;
   this.paidsalaryyear = this.salaryDatas.year;
   if(this.paidsalarymonth == null && this.paidsalaryyear == null){
    this.prevmonth = "NA";
   }else{
    this.prevmonth = this.paidsalarymonth + " , " + this.paidsalaryyear;

   }
   


    this.monthlyctc = this.salaryDatas.ctctotal;
    if(this.monthlyctc == null){
        this.monthlyctc = 'NA';
    }else{
        this.monthlyctc = this.salaryDatas.ctctotal;
    }
    this.grossbasics = this.salaryDatas.grossbasic;
    if(this.grossbasics == null){
        this.grossbasics = 'NA';
    }else{
        this.grossbasics = this.salaryDatas.grossbasic;
    }
    this.earnings = this.salaryDatas.grosstotal;
    if(this.earnings == null){
        this.earnings = 'NA';
    }else{
        this.earnings = this.salaryDatas.grosstotal;
    }
    //this.deductions = this.salaryDatas.grossbasic;
    this.netpay = this.salaryDatas.payout;
    if(this.netpay == null){
        this.netpay = 'NA';
    }else{
        this.netpay = this.salaryDatas.payout;
    }

    this.salarypaiddeductions = this.salaryDatas.deductions[0];
    if(this.salarypaiddeductions == null){
        this.salarypaiddeductions = 'NA';
    }else{
        this.salarypaiddeductions = this.salaryDatas.deductions;
    }
    if(this.salarypaiddeductions){
    this.deductionpt = this.salarypaiddeductions.PT;
    this.deductionvvpf = this.salarypaiddeductions.VPF;
    this.deductionvpf = this.salarypaiddeductions.Employee_PF;
    this.deductionvesi = this.salarypaiddeductions.Employee_ESI;
    this.deductionvgmonthly = this.salarypaiddeductions.Gratuity_Monthly;
    this.deductionvcumulative = this.salarypaiddeductions.Gratuity_Cumulative;
    this.deductionvmonthly = this.salarypaiddeductions.SuperAnnuation_monthly;
    this.deductionvprept = this.salarypaiddeductions.prept;
    this.deductionvtds = this.salarypaiddeductions.TDS;
    this.deductionvsecdeposit = this.salarypaiddeductions.SECURITY_DEPOSIT;
    this.deductionvintax = this.salarypaiddeductions.Income_tax;
    this.deductionvprotax = this.salarypaiddeductions.Professional_Tax;
    }
   
    var deductionarr =  this.salaryDatas.deductions[0];
    // console.log(deductionarr)
    if(deductionarr){
    this.deductiontotal = 0;
    for (var key in deductionarr) {
        this.deductiontotal = Number(deductionarr[key]) + this.deductiontotal;
        // console.log(this.deductiontotal)
    };
}
if(this.deductiontotal == null){
    this.deductiontotal = 'NA';
}else{
    this.deductiontotal = this.deductiontotal;
}

    this.monthlybasic = this.salaryDatas.ctcbasic;
    if(this.monthlybasic == null){
        this.monthlybasic = 'NA';
    }else{
        this.monthlybasic = this.salaryDatas.ctcbasic;
    }
    this.monthearning = this.salaryDatas.grossbasic;
    if(this.monthearning == null){
        this.monthearning = 'NA';
    }else{
        this.monthearning = this.salaryDatas.grossbasic;
    }
    this.leavenetpayable = this.salaryDatas.netpayable;
    // console.log(this.leavenetpayable)
    if(this.leavenetpayable == null){
        this.leavenetpayable = 'NA';
    }else{
        this.leavenetpayable = this.salaryDatas.netpayable;
    }

    this.salaryattendance = this.salaryDatas.attendance[0];
    if(this.salaryattendance == null){
        this.salaryattendance = 'NA';
    }else{
        this.salaryattendance = this.salaryDatas.attendance[0];
    }
    if(this.salaryattendance){
    this.workingdays = this.salaryattendance.Working_Days_of_Company_Excluding_Sundays_Holidays;
    if(this.workingdays == null || this.workingdays == 0){
        this.workingdays = 'NA';
    }else{
        this.workingdays = this.salaryattendance.Working_Days_of_Company_Excluding_Sundays_Holidays;
    }
    this.daysworked = this.salaryattendance.Actual_Worked_Days_Paid_Leaves;
    if(this.daysworked == null){
        this.daysworked = 'NA';
    }else{
        this.daysworked = this.salaryattendance.Actual_Worked_Days_Paid_Leaves;
    }
    this.sundays = this.salaryattendance.Sundays_Holidays;
    if(this.sundays == null){
        this.sundays = 'NA';
    }else{
        this.sundays = this.salaryattendance.Sundays_Holidays;
    }
    this.holiday = this.salaryattendance.Holiday_Present;
    if(this.holiday == null){
        this.holiday = 'NA';
    }else{
        this.holiday = this.salaryattendance.Holiday_Present;
    }
    }
    this.netpayable = this.daysworked == null? 0 : this.daysworked;
    this.netpayable = Number(this.netpayable) + Number(this.sundays) + Number(this.holiday);

    this.salarykeyvalues = this.salaryDatas.keyvalues;

    this.salaryctcbreakup = this.salaryDatas.ctcbreakup[0];
    if(this.salaryctcbreakup == null){
        this.salaryctcbreakup = [];
    }
    // console.log(this.salaryctcbreakup);
    // var salaryctcbreakup = this.salaryDatas.ctcbreakup;
    if(this.salaryctcbreakup){

    this.ctcbreak = this.salaryctcbreakup.ESI_total;
    if(this.ctcbreak == null){
        this.ctcbreak = 'NA';
    }else{
        this.ctcbreak = this.salaryctcbreakup.ESI_total;
    }
    this.mbhouserent = this.salaryctcbreakup.Hra;
    if(this.mbhouserent == null){
        this.mbhouserent = 'NA';
    }else{
        this.mbhouserent = this.salaryctcbreakup.Hra;
    }
    this.mbmediacal = this.salaryctcbreakup.MedicalInsurance;
    if(this.mbmediacal == null){
        this.mbmediacal = 'NA';
    }else{
        this.mbmediacal = this.salaryctcbreakup.MedicalInsurance;
    }
    this.mbconveyence = this.salaryctcbreakup.ConveyanceAllowance;
    if(this.mbconveyence == null){
        this.mbconveyence = 'NA';
    }else{
        this.mbconveyence = this.salaryctcbreakup.ConveyanceAllowance;
    }
    this.mbtotal = this.salaryctcbreakup.CTC_Per_Month;
    if(this.mbtotal == null){
        this.mbtotal = 'NA';
    }else{
        this.mbtotal = this.salaryctcbreakup.CTC_Per_Month;
    }
    }

    this.salaryunset = this.salaryDatas.unset;

    this.salarydeductions = this.salaryDatas.grossearnings[0];
    if(this.salarydeductions == null){
        this.salarydeductions = 'NA';
    }else{
        this.salarydeductions = this.salaryDatas.grossearnings[0];
    }

    if(this.salarydeductions){
    this.earninghra = this.salarydeductions.Hra;
    if(this.earninghra == null){
        this.earninghra = 'NA';
    }else{
        this.earninghra = this.salarydeductions.Hra;
    }
    this.earningmedical = this.salarydeductions.MedicalAllowance;
    if(this.earningmedical == null){
        this.earningmedical = 'NA';
    }else{
        this.earningmedical = this.salarydeductions.MedicalAllowance;
    }
    this.earningconveyance = this.salarydeductions.ConveyanceAllowance;
    if(this.earningconveyance == null){
        this.earningconveyance = 'NA';
    }else{
        this.earningconveyance = this.salarydeductions.ConveyanceAllowance;
    }
    this.earningtotals = this.salarydeductions.GrossTotal;
    if(this.earningtotals == null){
        this.earningtotals = 'NA';
    }else{
        this.earningtotals = this.salarydeductions.GrossTotal;
    }
    }
}

mobileUpdate(){
    this.support=false;
}
supportSave(){

}
sendotp(){
    this.sendotpmobile=false;
}
sendotppersonal(){
    this.personalsendotp=false;
    const postData = {
        "operation":"mobUpdate",
        "module":"otp", 
        "mobile":this.otpvarification.get('mobilenumber').value,
        "bid": localStorage.getItem('bid'),
        "gid": localStorage.getItem('gid')
     };
     this.userService.otpcheck(postData)
        .subscribe((res) =>{
            var result = res;
        });
}
saveotp(){
    const postData = {
        "operation":"mobUpdate",
        "module":"verify",
        "mobile":this.otpvarification.get('mobilenumber').value,
        "bid": localStorage.getItem('bid'),
        "gid": localStorage.getItem('gid'),
        "otp":this.otpvarification.get('otp').value
     };
     this.userService.otpcheck(postData)
        .subscribe((res) =>{
            var result = res.status;
            if(result==1){
                alert("Update Successfully");
            }else{
                alert("error");
            }
        });
}
closeform(){
    this.support=true;
}
editmobile(){
    this.personalnumber=false;
}
editofficial(){
    this.officialnumber=false;
}
closebutton(){
    this.otpverifyform.back();
}
eqlcardpage(){
    window.open("https://app.ledgers.cloud/m/app/module/?m=eql", "_blank");
}
// publicwall(){
//     window.open("/#/pages/publicwall", "_blank");
// }

}
