import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Subject, Observable } from 'rxjs';
import { UserService } from 'app/shared/services/user.service';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
  selector: 'wfh-modal',
  templateUrl: './wfh-modal.component.html',
  styleUrls: ['./wfh-modal.component.scss']
})
export class WfhModalComponent implements OnInit {
  wfhcheckin:any;
  getchecktype:any;
  getbuttonvalue:boolean=false;
  userwebcam:boolean;
  myprofileimg:any;
  fileToUpload: any;
  imageUrl: any;

  webcamSrc:any;
  fileSrc:any;

  imgTag:any;
  paraTag:any;

  imgcroperDiv:any;
  dropzoneDiv:any;
  iconDiv:any;

  imageChangedEvent: any = '';
  croppedImage: any = '';
  imageResult:any;


  activeColor: string = "green";
  baseColor: string = "#ccc";
  overlayColor: string = "rgba(255,255,255,0.5)";

  dragging: boolean = false;
  loaded: boolean = false;
  imagetagLoaded: boolean = false;
  imageSrc: string = "";
  constructor(private userService:UserService,public dialogRef: MatDialogRef<WfhModalComponent>,public util:UtilityService) { 
    
  }

    

  ngOnInit(): void {
    this.getchecktype = localStorage.getItem('checkintype');
    // if (this.getchecktype == 'checkin'){
    //   this.getbuttonvalue = true;
    // } else if (this.getchecktype == 'checkout') {
    //   this.getbuttonvalue = false;
    // }
  }

  
  acceptCheckin(){
    if (this.getchecktype == 'checkin'){
        const postData = {
          "gid":localStorage.getItem('gid'),
          "event":"CheckIn",
          "operation":"acceptcheckin"
        }
        this.userService.wfhpolicy(postData)
            .subscribe((res) =>{
              console.log(res)
              var wfhcheckin = res;
              if(wfhcheckin.status == '1'){
                alert('Checkin accepted successfully');
                window.location.reload();
              }else if (wfhcheckin.status == '0'){
                alert('unauthorized access');
                window.location.reload();
              }
            })
      } else if (this.getchecktype == 'checkout') {
        const postData = {
          "gid":localStorage.getItem('gid'),
          "event":"CheckOut",
          "operation":"acceptcheckin"
        }
        console.log(postData)
        this.userService.wfhpolicy(postData)
            .subscribe((res) =>{
              var wfhcheckin = res;
              if(wfhcheckin.status == '1'){
                alert('Checkout accepted successfully');
                window.location.reload();
              }else if (wfhcheckin.status == '0'){
                alert('unauthorized access');
                window.location.reload();
              }
            })
      }
  }
  closeModal() {
    this.dialogRef.close();
  }


  
    
}
