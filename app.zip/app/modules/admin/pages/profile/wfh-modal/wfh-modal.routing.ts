import { Route } from '@angular/router';
import { WfhModalComponent } from './wfh-modal.component';
// import { ProfileimagecapComponent } from 'app/modules/admin/pages/profileimagecap/profileimagecap.component';

export const WfhModalRoutes: Route[] = [
    {
        path     : '',
        component: WfhModalComponent
    }
];
