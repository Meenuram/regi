import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit } from '@angular/core';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
interface DataResponse {
    userId: number;
    id: number;
    title: string;
    completed: boolean;
  }
@Component({
    selector       : 'employee-calendar',
    templateUrl    : './employee-calendar.component.html',
    styleUrls      : ['./employee-calendar.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class EmployeeCalendarComponent implements OnInit{
   
    constructor()
    {
    }

ngOnInit() {   
}




}