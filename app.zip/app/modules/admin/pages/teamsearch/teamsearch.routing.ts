import { Route } from '@angular/router';
import { TeamsearchComponent } from 'app/modules/admin/pages/teamsearch/teamsearch.component';

export const teamsearchRoutes: Route[] = [
    {
        path     : '',
        component: TeamsearchComponent
    }
];
