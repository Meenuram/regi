import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
import { Router,ActivatedRoute } from '@angular/router';
import { environment } from 'environments/environment';
import { DayPilot, DayPilotSchedulerComponent } from 'daypilot-pro-angular';
import { DatePipe } from '@angular/common';
import {TeamComponent} from 'app/modules/admin/ui/content-layouts/common/demo-content/team.component';

@Component({
    selector       : 'usereditfeed',
    templateUrl    : './usereditfeed.component.html',
    styleUrls      : ['./usereditfeed.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class UsereditfeedComponent implements OnInit{
   
    myTeamsMember : any;
     fromSearch:any;
     userTeam:any;
     UserTeamimage:any;
     userTeamMember:any;
     ProfileTeamimage:any;
     current_date:any;
     yesterday:any;
     currentmonthsales:any;
     previousmonthsales:any;
     topsalesdata:any;
     topsales:any;
     emptotal:any;
     usertotalemp:any;
     profilecheck_modal:any;
     params_pass:any;
     teamgidcrm:any;
     params_passlink:any;

     /**
     * Constructor
     *
     * @param {ActivatedRoute} _activatedRoute
     */
    constructor(private _activatedRoute: ActivatedRoute,private userService:UserService,private router: Router,private datePipe: DatePipe,private activatedRoute: ActivatedRoute)
    {
        
    }

ngOnInit() {

    //
    this.fromSearch = localStorage.getItem('bysearch');
    if(this.fromSearch == 'fromsearch'){
        localStorage.removeItem('bysearch');
        this.router.navigate(['/ui/content-layouts/left-sidebar/fullheight/basic/team']); 
    }else{
        this.myTeamsMember = setInterval(() => { 
            this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
            this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
            this.topsales = localStorage.getItem("topthreesales");
              if(this.topsales && this.UserTeamimage && this.userTeamMember){

                //top3

                this.current_date = this.datePipe.transform(new Date(),"dd-MM-yyyy");
            let dte = new Date();
            dte.setDate(dte.getDate() - 1);
            this.yesterday = this.datePipe.transform(dte,"dd-MM-yyyy");
            const topsales = {
                "request": "sales",
                "apikey": "bedd1210-629e-48d7-bdf4-ddcb301c8ece",
                "bid": localStorage.getItem('bid'),
                "gid":localStorage.getItem('gid'),
                "date":this.current_date,
                "toppers":3
            }
            this.userService.topThreesales(topsales)
                .subscribe((res) =>{
                    this.topsalesdata = res;
                    if(res){
                        if(res.Message!="No Record Found."){
                            this.currentmonthsales = res;
                            var current_date = this.datePipe.transform(new Date(),"MMMM d, yyyy");
                            localStorage.setItem("salesdate", current_date);
                            localStorage.setItem("topthreesales", JSON.stringify(this.currentmonthsales));
                            this.router.navigate(['/pages/officefeed']); 
                        }else{
                            var dte = new Date();
                            dte.setDate(dte.getDate() - 1);
                            var current_date = this.datePipe.transform(dte,"MMMM d, yyyy");
                            localStorage.setItem("salesdate", current_date);
                            this.yesterday = this.datePipe.transform(dte,"dd-MM-yyyy");
                            const prepostData = {
                                "request": "sales",
                                "apikey": "bedd1210-629e-48d7-bdf4-ddcb301c8ece",
                                "bid": localStorage.getItem('bid'),
                                "gid":localStorage.getItem('gid'),
                                "date":this.yesterday,
                                "toppers":3
                            }
                            this.userService.topThreesales(prepostData)
                                .subscribe((res) =>{
                                    this.previousmonthsales = res;
                                    localStorage.setItem("topthreesales", JSON.stringify(this.previousmonthsales));
                                    this.router.navigate(['/pages/officefeed']); 
                                })
                        }
                    }
                })
                clearInterval(this.myTeamsMember);
              }else{
              }
          },500);
    }

    this.myTeammembers();
}


myTeammembers(){ 
        this.usertotalemp = JSON.parse(localStorage.getItem("userTotalemp"));
        this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
        if(this.UserTeamimage){
            console.log('if interval');
            if(this.usertotalemp){
                for(var i=0;i<this.usertotalemp.length;i++){
                    for(var j=0;j<this.UserTeamimage.length;j++){
                        if(this.usertotalemp[i].gid == this.UserTeamimage[j].gid){
                            this.usertotalemp[i]['profileImg'] = this.UserTeamimage[j].image
                            this.usertotalemp[i]['gender'] = this.UserTeamimage[j].gender
                        }
        
                    }
                }
                localStorage.setItem("userTotalemp", JSON.stringify(this.usertotalemp));
            }
        }else{ 
            this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
            console.log('else interval');
        }
}
}
