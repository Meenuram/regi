import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilityService } from 'app/shared/services/utility.service';
import { UserService } from 'app/shared/services/user.service';
import { MatStepper } from '@angular/material/stepper';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PersondetailsComponent } from '../persondetails/persondetails.component';
import { ProfileimagecapComponent } from '../profileimagecap/profileimagecap.component';

// import { HttpClient,HttpHeaders, HttpParams } from '@angular/common/http';
// import { map } from 'rxjs/operators';

@Component({
    selector     : 'start-onbording',
    templateUrl  : './start-onbording.component.html',
    styleUrls    : ['./start-onbording.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class StartOnbordingComponent implements OnInit
{
    horizontalStepperForm: FormGroup;
    verticalStepperForm: FormGroup;
    otpvarification:FormGroup;
    otpenter:FormGroup;
    verifyotp:any;
    enterotp:any;
    otpval: number;
    getotpmsg:any;
    totalAngularPackages:any;
    errorMessage:any;
    httpClient: any;
    data:any;
    lstcomments:any;
    onbordinginfo:any;
    empinformation:any;
    allformdata:any;
    mobileverifyinfo:any;
    mobileinformation:any;
    public imagePath;
    imgURL: any;
    public message: string;
    filedata:any;
    url;
	msg = "";
    correctotp: boolean = false;
    wrongotp: boolean = false;
    correctotpsavebtn: boolean = false;
    wrongotpsavebtn: boolean=true;
    verifyenable: boolean = true;
    verifydisable: boolean = false;
    resendotp: boolean = false;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    @ViewChild('horizontalStepper') private myStepper: MatStepper;
    constructor(
        // private http: HttpClient,
        // private _http: HttpClient,
        public matDialog: MatDialog,
        public dialog: MatDialog,
        private _formBuilder: FormBuilder,public util:UtilityService,private formBuilder: FormBuilder,private userService:UserService
    )
    {
    }
    // getItems() {
        
    //   }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai..');

        this.otpvarification = this.formBuilder.group({
            mobilenumber: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]]
            // mobilenumber:['']
        });
        this.otpenter = this.formBuilder.group({
            otp: [null, [ Validators.required ]]
            // otp:['']
        });
        localStorage.setItem('onbordingmobilenum',JSON.stringify(this.otpvarification.value));
        
        // Horizontal stepper form
        this.horizontalStepperForm = this._formBuilder.group({
            step1: this._formBuilder.group({
                // mobilenumber : ['', Validators.required],
                // otp : ['', Validators.required]
            }),
            step2: this._formBuilder.group({
                firstName: ['', Validators.required],
                lastName : ['', Validators.required],
                dob    : ['', Validators.required],
                email   : ['', [Validators.required, Validators.email]],
            }),
            step3: this._formBuilder.group({
                pushNotifications: ['everything', Validators.required]
            })
        });
        this.verifyotp=true;
        this.enterotp=false;
    }
    get f(){
        return this.otpvarification.controls;
      }
    //
    sendotppersonal(){
        // console.log(this.otpvarification.value);
        // var abcd = localStorage.getItem('onbordingmobilenum');
        // localStorage.setItem('onbordinggetotp',JSON.stringify(this.otpenter.value));
        // console.log(abcd)
        
        // this.mobileverifyinfo = this.horizontalStepperForm.value;
        // console.log(this.mobileverifyinfo)
        // this.mobileinformation = this.mobileverifyinfo.step1;
        // console.log(this.mobileinformation)
        var otpval = Math.floor(1000 + Math.random() * 9000);
        this.verifyenable = true;
        this.getotpmsg="Employment application: "+''+otpval+''+" is the verification code.";
        const postData = {
            "mobile":this.otpvarification.get('mobilenumber').value,
            "otp": this.getotpmsg
        };
        // console.log(postData)
        var otpresult = this.userService.onboardingotp(postData)
        .subscribe((res) =>{
            // console.log(res)
        })
        // console.log(postData);
        if(otpresult){
            localStorage.setItem('onbordinggetotp',JSON.stringify(otpval));
            this.verifyotp=false;
            this.enterotp=true;
            alert("otp sent successfully");
            this.verifyenable = false;
            this.verifydisable = true;
            this.resendotp = true;
        }else{
            alert("Incorrect otp.");
            this.verifyotp=true;
            this.enterotp=false;
            this.verifyenable = false;
            this.verifydisable = false;
            this.resendotp = true;
        }
    }
    onChangeotp(searchValue: string): void{
        var getotp = localStorage.getItem('onbordinggetotp');
        if(getotp.length==4){
            if(getotp==this.otpenter.get('otp').value){
                this.correctotp=true;
                this.wrongotp=false;
                this.correctotpsavebtn = true;
                this.wrongotpsavebtn = false;
                // alert("otp save successfully");
            }else{
                this.correctotp=false;
                this.wrongotp=true;
                this.correctotpsavebtn = false;
                this.wrongotpsavebtn = true;
                // alert("Incorrect otp.");
            }
        }
    }
    saveotp(){
    //     var getotp = localStorage.getItem('onbordinggetotp');
    //     if(getotp==this.otpenter.get('otp').value){
    //         // alert("otp save successfully");
    //     }else{
    //         alert("Incorrect otp.");
    //     }
    }


    //image
    // preview(files) {
    //     if (files.length === 0)
    //       return;
     
    //     var mimeType = files[0].type;
    //     if (mimeType.match(/image\/*/) == null) {
    //       this.message = "Only images are supported.";
    //       return;
    //     }
     
    //     var reader = new FileReader();
    //     this.imagePath = files;
    //     reader.readAsDataURL(files[0]); 
    //     this.filedata = files[0];
    //     console.log(this.filedata)
    //     reader.onload = (_event) => { 
    //       this.imgURL = reader.result; 
    //       console.log(this.imgURL);
    //     }
    //     let input = new FormData();
    //     input = new FormData();
    //     input.append("bid", "10653721");
    //     input.append("gid","123");
    //     input.append("file",this.imgURL);
    //     this.userService.profileImageupload(input)
    //     .subscribe((res) =>{
    //     console.log(res);
    //     })
    // }
    selectFile(event) {
		if(!event.target.files[0] || event.target.files[0].length == 0) {
			this.msg = 'You must select an image';
			return;
		}
		
		var mimeType = event.target.files[0].type;
		
		if (mimeType.match(/image\/*/) == null) {
			this.msg = "Only images are supported";
			return;
		}
		var reader = new FileReader();
		reader.readAsDataURL(event.target.files[0]);
		
		reader.onload = (_event) => {
			this.msg = "";
			this.url = reader.result; 
            console.log(this.url)
		}
        this.userService.profileImageupload(this.url)
        .subscribe((res) =>{
        console.log(res);
        })
	}
    //
//     nextStep(){
//        if(this.otpvarification.invalid || this.otpenter.invalid){
// alert('invalid')
//        }else{
//         this.onbordinginfo = this.horizontalStepperForm.value;
//         this.empinformation = this.onbordinginfo.step2;
//        }
//     }

/////testwebcam/////
// openModaltest() {
//     const dialogConfig = new MatDialogConfig();
//     dialogConfig.disableClose = true;
//     dialogConfig.id = "modal-component";
//     dialogConfig.height = "350px";
//     dialogConfig.width = "600px";
//     const modalDialog = this.matDialog.open(PersondetailsComponent, dialogConfig);
// }
openModaltest() {
    const dialogConfig = new MatDialogConfig();
    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = "modal-component";
    dialogConfig.height = "350px";
    dialogConfig.width = "600px";
    const modalDialog = this.matDialog.open(ProfileimagecapComponent, dialogConfig);
}
/////////
    sendInfo(){
        // var imageurl = this.imgURL;
        var mobile = this.otpvarification.get('mobilenumber').value;
        var otp = this.otpenter.get('otp').value;
        this.onbordinginfo = this.horizontalStepperForm.value;
        var empinformation = this.onbordinginfo.step2;
        // empinformation.push({mobile:this.otpvarification.get('mobilenumber').value, otp:this.otpenter.get('otp').value});
        // console.log(empinformation);
        var fname = empinformation.firstName;
        var lastname = empinformation.lastName;
        var dob =  empinformation.dob;
        var email = empinformation.email;
        var allinfo = {mobile,otp,fname,lastname,dob,email}

        const postData = {
            "bid": localStorage.getItem('bid'),
            "gid": localStorage.getItem('gid'),
            "request":"eqlInsert",
            "empjson":allinfo
        };
        console.log(postData)
        this.userService.beginonboarding(postData)
        .subscribe((res) =>{
            // console.log(res)
            var senddata = res.status;
            if(senddata == 1){
                // this.myStepper.next();
                window.open("https://kyc.eql.app/", "_blank");
                // alert("sent successfully");
            }else{
                // alert("Error");
            }
        })
        // error => {
        //     alert("Error");
        // })
    }
    // sendInfo() {
    //     this.myStepper.next();
    //   }
    // allDone(){
        // window.open("https://kyc.eql.app/", "_blank"); 
        // this.sendInfo();
        // if(senddata == 1){
        //     window.open("http://kyc.ledgers.cloud", "_blank"); 
        // }else{
        //     alert("Error");
        // }
        // console.log(this.otpvarification.value)
        // this.allformdata = this.horizontalStepperForm.value;
        // console.log(this.allformdata)
    //   }
}
