import { Route } from '@angular/router';
import { BioformsComponent } from './bioforms.component';

export const bioformsRoutes: Route[] = [
    {
        path     : '',
        component: BioformsComponent
    }
];
