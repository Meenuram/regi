import { Component, ViewEncapsulation, Inject } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
    selector     : 'demo-content',
    templateUrl  : './demo-content.component.html',
    styleUrls    : ['./demo-content.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class DemoContentComponent
{
    //userProfile : any;
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    userfname:any;
    usermobileno:any;
    userdob:any;
    userpemail:any;
    usergender:any;
    usermaritalStatus:any;
    usernationality:any;
    userlanguageKnown:any;
    userblood:any;
    useraadhaar:any;
    userpan:any;
    useraddressLine1:any;
    useraddressLine2:any;
    userzipCode:any;
    usercity:any;
    userstate:any;
    usercountry:any;
    //menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */
    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,
        @Inject(SESSION_STORAGE) private storage: StorageService,
        private userService:UserService,public util:UtilityService
        )
    { 
        //this.getUserProfile();
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });

            this.userfname = localStorage.getItem('FatherName');
            if(this.userfname == 0 || this.userfname == "null"){
                this.userfname = '';
            }else{
                this.userfname = localStorage.getItem('FatherName');
            }

            this.usermobileno = localStorage.getItem('Mobile');
            if(this.usermobileno == 0 || this.usermobileno == "null"){
                this.usermobileno = '';
            }else{
                this.usermobileno = localStorage.getItem('Mobile');
            }

            this.userdob = localStorage.getItem('dob');
            if(this.userdob == 0 || this.userdob == "null"){
                this.userdob = '';
            }else{
                this.userdob = localStorage.getItem('dob');
            }

            this.userpemail = localStorage.getItem('personalemail');
            if(this.userpemail == 0 || this.userpemail == "null"){
                this.userpemail = '';
            }else{
                this.userpemail = localStorage.getItem('personalemail');
            }

            this.usergender = localStorage.getItem('Gender');
            if(this.usergender == 0 || this.usergender == "null"){
                this.usergender = '';
            }else{
                this.usergender = localStorage.getItem('Gender');
            }
            
            this.usermaritalStatus = localStorage.getItem('MaritalStatus');
            if(this.usermaritalStatus == 0 || this.usermaritalStatus == "null"){
                this.usermaritalStatus = '';
            }else{
                this.usermaritalStatus = localStorage.getItem('MaritalStatus');
            }
            
            this.usernationality = localStorage.getItem('Nationality');
            if(this.usernationality == 0 || this.usernationality == "null"){
                this.usernationality = '';
            }else{
                this.usernationality = localStorage.getItem('Nationality');
            }
            
            this.userlanguageKnown = localStorage.getItem('LanguageKnown');
            if(this.userlanguageKnown == 0 || this.userlanguageKnown == "null"){
                this.userlanguageKnown = '';
            }else{
                this.userlanguageKnown = localStorage.getItem('LanguageKnown');
            }
            
            this.userblood = localStorage.getItem('Blood');
            if(this.userblood == 0 || this.userblood == "null"){
                this.userblood = '';
            }else{
                this.userblood = localStorage.getItem('Blood');
            }
            
            this.useraadhaar = localStorage.getItem('aadhaar');
            if(this.useraadhaar == 0 || this.useraadhaar == "null"){
                this.useraadhaar = '';
            }else{
                this.useraadhaar = localStorage.getItem('aadhaar');
            }
            
            this.userpan = localStorage.getItem('pan');
            if(this.userpan == 0 || this.userpan == "null"){
                this.userpan = '';
            }else{
                this.userpan = localStorage.getItem('pan');
            }
            
            this.useraddressLine1 = localStorage.getItem('AddressLine1');
            if(this.useraddressLine1 == 0 || this.useraddressLine1 == "null"){
                this.useraddressLine1 = '';
            }else{
                this.useraddressLine1 = localStorage.getItem('AddressLine1');
            }
            
            this.useraddressLine2 = localStorage.getItem('AddressLine2');
            if(this.useraddressLine2 == 0 || this.useraddressLine2 == "null"){
                this.useraddressLine2 = '';
            }else{
                this.useraddressLine2 = localStorage.getItem('AddressLine2');
            }
            
            this.userzipCode = localStorage.getItem('ZipCode');
            if(this.userzipCode == 0 || this.userzipCode == "null"){
                this.userzipCode = '';
            }else{
                this.userzipCode = localStorage.getItem('ZipCode');
            }
            
            this.usercity = localStorage.getItem('City');
            if(this.usercity == 0 || this.usercity == "null"){
                this.usercity = '';
            }else{
                this.usercity = localStorage.getItem('City');
            }
            
            this.userstate = localStorage.getItem('State');
            if(this.userstate == 0 || this.usercity == "null"){
                this.userstate = '';
            }else{
                this.userstate = localStorage.getItem('State');
            }
            
            this.usercountry = localStorage.getItem('Country');
            if(this.usercountry == 0 || this.usercountry == "null"){
                this.usercountry = '';
            }else{
                this.usercountry = localStorage.getItem('Country');
            }
    }
    editbio(){
        window.open("#/pages/bioforms");
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }


}