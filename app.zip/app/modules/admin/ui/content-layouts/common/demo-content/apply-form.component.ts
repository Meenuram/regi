import { Component, ViewEncapsulation, ElementRef, HostListener } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
    selector     : 'apply-form',
    templateUrl  : './apply-form.component.html',
    styleUrls    : ['./apply-form.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ApplyFormComponent
{
    leftscrollvalue:any;
    @HostListener("window:scroll", ["$event"])
    onWindowScroll() {
        console.log('hai'+document.documentElement.scrollTop)
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
     if(pos == max )   {
     //Do your action here
     }
        if (document.documentElement.scrollTop > 450) {
            this.leftscrollvalue = "abcd" ;
        } else {
            this.leftscrollvalue = "" ;
        }
    }

    clleavesbalance:any;
    clleavescredited:any;
    clleavestaken:any;
    unpaidleavescredited:any;
    unpaidleavestaken:any;
    unpaidleavesbalance:any;
    leavetype: any;
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */
    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,public elementRef: ElementRef,
        private userService:UserService,public util:UtilityService
        )
    {
        
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });
            this.displayleavebalance();
    }

    displayleavebalance(){
        const postData = {
            "gid":localStorage.getItem('gid'),
            "bid":localStorage.getItem('bid'),
            "key":"leaveBalance"
        };
        this.userService.userleavebalance(postData)
            .subscribe((res) =>{
                var leavebalancecl = res.data[0];
                var cl = leavebalancecl.CL;
                var leavebalanceunpaid = res.data[0];
                var unpaid = leavebalanceunpaid.unpaid;

              this.clleavesbalance = cl.leavesbalance;
              this.clleavescredited = cl.leavescredited;
              this.clleavestaken = cl.leavestaken ? cl.leavestaken : 0;

              this.unpaidleavescredited = unpaid.leavescredited;
              this.unpaidleavestaken = unpaid.leavestaken;
              this.unpaidleavesbalance = unpaid.leavesbalance;

              //this.leaveType = res.leavesarray;

             // console.log(res.leavesarray);
        }) 
    } 

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

}
