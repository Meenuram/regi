import { Component, ViewEncapsulation, ElementRef, HostListener } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { UtilityService } from 'app/shared/services/utility.service';



@Component({
    selector     : 'apply-status',
    templateUrl  : './apply-status.component.html',
    styleUrls    : ['./apply-status.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ApplyStatusComponent
{
    leftscrollvalue:any;
    @HostListener("window:scroll", ["$event"])
    onWindowScroll() {
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
     if(pos == max )   {
     //Do your action here
     }
        if (document.documentElement.scrollTop > 450) {
            this.leftscrollvalue = "abcd" ;
        } else {
            this.leftscrollvalue = "" ;
        }
    }

    leaveapproval:any;
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */
    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,public elementRef: ElementRef,
        private userService:UserService,public util:UtilityService
        )
    {
        
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });

            this.leaveapproval = JSON.parse(localStorage.getItem('leaveapproval'));
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

}
