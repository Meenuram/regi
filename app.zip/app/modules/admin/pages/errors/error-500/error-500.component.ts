import { ChangeDetectionStrategy, Component, ViewEncapsulation } from '@angular/core';
import { UtilityService } from 'app/shared/services/utility.service';

@Component({
    selector       : 'error-500',
    templateUrl    : './error-500.component.html',
    styleUrls      : ['./error-500.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class Error500Component
{
    /**
     * Constructor
     */
    constructor(public util:UtilityService,)
    {
    }
    /**
     * On init
     */
    ngOnInit()
    {
        this.util.profileHeader('hai');
    }
}
