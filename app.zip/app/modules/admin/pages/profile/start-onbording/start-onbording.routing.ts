import { Route } from '@angular/router';
import { StartOnbordingComponent } from './start-onbording.component';

export const StartOnbordingRoutes: Route[] = [
    {
        path     : '',
        component: StartOnbordingComponent
    }
];
