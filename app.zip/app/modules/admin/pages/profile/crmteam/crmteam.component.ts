import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
import { Router,ActivatedRoute } from '@angular/router';
import { environment } from 'environments/environment';
import { DayPilot, DayPilotSchedulerComponent } from 'daypilot-pro-angular';
import { DatePipe } from '@angular/common';

@Component({
    selector       : 'crmteam',
    templateUrl    : './crmteam.component.html',
    styleUrls      : ['./crmteam.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CrmteamComponent implements OnInit{
   
    myTeamsMember : any;
     fromSearch:any;
     userTeam:any;
     UserTeamimage:any;
     userTeamMember:any;
     ProfileTeamimage:any;
     current_date:any;
     yesterday:any;
     currentmonthsales:any;
     previousmonthsales:any;
     topsalesdata:any;
     topsales:any;
     emptotal:any;
     usertotalemp:any;
     profilecheck_modal:any;
     params_pass:any;
     teamgidcrm:any;
     params_passlink:any;
     pagespinner:Boolean=true;

     /**
     * Constructor
     *
     * @param {ActivatedRoute} _activatedRoute
     */
    constructor(private _activatedRoute: ActivatedRoute,private userService:UserService,private router: Router,private datePipe: DatePipe,private activatedRoute: ActivatedRoute)
    {
        this.pagespinner=true;
    }

ngOnInit() {
    //
    this.activatedRoute.queryParams.subscribe(params => {
        this.teamgidcrm = params['gid'];
        this.params_passlink={queryParams : { }};
        this.myTeamsMember = setInterval(() => { 
            this.usertotalemp = JSON.parse(localStorage.getItem("userTotalemp"));
            this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
            if(this.UserTeamimage){
                console.log('if interval');
                if(this.usertotalemp){
                    for(var i=0;i<this.usertotalemp.length;i++){
                        for(var j=0;j<this.UserTeamimage.length;j++){
                            if(this.usertotalemp[i].gid == this.UserTeamimage[j].gid){
                                this.usertotalemp[i]['profileImg'] = this.UserTeamimage[j].image
                                this.usertotalemp[i]['gender'] = this.UserTeamimage[j].gender
                            }
                        }
                    }
                    localStorage.setItem("userTotalemp", JSON.stringify(this.usertotalemp));
                }
                if(this.teamgidcrm){
                    this.params_passlink ={ queryParams: { gid: this.teamgidcrm } };
                }
                this.router.navigate(['/ui/content-layouts/left-sidebar/fullheight/basic/team'],this.params_passlink);
                clearInterval(this.myTeamsMember);
                this.pagespinner=false;
                console.log("teampagespinner if");
            }else{ 
                this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
                console.log('else interval');
                this.pagespinner=false;
                console.log("teampagespinner else");
            }
        },500);
    });
}

// myTeammembers(){
//     this.myTeamsMember = setInterval(() => { 
//         this.usertotalemp = JSON.parse(localStorage.getItem("userTotalemp"));
//         this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
//         if(this.UserTeamimage){
//             console.log('if interval');
//             if(this.usertotalemp){
//                 for(var i=0;i<this.usertotalemp.length;i++){
//                     for(var j=0;j<this.UserTeamimage.length;j++){
//                         if(this.usertotalemp[i].gid == this.UserTeamimage[j].gid){
//                             this.usertotalemp[i]['profileImg'] = this.UserTeamimage[j].image
//                             this.usertotalemp[i]['gender'] = this.UserTeamimage[j].gender
//                         }
//                     }
//                 }
//                 localStorage.setItem("userTotalemp", JSON.stringify(this.usertotalemp));
//             }
//             clearInterval(this.myTeamsMember);
//         }else{ 
//             this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
//             console.log('else interval');
//         }
//     },500);
// }




}
