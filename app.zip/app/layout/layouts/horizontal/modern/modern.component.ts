import { Component, HostBinding, OnDestroy, OnInit, DoCheck  , ViewEncapsulation,ElementRef ,HostListener } from '@angular/core';
import { ActivatedRoute, Data, Router } from '@angular/router';
import { Subject, Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { TreoNavigationService } from '@treo/components/navigation';
import { UserService } from 'app/shared/services/user.service';
import { DayGridSlicer } from '@fullcalendar/daygrid';
import { UtilityService } from 'app/shared/services/utility.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PersondetailsComponent } from 'app/modules/admin/pages/profile/persondetails/persondetails.component';
import { WfhModalComponent } from 'app/modules/admin/pages/profile/wfh-modal/wfh-modal.component';
import { ProfileimagecapComponent } from 'app/modules/admin/pages/profile/profileimagecap/profileimagecap.component';
// import { SimpleDemoComponent } from 'app/modules/admin/pages/profile/simple-demo/simple-demo.component';

@Component({
    selector     : 'modern-layout',
    templateUrl  : './modern.component.html',
    styleUrls    : ['./modern.component.scss'],
    encapsulation: ViewEncapsulation.None
    // encapsulation  : ViewEncapsulation.None,
    // changeDetection: ChangeDetectionStrategy.OnPush
})
export class ModernLayoutComponent implements OnInit, OnDestroy 
{
    scrollheader:any;
    @HostListener("window:scroll", ["$event"])
    onWindowScroll() {
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
     if(pos == max )   {
     //Do your action here
     }
        if (document.documentElement.scrollTop > 300) {
            this.fixedheader = true;
            this.officefeed = false;
        } else {
            this.fixedheader = false;
            this.officefeed = false;
        }
        // if (document.documentElement.scrollTop > 200) {
        //     this.fixedheader = false;
        //     this.fromofficefeedpage = true;
        // } else {
        //     this.fixedheader = false;
        //     this.fromofficefeedpage = false;
        // }
    }

    userimage:any;
    username:any;
    userdesignation:any;
    userteams:any;
    userfollow:any;
    data: any;
    isScreenSmall: boolean;
    userid:any;
    teammebergid:any;
    checkDoc: boolean = false;
    gender:any;
    headerItem:any;
    checkin:any;
    checkout:any;
    fromfinancepage:boolean= false;
    fromofficefeedpage:boolean=false;
    walletData:any;
    walletbalance:any;
    profilecredit:any;
    fixedheader:any;
    officefeed:any;
    headerfixed:any;
    @HostBinding('class.fixed-header')
    fixedHeader: boolean;

    @HostBinding('class.fixed-footer')
    fixedFooter: boolean;

    // Private
    private _unsubscribeAll: Subject<any>;

    

    /**
     * Constructor
     *
     * @param {ActivatedRoute} _activatedRoute
     * @param {Router} _router
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     * @param {TreoNavigationService} _treoNavigationService
     */
    constructor(
        private _activatedRoute: ActivatedRoute,
        private _router: Router,
        private _treoMediaWatcherService: TreoMediaWatcherService,
        private _treoNavigationService: TreoNavigationService,
        private userService:UserService,
        public util:UtilityService,
        private router: Router,
        public matDialog: MatDialog,
        public dialog: MatDialog,
        public elementRef: ElementRef,
        private activatedRoute: ActivatedRoute
    )
    {
        

        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.fixedHeader = false;
        this.fixedFooter = false;
        this.officefeed = false;
        this.util.invokeProfileHeader.subscribe(value =>{
            this.refreshPRofileData();
        });
        this.util.invokeOpenModal.subscribe(value =>{
            this.openModal();
        });

        this.headerItem = true;
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for current year
     */
    get currentYear(): number
    {
        return new Date().getFullYear();
    }

    DoCheck(){
       
    }
        
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks 
    // -----------------------------------------------------------------------------------------------------
    refreshPRofileData(){
            var uri = window.location.href;
            var lastslashindex = uri.match(/\/([^\/]+)\/?$/)[1];
            if(lastslashindex == 'usereditprofile'){
                this.headerItem = false;
            }else if(lastslashindex == 'finance'){
               this.fromfinancepage = true;
            }else if(lastslashindex == 'modern'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'analytics'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'crypto'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'leaves-count'){
                this.fromfinancepage = true;
            }else if(lastslashindex == '500'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'calendar'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'settings'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'contacts'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'leader-board'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'officefeed'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'publicwall'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'employee-onboarding'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'cards'){
                this.fromfinancepage = true;
            }else if(lastslashindex == 'start-onbording'){
                this.fromfinancepage = true;
            }
            // else if(lastslashindex == 'profileimg'){
            //     this.profileimgchange();
            // }
            else{
                this.fromfinancepage = false;
                this.headerItem = true;
            }

            //onboarding
            if(lastslashindex == 'employee-onboarding'){
                this.fromofficefeedpage = true;
            }else if(lastslashindex == 'start-onbording'){
                this.fromofficefeedpage = true;
            }else{
                this.fromofficefeedpage = false;
                this.headerItem = true;
            }

            this.userimage = localStorage.getItem('userimage');
            this.username =  localStorage.getItem('name');
            this.gender = localStorage.getItem('Gender');
            this.userdesignation =  localStorage.getItem('designation');
            this.userteams =  localStorage.getItem('team');
            this.userfollow =  localStorage.getItem('following');
            this.userid = localStorage.getItem('gid');
            this.teammebergid = localStorage.getItem('teammebergid');
            if(this.userid == this.teammebergid){
                this.checkDoc =true;
            }else{
                this.checkDoc =false;

            }
    }  
    userFollow(){
        localStorage.setItem('bysearch', 'fromsearch');
        this.router.navigate(['/pages/usereditprofile']);
    }
    userTeams(){
        localStorage.setItem('bysearch', 'fromsearch');
        this.router.navigate(['/pages/usereditprofile']);  
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        // this.activatedRoute.queryParams.subscribe(params => {
        //     var profilecheck_modal = atob(params['p']);
        //     console.log(profilecheck_modal); // Print the parameter to the console. 
        //     if(profilecheck_modal=="profile_image"){
        //         this.openModal();
        //     }
        // });
        var uri = window.location.href;
        var lastslashindex = uri.match(/\/([^\/]+)\/?$/)[1];
        if(lastslashindex == 'usereditprofile'){
            this.headerItem = false;
        }else{
            this.headerItem = true;
        }
        // Subscribe to the resolved route data
        this._activatedRoute.data.subscribe((data: Data) => {
            this.data = data.initialData;
        });

        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Check if the breakpoint is 'lt-md'
                this.isScreenSmall = matchingAliases.includes('lt-md');
            });

            //wallet
    this.walletData = JSON.parse(localStorage.getItem("getwalletdata"));
    // this.walletbalance = this.walletData.credit - this.walletData.debit;
    // console.log(this.walletbalance);
    if(this.walletData.status==1){
        this.profilecredit = this.walletData.credit;
        if(!this.walletData){
            this.walletbalance =0;
        }else if(this.walletData.credit == 0 && this.walletData.credit == 0 && this.walletData.debit == 0){
        this.walletbalance =0;
        }else if(this.walletData.status == 0){
            this.walletbalance =0;
            this.walletData.credit = 0;
            this.walletData.debit = 0;
        }else{
            this.walletbalance = this.walletData.credit - this.walletData.debit;
        }
    }else{
        this.profilecredit = 0;
        this.walletbalance = 0;
    }

    

    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Toggle navigation
     *
     * @param key
     */
    toggleNavigation(key): void
    {
        // Get the navigation
        const navigation = this._treoNavigationService.getComponent(key);

        if ( navigation )
        {
            // Toggle the opened status
            navigation.toggle();
        }
    }

    errorImage(){
        console.log('errorimage');
        if(this.gender == 'male'){
            this.userimage = "https://de1.conqhr.com/images/male.jpeg"  

        }else{
            this.userimage = "https://de1.conqhr.com/images/female.jpeg"    
        }
    }
    openModal() {
        const dialogConfig = new MatDialogConfig();
        // The user can't close the dialog by clicking outside its body
        dialogConfig.disableClose = true;
        dialogConfig.id = "modal-component";
        dialogConfig.height = "350px";
        dialogConfig.width = "600px";
        const modalDialog = this.matDialog.open(ProfileimagecapComponent, dialogConfig);
    }
    // modalopencrm(){
    //     var get_pro=atob
    // }
    
    //   profileimgchange() {
    //     const dialogConfig = new MatDialogConfig();
    //     dialogConfig.disableClose = true;
    //     dialogConfig.id = "modal11-component";
    //     dialogConfig.height = "350px";
    //     dialogConfig.width = "600px";
    //     const modalDialog = this.matDialog.open(WfhModalComponent, dialogConfig);
    //   }
      openCheckin() {
        this.dialog.open(WfhModalComponent, {
          data: {
          }
        });
        this.checkin = localStorage.setItem('checkintype', 'checkin');
      }
      openCheckout() {
        this.dialog.open(WfhModalComponent, {
            data: {
            }
        });
        this.checkout = localStorage.setItem('checkintype', 'checkout');
      }
   
}
