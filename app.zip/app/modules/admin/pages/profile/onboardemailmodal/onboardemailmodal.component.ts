import { Component, OnInit, Inject } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { Router } from '@angular/router';
import { ModernLayoutComponent } from 'app/layout/layouts/horizontal/modern/modern.component';
import { UtilityService } from 'app/shared/services/utility.service';
import { MatDialogRef } from '@angular/material/dialog';
import { Subject, Observable } from 'rxjs';
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-onboardemailmodal',
  templateUrl: './onboardemailmodal.component.html',
  styleUrls: ['./onboardemailmodal.component.scss']
})
export class OnboardemailmodalComponent implements OnInit {
  onboardemailenter:FormGroup;
  constructor(private _formBuilder: FormBuilder,private formBuilder: FormBuilder,public dialogRef: MatDialogRef<OnboardemailmodalComponent>, private userService:UserService,public util:UtilityService) { 
    
  }


  ngOnInit(): void {
    this.onboardemailenter = this.formBuilder.group({
      onboardemail: [null, [ Validators.required ]]
      // otp:['']
  });
  }
  emponboardemailsave(){
      var getemail = localStorage.getItem('empgetemailotp');
      if(getemail==this.onboardemailenter.get('onboardemail').value){
        localStorage.setItem('emailverify','verified');
        this.util.onboardemailotp('hai');
        this.dialogRef.close();
      }else{
          alert("Incorrect otp.");
      }
  }
    actionFunction() {
      alert("You have logged out.");
      this.closeModal();
    }

    // If the user clicks the cancel button a.k.a. the go back button, then\
    // just close the modal
    closeModal() {
      this.dialogRef.close();
    }

}
