import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileimagecapComponent } from './profileimagecap.component';

describe('ProfileimagecapComponent', () => {
  let component: ProfileimagecapComponent;
  let fixture: ComponentFixture<ProfileimagecapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileimagecapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileimagecapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
