import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { EmployeeCalendarComponent } from './employee-calendar.component';
import { employeecalendarRoutes } from './employee-calendar.routing';
import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
    declarations: [
        EmployeeCalendarComponent
    ],
    imports     : [
        RouterModule.forChild(employeecalendarRoutes),
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatTabsModule,
        MatTooltipModule
    ]
})
export class EmployeeCalendarModule
{
}
