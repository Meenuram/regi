import { Route } from '@angular/router';
import { CardModalComponent } from './card-modal.component';

export const cardmodalRoutes: Route[] = [
    {
        path     : '',
        component: CardModalComponent
    }
];
