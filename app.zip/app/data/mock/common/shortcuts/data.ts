import { Shortcut } from 'app/layout/common/shortcuts/shortcuts.types';

/* tslint:disable:max-line-length */

export const shortcuts: Shortcut[] = [
    {
        id         : 'a1ae91d3-e2cb-459b-9be9-a184694f548b',
        label      : 'LEDGERS',
        description: 'Invoicing & Payments',
        icon       : 'list_alt',
        link       : 'https://app.ledgers.cloud/m/app/dashboard',
        useRouter  : false
    },
    {
        id         : '2496f42e-2f25-4e34-83d5-3ff9568fd984',
        label      : 'Company Portal',
        description: 'Manage Engagements',
        icon       : 'dashboard',
        link       : 'http://indiafilings.company/',
        useRouter  : false
    },{
        id         : '34fb28db-4ec8-4570-8584-2414d6de796b',
        label      : 'Customer Central',
        description: 'New CRM',
        icon       : 'supervisor_account',
        link       : 'https://epiccrm.app/#/',
        useRouter  : false
    },
    {
        id         : '56a0a561-17e7-40b3-bd75-0b6cef230b7e',
        label      : 'Help Desk',
        description: 'Tasks & Tickets',
        icon       : 'live_help',
        link       : 'https://team.ledgers.cloud/',
        useRouter  : false
    }
];
