import { Route } from '@angular/router';
import { OnboardmobilemodalComponent } from './onboardmobilemodal.component';
// import { ProfileimagecapComponent } from 'app/modules/admin/pages/profileimagecap/profileimagecap.component';

export const OnboardmobilemodalRoutes: Route[] = [
    {
        path     : '',
        component: OnboardmobilemodalComponent
    }
];
