import { Component, OnInit, Inject } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { Router } from '@angular/router';
import { ModernLayoutComponent } from 'app/layout/layouts/horizontal/modern/modern.component';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { UtilityService } from 'app/shared/services/utility.service';

@Component({
  selector: 'app-teamsearch',
  templateUrl: './teamsearch.component.html',
  styleUrls: ['./teamsearch.component.scss']
})
export class TeamsearchComponent implements OnInit {
  emptotal:any;

  constructor(@Inject(SESSION_STORAGE) private storage: StorageService,
  private userService:UserService,private router: Router,public util:UtilityService) {
    this.util.invokeSearchList.subscribe(value =>{
      this.emptotal = value;
      console.log(value)
  });
   }

  ngOnInit(): void { 
    this.emptotal = JSON.parse(localStorage.getItem("searchresult")); 
    console.log(this.emptotal);
  }
  refreshsearchlistdata(){

  }
  searchedMember(teams){
    localStorage.setItem("teammebergid", teams.gid);
    localStorage.setItem('userimage', teams.profileImg);
    localStorage.setItem('bysearch', 'fromsearch');
    this.router.navigate(['/pages/usereditprofile']);
}

}
