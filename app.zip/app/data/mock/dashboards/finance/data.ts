import * as moment from 'moment';

/* tslint:disable:max-line-length */
export const finance = {
    age                 : {
        series: [35, 65],
        labels: ['Under 30','Over 30']
    },
    language            : {
        series: [5, 5],
        labels: [
            'Late',
            'ontime'
        ]
    },
    accountBalance    : {
        growRate: 38.33,
        ami     : 45332,
        series  : [
            {
                name: "Incentive Netpay",
                data: [
                    {
                        x: "Amount",
                        y: 48.84
                    },
                    {
                        x: "Amount",
                        y: 50.34
                    },
                    {
                        x: "Amount",
                        y: 60.84
                    },
                    {
                        x: "Amount",
                        y: 80.84
                    }
                ]
            }
            // ,
            // {
            //     name: 'Actual',
            //     data: [
            //         {
            //             x: moment().subtract(12, 'months').day(1).toDate(),
            //             y: 20.21
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(4).toDate(),
            //             y: 17.49
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(7).toDate(),
            //             y: 16.54
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(10).toDate(),
            //             y: 19.00
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(13).toDate(),
            //             y: 16.47
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(16).toDate(),
            //             y: 13.15
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(19).toDate(),
            //             y: 18.07
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(22).toDate(),
            //             y: 17.93
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(25).toDate(),
            //             y: 18.92
            //         },
            //         {
            //             x: moment().subtract(12, 'months').day(28).toDate(),
            //             y: 18.46
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(1).toDate(),
            //             y: 18.04
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(4).toDate(),
            //             y: 17.78
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(7).toDate(),
            //             y: 20.15
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(10).toDate(),
            //             y: 18.92
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(13).toDate(),
            //             y: 17.08
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(16).toDate(),
            //             y: 17.11
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(19).toDate(),
            //             y: 15.70
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(22).toDate(),
            //             y: 15.07
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(25).toDate(),
            //             y: 14.51
            //         },
            //         {
            //             x: moment().subtract(11, 'months').day(28).toDate(),
            //             y: 15.22
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(1).toDate(),
            //             y: 19.77
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(4).toDate(),
            //             y: 23.67
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(7).toDate(),
            //             y: 27.98
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(10).toDate(),
            //             y: 30.80
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(13).toDate(),
            //             y: 28.56
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(16).toDate(),
            //             y: 27.45
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(19).toDate(),
            //             y: 27.50
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(22).toDate(),
            //             y: 27.28
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(25).toDate(),
            //             y: 24.36
            //         },
            //         {
            //             x: moment().subtract(10, 'months').day(28).toDate(),
            //             y: 22.89
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(1).toDate(),
            //             y: 28.04
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(4).toDate(),
            //             y: 27.77
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(7).toDate(),
            //             y: 30.24
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(10).toDate(),
            //             y: 26.57
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(13).toDate(),
            //             y: 22.18
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(16).toDate(),
            //             y: 19.64
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(19).toDate(),
            //             y: 16.74
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(22).toDate(),
            //             y: 17.21
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(25).toDate(),
            //             y: 20.05
            //         },
            //         {
            //             x: moment().subtract(9, 'months').day(28).toDate(),
            //             y: 16.13
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(1).toDate(),
            //             y: 10.71
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(4).toDate(),
            //             y: 7.99
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(7).toDate(),
            //             y: 11.33
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(10).toDate(),
            //             y: 15.36
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(13).toDate(),
            //             y: 20.16
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(16).toDate(),
            //             y: 22.56
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(19).toDate(),
            //             y: 19.34
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(22).toDate(),
            //             y: 18.32
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(25).toDate(),
            //             y: 20.75
            //         },
            //         {
            //             x: moment().subtract(8, 'months').day(28).toDate(),
            //             y: 17.09
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(1).toDate(),
            //             y: 18.31
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(4).toDate(),
            //             y: 14.34
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(7).toDate(),
            //             y: 9.93
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(10).toDate(),
            //             y: 10.64
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(13).toDate(),
            //             y: 6.18
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(16).toDate(),
            //             y: 10.32
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(19).toDate(),
            //             y: 12.80
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(22).toDate(),
            //             y: 13.44
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(25).toDate(),
            //             y: 18.35
            //         },
            //         {
            //             x: moment().subtract(7, 'months').day(28).toDate(),
            //             y: 22.87
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(1).toDate(),
            //             y: 26.92
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(4).toDate(),
            //             y: 22.50
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(7).toDate(),
            //             y: 18.14
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(10).toDate(),
            //             y: 19.06
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(13).toDate(),
            //             y: 19.73
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(16).toDate(),
            //             y: 18.82
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(19).toDate(),
            //             y: 23.33
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(22).toDate(),
            //             y: 20.48
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(25).toDate(),
            //             y: 25.47
            //         },
            //         {
            //             x: moment().subtract(6, 'months').day(28).toDate(),
            //             y: 28.84
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(1).toDate(),
            //             y: 27.71
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(4).toDate(),
            //             y: 25.22
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(7).toDate(),
            //             y: 25.43
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(10).toDate(),
            //             y: 24.13
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(13).toDate(),
            //             y: 20.02
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(16).toDate(),
            //             y: 18.38
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(19).toDate(),
            //             y: 18.30
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(22).toDate(),
            //             y: 18.72
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(25).toDate(),
            //             y: 22.46
            //         },
            //         {
            //             x: moment().subtract(5, 'months').day(28).toDate(),
            //             y: 21.71
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(1).toDate(),
            //             y: 29.88
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(4).toDate(),
            //             y: 26.94
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(7).toDate(),
            //             y: 28.06
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(10).toDate(),
            //             y: 30.40
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(13).toDate(),
            //             y: 28.98
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(16).toDate(),
            //             y: 30.13
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(19).toDate(),
            //             y: 27.60
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(22).toDate(),
            //             y: 30.21
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(25).toDate(),
            //             y: 26.88
            //         },
            //         {
            //             x: moment().subtract(4, 'months').day(28).toDate(),
            //             y: 25.72
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(1).toDate(),
            //             y: 27.89
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(4).toDate(),
            //             y: 30.69
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(7).toDate(),
            //             y: 31.42
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(10).toDate(),
            //             y: 36.14
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(13).toDate(),
            //             y: 32.02
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(16).toDate(),
            //             y: 27.30
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(19).toDate(),
            //             y: 29.51
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(22).toDate(),
            //             y: 32.67
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(25).toDate(),
            //             y: 28.82
            //         },
            //         {
            //             x: moment().subtract(3, 'months').day(28).toDate(),
            //             y: 28.85
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(1).toDate(),
            //             y: 29.15
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(4).toDate(),
            //             y: 27.90
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(7).toDate(),
            //             y: 30.71
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(10).toDate(),
            //             y: 28.02
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(13).toDate(),
            //             y: 23.82
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(16).toDate(),
            //             y: 18.83
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(19).toDate(),
            //             y: 14.48
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(22).toDate(),
            //             y: 11.76
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(25).toDate(),
            //             y: 12.75
            //         },
            //         {
            //             x: moment().subtract(2, 'months').day(28).toDate(),
            //             y: 11.36
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(1).toDate(),
            //             y: 11.60
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(4).toDate(),
            //             y: 15.24
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(7).toDate(),
            //             y: 13.05
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(10).toDate(),
            //             y: 17.25
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(13).toDate(),
            //             y: 18.50
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(16).toDate(),
            //             y: 23.04
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(19).toDate(),
            //             y: 21.87
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(22).toDate(),
            //             y: 25.97
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(25).toDate(),
            //             y: 22.46
            //         },
            //         {
            //             x: moment().subtract(1, 'months').day(28).toDate(),
            //             y: 17.67
            //         }
            //     ]
            // }
        ]
    },
    budget            : {
        expenses     : 11763.34,
        expensesLimit: 20000,
        savings      : 10974.12,
        savingsGoal  : 250000,
        bills        : 1789.22,
        billsLimit   : 1000
    },
    previousStatement : {
        status : 'paid',
        date   : moment().startOf('day').subtract(15, 'days').format('LL'),
        limit  : 34500,
        spent  : 27221.21,
        minimum: 7331.94
    },
    currentStatement  : {
        status : 'pending',
        date   : moment().startOf('day').subtract(15, 'days').add(1, 'month').format('LL'),
        limit  : 34500,
        spent  : 39819.41,
        minimum: 9112.51
    },
    recentTransactions: [
        {
            id           : '1b6fd296-bc6a-4d45-bf4f-e45519a58cf5',
            transactionId: 'Basic',
            name         : '987',
            amount       : 21000,
            // status       : 'completed',
            // date         : '21000'
        },
        {
            id           : '2dec6074-98bd-4623-9526-6480e4776569',
            transactionId: 'House Rent Allowance',
            name         : '123',
            amount       : 4200,
            // status       : 'completed',
            // date         : '4200'
        },
        {
            id           : 'ae7c065f-4197-4021-a799-7a221822ad1d',
            transactionId: 'Medical Allowance',
            name         : '56456',
            amount       : 1828,
            // status       : 'pending',
            // date         : '2280'
        },
        {
            id           : '0c43dd40-74f6-49d5-848a-57a4a45772ab',
            transactionId: 'Conveyance Allowance',
            name         : '17420',
            amount       : 1647,
            // status       : 'completed',
            // date         : '1233'
        },
        {
            id           : 'e5c9f0ed-a64c-4bfe-a113-29f80b4e162c',
            transactionId: 'Total',
            name         : '12194',
            amount       : 1927,
            // status       : 'completed',
            // date         : '1234'
        }
    ]
};
