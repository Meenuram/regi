import { Component, ViewEncapsulation, Inject } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { FormControl, FormGroup ,FormBuilder,Validators } from '@angular/forms';
import { UtilityService } from 'app/shared/services/utility.service';
import CryptoJS from 'crypto-js';


@Component({
    selector     : 'account-details',
    templateUrl  : './account-details.component.html',
    styleUrls    : ['./account-details.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AccountDetailsComponent
{
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];
    accountdetails:boolean;
    userbranch:any;
    useraccno:any;
    useraccountname:any;
    userbankname:any;
    userbankbranch:any;
    userifsccode:any;
    userpfno:any;
    useruanno:any;
    useresino:any;

     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */

    branch:any;
    accountform:FormGroup;
    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,
        @Inject(SESSION_STORAGE) private storage: StorageService,private formBuilder: FormBuilder,
        private userService:UserService,public util:UtilityService
        )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';
        this.accountform = this.formBuilder.group({
            // ebranch: [null, [ Validators.required ]],
            eaccountnumber: [null, [ Validators.required ]],
            eaccountname: [null, [ Validators.required ]],
            ebankname: [null, [ Validators.required ]],
            ebanknumber: [null, [ Validators.required ]],
            ebankbranch: [null, [ Validators.required ]],
            eifsccode: [null, [ Validators.required ]],
            epfnumber:  [null, [ Validators.required ]],
            euannumber: [null, [ Validators.required ]],
            eesinumber: [null, [ Validators.required ]]
        });
      
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        var obj = { ts : new Date().getTime(), operation:"view-bank", bid:"10653721" };
        var sendjson= JSON.stringify(obj);
        var accpostData = CryptoJS.AES.encrypt(sendjson, '').toString();
        // console.log(JSON.stringify(obj),accpostData);

        
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });
            this.accountdetails=true;

            this.userbranch = localStorage.getItem('branch');
            if(this.userbranch == 0 || this.userbranch == "null"){
                this.userbranch = '';
            }else{
                this.userbranch = localStorage.getItem('branch');
            }

            this.useraccno = localStorage.getItem('accountnumber');
            // console.log(this.useraccno);
            if(this.useraccno == 0 || this.useraccno == 'null'){
                this.useraccno = '';
               
            }else{
                this.useraccno = localStorage.getItem('accountnumber');
            }

            this.useraccountname = localStorage.getItem('accountname');
            if(this.useraccountname == 0 || this.useraccountname == "null"){
                this.useraccountname = '';
            }else{
                this.useraccountname = localStorage.getItem('accountname');
            }

            this.userbankname = localStorage.getItem('bankname');
            if(this.userbankname == 0 || this.userbankname == "null"){
                this.userbankname = '';
            }else{
                this.userbankname = localStorage.getItem('bankname');
            }

            this.userbankbranch = localStorage.getItem('bankbranch');
            if(this.userbankbranch == 0 || this.userbankbranch == "null"){
                this.userbankbranch = '';
            }else{
                this.userbankbranch = localStorage.getItem('bankbranch');
                
            }

            this.userifsccode = localStorage.getItem('ifsccode');
            if(this.userifsccode == 0 || this.userifsccode == "null"){
                this.userifsccode = '';
                
            }else{
                this.userifsccode = localStorage.getItem('ifsccode');
            }

            this.userpfno = localStorage.getItem('pfno');
            if(this.userpfno == 0 || this.userpfno == "null"){
                this.userpfno = '';
            }else{
                this.userpfno = localStorage.getItem('pfno');
            }

            this.useruanno = localStorage.getItem('uanno');
            if(this.useruanno != 0 || this.useruanno != "null"){
                this.useruanno = '';
                
            }else{
                this.useruanno = localStorage.getItem('uanno');
            }

            this.useresino = localStorage.getItem('esino');
            if(this.useresino == 0 || this.useresino == "null"){                
                this.useresino = '';

            }else{
                this.useresino = localStorage.getItem('esino');


            }
    }

    // editAccount(){
    //     this.accountdetails=false;
    // }
    editAccountSave(){
        // this.accountform.get('ebranch').value//
        // this.accountform.get('eaccountnumber').value
        // this.accountform.get('eaccountname').value
        // this.accountform.get('ebanknumber').value
        // this.accountform.get('ebankname').value
        // this.accountform.get('ebankbranch').value
        // this.accountform.get('eifsccode').value
        // this.accountform.get('epfnumber').value
        // this.accountform.get('euannumber').value
        // this.accountform.get('eesinumber').value
        // const postData = {
            // "bkey":"bankDetailsUpdate",//
    //         "key":"EmployeeDataUpdate",
    //         "bankaccno":this.accountform.get('eaccountnumber').value,
    //         "acname":this.accountform.get('eaccountname').value,
    //         "bankname":this.accountform.get('ebankname').value,
    //         "branch":this.accountform.get('ebankbranch').value,
    //         "ifsccode":this.accountform.get('eifsccode').value,
    //         "pfno":this.accountform.get('epfnumber').value,
    //         "uanno":this.accountform.get('euannumber').value,
    //         "esino":this.accountform.get('eesinumber').value,
    //         "bid":localStorage.getItem('bid'),
    //         "gid":localStorage.getItem('gid')
    //     }
    //     console.log(postData)
    //     this.userService.getAccountupdate(postData)
    //         .subscribe((res) =>{
    //             console.log(res);
    //             var status = res.status;
    //             if(status==1){
    //                 this.accountdetails=true;
    //             }else{
    //                 alert("error");
    //             }
    //     })
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
    // get userbranch(): any {
    //     return localStorage.getItem('branch');
    // }
    // get useraccno(): any {
    //     return localStorage.getItem('accountnumber');
    // }
    // get useraccountname(): any {
    //     return localStorage.getItem('accountname');
    // }
    // get userbankname(): any {
    //     return localStorage.getItem('bankname');
    // }
    // get userbankbranch(): any {
    //     return localStorage.getItem('bankbranch');
    // }
    // get userifsccode(): any {
    //     return localStorage.getItem('ifsccode');
    // }
    // get userpfno(): any {
    //     return localStorage.getItem('pfno');
    // }
    // get useruanno(): any {
    //     return localStorage.getItem('uanno');
    // }
    // get useresino(): any {
    //     return localStorage.getItem('esino');
    // }
    editbio(){
        window.open("#/pages/bioforms", "_self");
    }
}
