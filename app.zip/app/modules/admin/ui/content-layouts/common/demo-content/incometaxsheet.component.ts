import { Component, ViewEncapsulation } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { Router } from '@angular/router';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
    selector     : 'incometaxsheet',
    templateUrl  : './incometaxsheet.component.html',
    styleUrls    : ['./incometaxsheet.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class IncometaxsheetComponent
{
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];

     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */

    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,private router: Router,public util:UtilityService
        )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();

      
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        this.router.navigate(['/ui/content-layouts/left-sidebar/fullheight/basic/personaldetails']);
        window.open("../main/incometax-sheet.php", "_blank"); 
    }

   

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
    // get userbranch(): any {
    //     return localStorage.getItem('branch');
    // }
    // get useraccno(): any {
    //     return localStorage.getItem('accountnumber');
    // }
    // get useraccountname(): any {
    //     return localStorage.getItem('accountname');
    // }
    // get userbankname(): any {
    //     return localStorage.getItem('bankname');
    // }
    // get userbankbranch(): any {
    //     return localStorage.getItem('bankbranch');
    // }
    // get userifsccode(): any {
    //     return localStorage.getItem('ifsccode');
    // }
    // get userpfno(): any {
    //     return localStorage.getItem('pfno');
    // }
    // get useruanno(): any {
    //     return localStorage.getItem('uanno');
    // }
    // get useresino(): any {
    //     return localStorage.getItem('esino');
    // }

}
