import { Route } from '@angular/router';
import { LeavesCountComponent } from './leaves-count.component';

export const leavescountRoutes: Route[] = [
    {
        path     : '',
        component: LeavesCountComponent
    }
];
