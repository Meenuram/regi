import { Component } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { UtilityService } from 'app/shared/services/utility.service';
import { DatePipe } from '@angular/common';
import * as _ from 'underscore';
import {DayPilot, DayPilotSchedulerComponent} from 'daypilot-pro-angular';
import { TimeGridSlicer } from '@fullcalendar/timegrid';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { environment } from 'environments/environment';
import { isNull } from 'lodash';

@Component({
    selector   : 'app-root',
    templateUrl: './app.component.html',
    styleUrls  : ['./app.component.scss']
})
export class AppComponent
{
    /**
     * Constructor
     */
    UserTeamimage:any;
    userSession:any;
    userTeam:any;
    myTeamsMember:any;
    userProfile:any;
    userGID:any;
    userBID:any;
    usertotalemp:any;
    useratoff:any;
    usernotoff:any;
    incentiveseriesData:any;
    userwalletdetails:any;
    userattendancedetails:any;
    userteamlead:any;
    ProfileTeamimage:any;
    eqltoken:any;
    current_date:any;
    first_date:any;
    checkkoutapplylist:any;
    checkout_date:any;
    personincentive:any;
    removeincentivechart:any;
    accdetailkey:any;
    tasklist:any;
    extravalue:any;
    eventlist:any;
    currentmonthsales:any;
    proimages:any;
    empcontactlist:any;
    operation:any;
    secret:any;
    yesterday:any;
    previousmonthsales:any;
    topsalesdata:any;
    newsfeed:any;
    cardData:any;
    fileinfo:any;
    category:any;
    getuploadimage:any;
    imagefilename:any;
    branchname:any;
    tablist:any;
    newsfeedinterval:any;
    getcardimages:any;
    displaylist:any;
    mybranch:any;
    mydepartment:any;
    mydesignation:any;
    myempid:any;
    myteamname:any;
    createddby:any;
    tllist:any;
    reportingid:any;
    getreport:any;
    companydetails:any;
    contactinfo:any;
    contactData:any;
    getreportdata:any;
    getpreviousreport:any;
    productinfo:any;
    productlist:any;
    productprice:any;
    showrecords:any;

    screenWidth: any;
    screenHeight: any;

    constructor(private userService:UserService,
        public util:UtilityService,private datePipe: DatePipe,private http: HttpClient
    )
    {
        this.util.invokeCardList.subscribe(value =>{
            this.displaycarddata();
            this.util.carddataList('hai');
        });
        this.util.invokeProfileImage.subscribe(value =>{
            this.getUserProfile(this.userGID,this.userBID);
        });
    }
    ngOnInit() {
        localStorage.setItem('gid', '836136547');
        localStorage.setItem('bid', '10653721');
        localStorage.setItem('secret', 'YzJWamNtVjBMREl4TGpjMU1TNHdOaTQzT0dsdVpHbGhSbWxzYVc1bmN3PT0=');
        // localStorage.setItem('getempdatakey',btoa(localStorage.getItem('gid') + 'TXhfVjJ4amVHUXhTa2hTYWtKYVZWUXdPUT09'));
        this.getuserSession();
        // this.getUserTeamimageFunction();
        // this.getUserProfile();
     }

    getuserSession() {
        this.userService.getuserSession()
        .subscribe((res) =>{
        // this.userSession = res.data;
        // this.userGID = this.userSession.gid;
        // this.userBID = this.userSession.bid;
        // console.log('session'+ JSON.stringify(this.userSession));
        // localStorage.setItem('gid',res.data.gid);
        // localStorage.setItem("teammebergid", res.data.gid);
        // localStorage.setItem('bid',res.data.bid);
        // localStorage.setItem('username',res.data.username);
        // localStorage.setItem('bidname',res.data.bidname);

        this.userGID = '836136547';
        localStorage.setItem('teammebergid',this.userGID);
        this.userBID = '10653721';
        this.getTeamImage();
        this.getUserProfile(this.userGID,this.userBID);
        this.getWallet();
        // this.topsalesmonth();
        // this.topsalesprevious();
        this.userService.getUserTeamimage(this.userBID)
        .subscribe((res) =>{
            localStorage.setItem("teamimage",  JSON.stringify(res.data));
            this.topsalesmonth();
            this.getSalaryDatas(this.userGID,this.userBID);
            this.getAttendanceData();
            this.getTeamLead();
            this.getIncentiveamount();
            this.applylistdata();
           
            // this.employeecontacts();
            // this.accountlistdata();
            // this.getTasklist();
            this.geteventlist();
            this.viewtablist();
            this.teamleadlist();
            this.displaycarddata();
            this.getbranch();
            this.dailyaccountreport();
            
        }, err => {
            console.log('Error', err);
            
        })

        }, err => {
            console.log('Error', err);
            
        })
        
    }

    getSalaryDatas(gid:any,bid:any){
        // this.userGID = '228936536';
        // this.userBID = '10653721';
        const postData = {
            "gid":this.userGID,
            "bid":this.userBID,
            // "key":"Z2V0U2FsYXJ5RGV0YWlscw=="
            "operation": btoa(this.userGID + 'TXhfVjJ4amVHUXhWWGxTYms1YVYwVnZNUT09'),
            "secret": environment.ANOTHER_API_SECRET
        };
        // console.log(postData)
        this.userService.getSalaryDetails(postData)
        .subscribe((res) =>{
            // console.log(res)
            localStorage.setItem("salaryData", JSON.stringify(res));
        })
    }

    getUserProfile(gid:any,bid:any) {
            const postData = {
                "gid":gid,
                "bid":bid,
                "operation": btoa(gid + 'TXhfVjJ4amVHUXhTa2hTYWtKYVZWUXdPUT09'),
                "secret": environment.ANOTHER_API_SECRET
                };
            this.userService.getUserProfile(postData)
            .subscribe((res) =>{
                this.userProfile = res.data;
                localStorage.setItem("myProfile", JSON.stringify(this.userProfile));
                // console.log(this.userProfile);
                localStorage.setItem('userimage', res.data[0].image);
                localStorage.setItem('myprofileimg', res.data[0].image);
                localStorage.setItem('myname', res.data[0].name);
                localStorage.setItem('mymobile', res.data[0].Mobile);  
                localStorage.setItem('name', res.data[0].name);
                localStorage.setItem('mymailid', res.data[0].personalemail);
                localStorage.setItem('mypan', res.data[0].pan);  
                localStorage.setItem('Gender', res.data[0].Gender);     
                localStorage.setItem('designation', res.data[0].designation);
                localStorage.setItem('mydesignation', res.data[0].designation);
                localStorage.setItem('following', res.following);
                localStorage.setItem('team', res.team.length);
                localStorage.setItem('eqltoken', res.kyctoken);
                localStorage.setItem('eqltoken', res.acctkey);
                localStorage.setItem('feedpagebid', res.encempbid);
                localStorage.setItem('feedpagegid', res.encempid);
                this.mybranch = this.userProfile[0].branch;
                this.mydepartment = this.userProfile[0].department;
                this.mydesignation = this.userProfile[0].designation;
                this.myempid = this.userProfile[0].employee_id;
                this.reportingid = this.userProfile[0].reporting_id;
                this.myteamname = this.userProfile[0].reporting_to;
                this.util.profileHeader('hai');
                this.eqltoken = res.kyctoken;
                // console.log(this.eqltoken);
                this.usertotalemp = res.totalEmp;
                localStorage.setItem("userTotalemp", JSON.stringify(this.usertotalemp));
                this.useratoff = res.atoffc;
                this.usernotoff = res.notoffc;
                this.userTeam = res.team;
                    this.myTeamsMember = setInterval(() => { 
                    this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
                    if(this.UserTeamimage){
                        console.log('if interval');
                        for(var i=0;i<this.userTeam.length;i++){
                            for(var j=0;j<this.UserTeamimage.length;j++){
                                if(this.userTeam[i].gid == this.UserTeamimage[j].gid){
                                    this.userTeam[i]['profileImg'] = this.UserTeamimage[j].image
                                    this.userTeam[i]['gender'] = this.UserTeamimage[j].gender
                                }
                
                            }
                        }
                        localStorage.setItem("myteam",  JSON.stringify(this.userTeam));
                        if(this.usertotalemp){
                            for(var i=0;i<this.usertotalemp.length;i++){
                                for(var j=0;j<this.UserTeamimage.length;j++){
                                    if(this.usertotalemp[i].gid == this.UserTeamimage[j].gid){
                                        this.usertotalemp[i]['profileImg'] = this.UserTeamimage[j].image
                                        this.usertotalemp[i]['gender'] = this.UserTeamimage[j].gender
                                    }
                    
                                }
                            }
                            }
                            if(this.useratoff){
                            for(var i=0;i<this.useratoff.length;i++){
                                for(var j=0;j<this.UserTeamimage.length;j++){
                                    if(this.useratoff[i].gid == this.UserTeamimage[j].gid){
                                        this.useratoff[i]['profileImg'] = this.UserTeamimage[j].image
                                        this.useratoff[i]['gender'] = this.UserTeamimage[j].gender
                                    }
                    
                                }
                            }
                            }
                            if(this.usernotoff){
                            for(var i=0;i<this.usernotoff.length;i++){
                                for(var j=0;j<this.UserTeamimage.length;j++){
                                    if(this.usernotoff[i].gid == this.UserTeamimage[j].gid){
                                        this.usernotoff[i]['profileImg'] = this.UserTeamimage[j].image
                                        this.usernotoff[i]['gender'] = this.UserTeamimage[j].gender
                                    }
                    
                                }
                            }
                            }
                            localStorage.setItem("totalempls", JSON.stringify(this.usertotalemp));
                            localStorage.setItem("atoffice", JSON.stringify(this.useratoff));
                            localStorage.setItem("notoffice", JSON.stringify(this.usernotoff));
                        clearInterval(this.myTeamsMember);
                    }else{ 
                        this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
                        console.log('else interval');
                    }
                },300);
             
            });
    }
    getIncentiveamount(){
        var date = new Date(); 
        var firstDay = new Date(date.getFullYear(),date.getMonth(), 1);
        this.first_date = this.datePipe.transform(firstDay,"yyyy-MM-dd");
        this.current_date = this.datePipe.transform(new Date(),"yyyy-MM-dd");
        // console.log(this.first_date,this.current_date);
        var incentivechart = [];

        const postdata = {
            "bid": "10653721",
            "from":this.first_date,
            "to":this.current_date,
            "optype":"getTopperform"
            }
        this.userService.getIncentive(postdata)
            .subscribe((res) =>{
            for(var i=0;i<res.length;i++){
                // if (res[i].transaction_amount == "59145") {
                //     res.splice(i,1);
                // } 
                if(res[i].transaction_type == 'credit' && res[i].transaction_amount >= 1000){
                    incentivechart.push({x: "Amount", y: res[i].transaction_amount});
                }          
            }
            
            this.removeincentivechart = _.shuffle(this.removeDuplicates(incentivechart,"y"));
            this.getIncentivepersonamount();
            // this.incentiveseriesData = [
            //     {
            //         name: 'Incentive Netpay',
            //         data: removeincentivechart
            //     }
            // ]
            
            })
    }
    getIncentivepersonamount(){
        var incentivepersonchart = [];
        const postData = {
            "bid":this.userBID,
            "gid":118473260,
            "akey":"d2FsbGV0S2V5",
            "base":1
        }
        this.userService.getIncentiveperson(postData)
        .subscribe((res) =>{
            // this.personincentive = res;
            for(var i=0;i<res.length;i++){
 
                if(res[i].transaction_type == 'credit'){
                    incentivepersonchart.push({x: "Amount", y: res[i].transaction_amount});
                }          
            }
        //    console.log(incentivepersonchart);
            this.incentiveseriesData = [
                {
                    name: 'Incentive Netpay',
                    data: this.removeincentivechart
                    // data: this.removeincentivechart.slice(0, 30)
                },
                {
                    name: 'Personal Netpay',
                    data: incentivepersonchart
                    // data: incentivepersonchart.slice(0,30)
                }
            ]
            localStorage.setItem("getincentivedata", JSON.stringify(this.incentiveseriesData));
            // console.log(this.incentiveseriesData )
            })
    }
    removeDuplicates(originalArray, prop) {
        var newArray = [];
        var lookupObject  = {};
    
        for(var i in originalArray) {
            
           lookupObject[originalArray[i][prop]] = originalArray[i];
        }
    
        for(i in lookupObject) {
            newArray.push(lookupObject[i]);
        }
         return newArray.sort((n1,n2) => n1.sortby - n2.sortby);
    }
    // getWallet(){
    //     this.userService.getWallet()
    //     .subscribe((res) =>{

    //     this.userwalletdetails = res.msg;
    //     this.seriesData = [
    //         {
    //             name: 'Credit',
    //             data: this.userwalletdetails
    //         }
    //     ]
    //     localStorage.setItem("getwalletdata", JSON.stringify(this.seriesData));
    //     })
    // }
    getWallet(){
        this.userService.getWallet()
        .subscribe((res) =>{

        this.userwalletdetails = res;
        // console.log(res)
        localStorage.setItem("getwalletdata", JSON.stringify(this.userwalletdetails));
        })
    }
    getAttendanceData(){
        this.userService.getAttendanceData()
        .subscribe((res) =>{

        this.userattendancedetails = res;
        // console.log(this.userattendancedetails);
        localStorage.setItem("getattendancedata", JSON.stringify(this.userattendancedetails));
        })
    }

    getTeamLead(){
        const postData = {
            "gid":this.userGID,
            "bid":this.userBID,
            // "x-api-key":"teamList"
            "operation": btoa(this.userGID + 'TXhfV2tWa1YyRkhTbFpsU0VKcVRURkZPUT09'),
            "secret": environment.ANOTHER_API_SECRET
        };
        this.userService.getTeamList(postData)
        .subscribe((res) =>{
            localStorage.setItem("teamleadlist", JSON.stringify(res));
        })
    }
    getTeamImage(){
        const postData = {
            "bid":this.userBID,
            "gid":this.userGID,
            "operation": btoa(this.userGID + 'TXhfVjJ4amVHUXhWWHBWYm14aFZqQmFNRmt6WXpsUVVUMDk='),
            "secret": environment.ANOTHER_API_SECRET
            // "api-key":"steams"
        };
        // console.log(postData)
        this.userService.getProfileteam(postData)
        .subscribe((res) =>{
            this.ProfileTeamimage = res.data;
            localStorage.setItem("profileteamimage", JSON.stringify(this.ProfileTeamimage));
        }) 
    } 
      
    applylistdata(){
        this.checkout_date = this.datePipe.transform(new Date(),"yyyy-MM");
        const postData = {
            "bid":this.userBID,
            "egid":this.userGID,
            "date":this.checkout_date,
            "apiKey":"applyList"
        }
        this.userService.getCheckoutapplylist(postData)
            .subscribe((res) =>{
                this.checkkoutapplylist = res.data;
                localStorage.setItem("checkoutapplylist", JSON.stringify(this.checkkoutapplylist));
                })
    }

    accountlistdata(){
        const postData = {
            "data":localStorage.getItem('eqltoken')
        }
        this.userService.getAccountDetails(postData)
            .subscribe((res) =>{
                // console.log(res);
            })
    }
    // getTasklist(){
    //     const postData = {
    //         "bid":this.userBID,
    //         "gid":this.userGID,
    //         "taskKey":"TaskManagement",
    //         "getType":"getTasks"
    //     };
    //     this.extravalue = [
    //         { name: "Breakfast", id:"100"},
    //         { name: "Lunch Break", id:"101"},
    //         { name: "Dinner Break", id:"102"},
    //         { name: "Tea/Coffee Break", id:"103"}
    //     ];
    //     this.userService.getTasknames(postData)
    //     .subscribe((res) =>{
    //         this.tasklist = res.tasknames;
    //         var mergevalue  = [...this.tasklist,...this.extravalue];
    //         this.tasklist.forEach(v => v.id += '');
    //         localStorage.setItem("tasknamelist", JSON.stringify(mergevalue));
    //     })
    // }

    geteventlist(){
        var eventdatalist = [];
        const postData = {
            "bid":this.userBID,
            "gid":this.userGID,
            "taskKey":"TaskManagement",
            "getType":"fetchTask",
            "date": "2020-09"
        };
        this.userService.getTasknames(postData)
        .subscribe((res) =>{
            this.eventlist = res.data;
            for(var i=0;i<this.eventlist.length;i++){
                eventdatalist.push({id: DayPilot.guid(), start: this.changedDateType(this.eventlist[i].start), end: this.changedDateType(this.eventlist[i].end), resource: this.eventlist[i].resourceid, text: this.eventlist[i].time});
            }
            localStorage.setItem("eventlist", JSON.stringify(eventdatalist));
        })
    }
    changedDateType(date){
        return new DayPilot.Date(date);
    }

//topthreesales
    topsalesmonth(){
        this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
        // var date = new Date(); 
        this.current_date = this.datePipe.transform(new Date(),"dd-MM-yyyy");
        let dte = new Date();
        dte.setDate(dte.getDate() - 1);
        // console.log(dte.toString());
        this.yesterday = this.datePipe.transform(dte,"dd-MM-yyyy");
        // console.log(this.yesterday);
        const postData = {
            "request": "sales",
            "apikey": "bedd1210-629e-48d7-bdf4-ddcb301c8ece",
            "bid": this.userBID,
            "gid":this.userGID,
            "date":this.current_date,
            "toppers":3
        }
        this.userService.topThreesales(postData)
            .subscribe((res) =>{
                this.topsalesdata = res;
                
                // for(var i=0;i<this.topsalesdata.length;i++){
                //     for(var j=0;j<this.UserTeamimage.length;j++){
                //         if(this.topsalesdata[i].gid == this.UserTeamimage[j].gid){
                //             this.topsalesdata[i]['profileImg'] = this.UserTeamimage[j].image
                //             this.topsalesdata[i]['gender'] = this.UserTeamimage[j].gender
                //         }
        
                //     }
                // }
                // console.log(this.topsalesdata)
                if(res){
                    if(res.Message!="No Record Found."){
                        this.currentmonthsales = res;
                        var current_date = this.datePipe.transform(new Date(),"MMMM d, yyyy");
                        localStorage.setItem("salesdate", current_date);
                        localStorage.setItem("topthreesales", JSON.stringify(this.currentmonthsales));
                    }else{
                        this.topsalesprevious();
                    }
                }
            })
    }
    topsalesprevious(){
        var dte = new Date();
        dte.setDate(dte.getDate() - 1);
        var current_date = this.datePipe.transform(dte,"MMMM d, yyyy");
        localStorage.setItem("salesdate", current_date);
        this.yesterday = this.datePipe.transform(dte,"dd-MM-yyyy");
        const postData = {
            "request": "sales",
            "apikey": "bedd1210-629e-48d7-bdf4-ddcb301c8ece",
            "bid": this.userBID,
            "gid":this.userGID,
            "date":this.yesterday,
            "toppers":3
        }
        this.userService.topThreesales(postData)
            .subscribe((res) =>{
                // console.log(res)
                this.previousmonthsales = res;
                // for(var i=0;i<this.previousmonthsales.length;i++){
                //     for(var j=0;j<this.UserTeamimage.length;j++){
                //         if(this.previousmonthsales[i].gid == this.UserTeamimage[j].gid){
                //             this.previousmonthsales[i]['profileImg'] = this.UserTeamimage[j].image
                //             this.previousmonthsales[i]['gender'] = this.UserTeamimage[j].gender
                //         }
        
                //     }
                // }
                // console.log(this.previousmonthsales);
                localStorage.setItem("topthreesales", JSON.stringify(this.previousmonthsales));
            })
    }
//Employee directory
    employeecontacts(){
        const postData = {
            "bid":this.userBID,
            "key":"empDirectory"
        }
        this.userService.empdirectory(postData)
            .subscribe((res) =>{
                this.empcontactlist = res.msg;
                console.log(this.empcontactlist);
                var empcontactList=[];
                this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
                for(var i=0;i<this.empcontactlist.length;i++){
                    // console.log(this.empcontactlist[i].gid)
                    this.empcontactlist[i].employeemaster["gid"] = this.empcontactlist[i].gid
                    for(var j=0;j<this.UserTeamimage.length;j++){
                        if(this.empcontactlist[i].employeemaster.gid == this.UserTeamimage[j].gid){
                            this.empcontactlist[i].employeemaster['profileImg'] = this.UserTeamimage[j].image
                        }
                        

                    }
                    empcontactList.push({id: DayPilot.guid(), name: this.empcontactlist[i].employeemaster.name, 
                        avatar: this.empcontactlist[i].employeemaster.profileImg, 
                        phoneNumbers: this.mobilenumbermerge(this.empcontactlist[i].employeemaster.personalmobile,this.empcontactlist[i].employeemaster.officemobile), 
                        job: this.empcontactlist[i].employeemaster.designation, 
                        emails: this.mergeEmail(this.empcontactlist[i].employeemaster.personalemail,this.empcontactlist[i].employeemaster.officeemail),
                        birthday:this.empcontactlist[i].employeemaster.DateOfBirth, 
                        address:this.removeArrayvalue(this.empcontactlist[i].employeemaster.Address)
                    });
                    
                }
               
                //  console.log(empcontactList);
                localStorage.setItem("employeecontactlist", JSON.stringify(empcontactList));
                })
    }
    removeArrayvalue(address){
        if(address){
            var obj = Object.assign({}, ...address);
            return _.values(obj).join();
        }
    }
    mobilenumbermerge(mob1,mob2){
      var  phoneNumbers = [
            {
                country: 'In',
                number : mob1,
                label  : 'Mobile'
            },
            {
                country: 'In',
                number : mob2,
                label  : 'Work'
            }
        ]
        return phoneNumbers;
    }
    mergeEmail(email1,email2){
        var emails  = [
            {
                email: email1,
                label: 'Personal'
            },
            {
                email: email2,
                label: 'Work'
            }
        ]
        return emails;
    }

    //branch display
    getbranch(){
        const postData = {
            "operation":"fetchBranch",
            "bid": localStorage.getItem('bid')
        };
        this.userService.getbranchname(postData)
            .subscribe((res) =>{
                this.branchname = res.msg;
                // console.log(this.branchname);
                localStorage.setItem("branchdetails",  JSON.stringify(this.branchname));
            })
    }
    //card page tab list
    viewtablist(){
    const postData = {
        "operation":"holidayList",
        "bid": localStorage.getItem('bid')
    };
    this.userService.broadcastfeeds(postData)
        .subscribe((res) =>{
            this.tablist = res.msg;
            localStorage.setItem("tablistdata",  JSON.stringify(this.tablist));
        })
    }
    //card data display
    displaycarddata(){
        this.getcardimages = [];
    const postData = {
        "operation":"selectFeeds",
        "bid": localStorage.getItem('bid')
    };
    this.userService.broadcastfeeds(postData)
        .subscribe((res) =>{
            // this.newsfeed = res;
            // this.newsfeed = res.filter((item)=>{return item.file_info});
            this.newsfeed = _.reject(res, function(item){ return (item.file_info == "null"); });
            // this.newsfeed.splice(15, 2)
            for(var i=0;i<this.newsfeed.length;i++){
                this.cardData = JSON.parse(this.newsfeed[i].card_data);
                this.fileinfo = JSON.parse(this.newsfeed[i].file_info);
                this.category = JSON.parse(this.newsfeed[i].viewfor);
                this.createddby = this.newsfeed[i].created_by;
                this.newsfeed[i]['cardname'] = this.cardData.name
                this.newsfeed[i]['cardtitle'] = this.cardData.title
                this.newsfeed[i]['cardtype'] = this.cardData.cardtype
                this.newsfeed[i]['carddescription'] = this.cardData.description
                this.newsfeed[i]['imagefilename'] = this.fileinfo.s3_file_name
                this.displayuploadimage(this.fileinfo.s3_file_name);
                this.newsfeed[i]['totype'] = this.category.category
                this.newsfeed[i]['to'] = this.category.subcategory
                this.newsfeed[i]['WhoView'] = "OtherCard";
                if(this.category.category == "Department" && this.category.subcategory == this.mydepartment){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }else if(this.category.category == "Designation" && this.category.subcategory == this.mydesignation){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }else if(this.category.category == "Individual" && this.category.subcategory == this.myempid){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }else if(this.category.category == "Team" && this.category.subcategory == this.myempid){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }else if(this.category.category == "Team" && this.category.subcategory == this.reportingid){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }else if(this.category.category == "Branch" && this.category.subcategory == this.mybranch){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }else if(this.category.category == "All"){
                    this.newsfeed[i]['WhoView'] = "MyCard";
                }
            }
            localStorage.setItem("newsfeeddata",  JSON.stringify(this.newsfeed));
            // console.log(_.where(this.newsfeed , {WhoView: "MyCard"}));
        })
        
    }
    displayuploadimage(s3_file_name){
        var s3_file = s3_file_name;
        const postData = {
            "process":"s3_signed_url",
            "request":"encrypt",
            // "gid":localStorage.getItem('feedpagegid'),
            "gid":this.createddby,
            "file_name":s3_file_name,
            "module":"hronboarding"
        }
        // console.log(postData)
        this.userService.feedsimageuploadselect(postData)
        .subscribe((res) =>{
            this.getuploadimage = res;
            this.getcardimages.push({imgvalue :this.getuploadimage.s3_signed_url,filevalue : s3_file});
            // console.log(this.getcardimages)
            localStorage.setItem("feedimages",  JSON.stringify(this.getcardimages));
            for(var i=0;i<this.newsfeed.length;i++){
                for(var j=0;j<this.getcardimages.length;j++){
                    if(this.newsfeed[i].imagefilename == this.getcardimages[j].filevalue){
                        this.newsfeed[i]['cardimage'] = this.getcardimages[j].imgvalue
                    }
                }
            }
            localStorage.setItem("newsfeeddata",  JSON.stringify(this.newsfeed));
        })
    }
    //card page TL list
    teamleadlist(){
        const postData = {
            "operation":"tlList",
            "bid": localStorage.getItem('bid')
        };
        this.userService.broadcastfeeds(postData)
            .subscribe((res) =>{
                this.tllist = res.msg;
                localStorage.setItem("teamleaddata",  JSON.stringify(this.tllist));
            })
    }
    //Daily Accounting Report
    dailyaccountreport(){
        this.current_date = this.datePipe.transform(new Date(),"yyyy-MM-dd");
        let dte = new Date();
        dte.setDate(dte.getDate() - 1);
        this.yesterday = this.datePipe.transform(dte,"yyyy-MM-dd");
        // var getdataproduct = [];
        const postData = {
            "method": "dailyMailer",
            "bid": localStorage.getItem('bid'),
            // "date":this.current_date
            // "bid": "1568264750657", //1592305495331
            // "date":"2021-02-03"
        };
        this.userService.getdailyreport(postData)
            .subscribe((res) =>{
                this.getreport = res;
                if(res){
                    if(res.company_details && res.sales_details && res.receipt_details && res.purchase_details && res.payments_details && res.product_creation && res.contact_creation && res.documents && res.attendance_data && res.engagement_id && res.business_name && res.business_advisor_num && res.date){
                        this.getreportdata = res;
                        // var current_date = this.datePipe.transform(new Date(),"dd-MMM-yyyy");
                        // localStorage.setItem("reportdates", current_date);
                        localStorage.setItem("accountingreport",  JSON.stringify(this.getreportdata));
                    }
                    // else{
                    //     this.previousaccountreport();
                    // }
                }
                 localStorage.setItem("accountingreport",  JSON.stringify(this.getreport));
            })
    }
    // previousaccountreport(){
    //     var dte = new Date();
    //     dte.setDate(dte.getDate() - 1);
    //     var current_date = this.datePipe.transform(dte,"yyyy-MM-dd");
    //     localStorage.setItem("reportdates", current_date);
    //     this.yesterday = this.datePipe.transform(dte,"yyyy-MM-dd");
    //     const postData = {
    //         "method": "dailyMailer",
    //         "bid": localStorage.getItem('bid'),
    //         "date":this.yesterday
    //     };
    //     this.userService.getdailyreport(postData)
    //         .subscribe((res) =>{
    //             this.getpreviousreport = res;
    //             localStorage.setItem("accountingreport",  JSON.stringify(this.getpreviousreport));
    //         })
    // }
    
}
