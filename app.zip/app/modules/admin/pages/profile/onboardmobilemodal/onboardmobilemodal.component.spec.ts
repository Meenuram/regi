import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardmobilemodalComponent } from './onboardmobilemodal.component';

describe('OnboardmobilemodalComponent', () => {
  let component: OnboardmobilemodalComponent;
  let fixture: ComponentFixture<OnboardmobilemodalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardmobilemodalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardmobilemodalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
