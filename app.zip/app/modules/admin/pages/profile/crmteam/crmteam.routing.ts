import { Route } from '@angular/router';
import { CrmteamComponent } from './crmteam.component';

export const CrmteamRoutes: Route[] = [
    {
        path     : '',
        component: CrmteamComponent
    }
];
