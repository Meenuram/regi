import { Route } from '@angular/router';
import { EmployeeCalendarComponent } from './employee-calendar.component';
// import { CreditReportComponent } from 'app/modules/admin/pages/credit-report/credit-report.component';

export const employeecalendarRoutes: Route[] = [
    {
        path     : '',
        component: EmployeeCalendarComponent
    }
];
