import { Route } from '@angular/router';
import { UsereditprofilefeedComponent } from './usereditprofilefeed.component';

export const usereditprofilefeedRoutes: Route[] = [
    {
        path     : '',
        component: UsereditprofilefeedComponent
    }
];
