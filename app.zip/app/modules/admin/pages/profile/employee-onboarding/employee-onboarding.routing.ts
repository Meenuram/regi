import { Route } from '@angular/router';
import { EmployeeOnboardingComponent } from './employee-onboarding.component';

export const EmployeeOnboardingRoutes: Route[] = [
    {
        path     : '',
        component: EmployeeOnboardingComponent
    }
];
