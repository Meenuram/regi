import { Route } from '@angular/router';
import { ProfileimagecapComponent } from './profileimagecap.component';
// import { ProfileimagecapComponent } from 'app/modules/admin/pages/profileimagecap/profileimagecap.component';

export const profileimagecapRoutes: Route[] = [
    {
        path     : '',
        component: ProfileimagecapComponent
    }
];
