import { Component, ViewEncapsulation, Inject } from '@angular/core';
import { FormControl, FormGroup ,FormBuilder,Validators } from '@angular/forms';
import { HttpHandler } from '@angular/common/http';
import { UserService } from 'app/shared/services/user.service';
import { Router } from '@angular/router';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject, empty } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UtilityService } from 'app/shared/services/utility.service';
import { DatePipe } from '@angular/common';

@Component({
    selector     : 'leaves-count',
    templateUrl  : './leaves-count.component.html',
    styleUrls    : ['./leaves-count.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LeavesCountComponent
{

    //userProfile : any;
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */

    /**
     * Constructor
     */
    leaveform: FormGroup;
    category: any;
    categoryName:any;
    reason:any;
    leavetype: any;
    onductyTypes:any;
    reasonvalue:any;
    leavetypevalue:any;
    discription:any;
    fromtime:any;
    totime:any;
    fromdate:any;
    todate:any;
    onductytypevalue:any;
    instandapproval:any;
    otpsubmit:any;
    otp:any;
    instantstatus_res:any;
    myProfile:any;
    leaveapproval:any;
    shift:any;
    shiftid:any;
    shifttype:any;
    clleavesbalance:any;
    clleavescredited:any;
    clleavestaken:any;
    unpaidleavescredited:any;
    unpaidleavestaken:any;
    unpaidleavesbalance:any;
    changedCategoryvalue:any;
    manualleaveform: FormGroup;
    teamleaddata:any;
    empList:any;
    //force checkout
    forcecheckoutform: FormGroup;
    changedRequestvalue:any;
    requesttype:any;
    date:any;
    exptime:any;
    actualtime:any;
    changetime:any;
    forcereason:any;
    current_date:any;
    form:any;
    actualcheckin:any;
    moduleid:any;
    //force checkout list
    requestlistdata:any;
    date_count:any;
    instentivemonths:any;
    checkout_date:any;


    Category = [
      {value: '1', viewValue: 'Leave'},
      {value: '2', viewValue: 'Permission'},
      {value: '4', viewValue: 'Half Day Leave'},
      {value: '5', viewValue: 'On Duty'},
      {value: '6', viewValue: 'Holiday Working Permission'}
    ];
    Reason: any = [
        {value: '13', viewValue: 'Travel'},
        {value: '14', viewValue: 'Health Reason'},
        {value: '15', viewValue: 'Family Event'},
        {value: '16', viewValue: 'Friend Event'},
        {value: '17', viewValue: 'Exam or Education'},
        {value: '18', viewValue: 'Vacation'},
        {value: '19', viewValue: 'Other Reasons'}
    ]
    Perreason: any = [
        {value: '7', viewValue: 'Friend Meeting'},
        {value: '8', viewValue: 'Family Meeting'},
        {value: '9', viewValue: 'Family Function'},
        {value: '10', viewValue: 'Health Reasons'},
        {value: '11', viewValue: 'Bank Work'},
        {value: '12', viewValue: 'Others'}
    ]
    Ondutyreason: any = [
        {value: '3', viewValue: 'Client Meeting'},
        {value: '4', viewValue: 'Field Work'},
        {value: '5', viewValue: 'Office Work'},
        {value: '6', viewValue: 'Ground Force'}
    ]
    leaveType: any = [
        {value: '1', viewValue: 'Leave'}
    ] 
    onductyType: any = [
        {value: '1', viewValue: 'Full Day'},
        {value: '2', viewValue: 'Either'}
    ]
    ManualReason: any = [
        {value: '13', viewValue: 'Travel'},
        {value: '14', viewValue: 'Health Reason'},
        {value: '15', viewValue: 'Family Event'},
        {value: '16', viewValue: 'Friend Event'},
        {value: '17', viewValue: 'Exam or Education'},
        {value: '18', viewValue: 'Vacation'},
        {value: '19', viewValue: 'Other Reasons'}
    ]
    ManualleaveType: any = [
        {value: '1', viewValue: 'Leave'}
    ] 
    //force checkout
    ForceCategory = [
        {value: '1', viewValue: 'Late checkin'},
        {value: '2', viewValue: 'Force Checkout'}
      ];
    exptime_display:boolean;
    actualtime_display:boolean;
    changetime_display:boolean;
    forcereason_display:boolean;
    dates:any;
    //force checkout   

    reason_display:boolean;
    leaveType_display:boolean;
    onductyType_display:boolean;
    formdate_display:boolean;
    todate_display:boolean;
    formtime_display:boolean;
    totime_display:boolean;
    description_display:boolean;
    date_display:boolean;
    otp_display:boolean;
    fullcontent:boolean;
    constructor(private formBuilder: FormBuilder,@Inject(SESSION_STORAGE) private storage: StorageService,
    private userService:UserService,private router: Router, private _treoMediaWatcherService: TreoMediaWatcherService,public util:UtilityService,private datePipe: DatePipe)
    {

        //this.getUserProfile();
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';


        this.leaveform = this.formBuilder.group({
            //category: [null, [ Validators.required ] ],
            categoryName: [null, [ Validators.required ]],
            reason: [null, [ Validators.required ]],
            leaveTypes: [null, [ Validators.required ]],
            onductyTypes: [null, [ Validators.required ]],
            discription: [null, [ Validators.required ]],
            fromtime: [null, [ Validators.required ]],
            totime:  [null, [ Validators.required ]],
            fromdate: [null, [ Validators.required ]],
            todate: [null, [ Validators.required ]],
            otp: [null, [ Validators.required ]]
        });
        this.manualleaveform = this.formBuilder.group({
            employeeName: [null, [ Validators.required ]],
            date: [null, [ Validators.required ]],
            leavetype: [null, [ Validators.required ]],
            reason: [null, [ Validators.required ]],
            description: [null, [ Validators.required ]]
        });
        //force checkout
        this.forcecheckoutform = this.formBuilder.group({
            requesttype: [null, [ Validators.required ]],
            date: [null, [ Validators.required ]],
            exptime: [null, [ Validators.required ]],
            actualtime: [null, [ Validators.required ]],
            changetime: [null, [ Validators.required ]],
            reason: [null, [ Validators.required ]],
        });

        this.date_display = true;
        this.reason_display = true;
        this.leaveType_display = true;
        this.onductyType_display = false;
        this.formdate_display = true;
        this.todate_display = true;
        this.formtime_display = false;
        this.totime_display = false;
        this.description_display = true;
        this.instandapproval=true;
        this.otpsubmit=false;
        this.otp_display=false;
        this.fullcontent=true;
        //force checkout
        this.exptime_display = false;
        this.actualtime_display = false;
        this.changetime_display = false;
        this.forcereason_display = false;
    
    }
    clearbutton(){
        this.manualleaveform.reset();
        this.forcecheckoutform.reset();
    }
    manualsubmit(){
        var current_date = new Date().toLocaleString().slice(0,10);
        const postData = {
        "bid":localStorage.getItem('bid'),
        "egid":this.manualleaveform.get('employeeName').value,
        "hrgid":localStorage.getItem('gid'),
        "date":this.manualleaveform.get('date').value,
        "type":this.manualleaveform.get('leavetype').value,
        "apiKey":"manual",
        "description":this.manualleaveform.get('description').value
     };
     console.log(postData);
     this.userService.manualFormsubmit(postData)
            .subscribe((res) =>{
                console.log(res);
                var result = res;
            });
    }
    onOptionsSelected(event){
        console.log(event)
    }
    changeCategory(e) {
        console.log(this.leaveform.get('categoryName').value)
        this.changedCategoryvalue = this.leaveform.get('categoryName').value;
        var changedCategory = this.leaveform.get('categoryName').value;
        if(changedCategory == '1'){
            this.reason=this.reason;
            this.reason_display = true;
            this.leaveType_display = true;
            this.onductyType_display = false;
            this.formdate_display = true;
            this.todate_display = true;
            this.formtime_display = false;
            this.totime_display = false;
            this.description_display = true;
            this.date_display = true;

        }else if(changedCategory == '2'){
            this.reason=this.Perreason;
            this.reason_display = true;
            this.leaveType_display = false;
            this.onductyType_display = false;
            this.formdate_display = true;
            this.todate_display = false;
            this.formtime_display = true;
            this.totime_display = true;
            this.description_display = true;
            this.date_display = true;

        }else if(changedCategory == '4'){
            this.reason_display = true;
            this.leaveType_display = true;
            this.onductyType_display = false;
            this.formdate_display = true;
            this.todate_display = false;
            this.formtime_display = false;
            this.totime_display = false;
            this.description_display = true;
            this.date_display = false;

        }else if(changedCategory == '5'){
            this.reason=this.Ondutyreason;
            this.reason_display = true;
            this.leaveType_display = false;
            this.onductyType_display = true;
            this.formdate_display = true;
            this.todate_display = false;
            this.formtime_display = true;
            this.totime_display = true;
            this.description_display = true;
            this.date_display = true;

        }else if(changedCategory == '6'){
            this.reason_display = false;
            this.leaveType_display = false;
            this.onductyType_display = false;
            this.formdate_display = true;
            this.todate_display = false;
            this.formtime_display = false;
            this.totime_display = false;
            this.description_display = true;
            this.date_display = true;
        }
        
      }
      changeReason(e) {
        console.log(this.leaveform.get('reason').value)
        this.reasonvalue = this.leaveform.get('reason').value;
      }
      changeleavetype(e) {
        console.log(this.leaveform.get('leaveTypes').value)
        if(typeof this.leaveform.get('leaveTypes').value !== 'undefined'){
            this.leavetypevalue =this.leaveform.get('leaveTypes').value
        }else{
            this.leavetypevalue =null;
        }
       // this.leavetypevalue = if(this.leaveform.get('leaveTypes').value){this.leaveform.get('leaveTypes').value};
      }
      changeonductytype(e) {
        console.log(this.leaveform.get('onductyTypes').value)
        this.onductytypevalue = this.leaveform.get('onductyTypes').value
      }
    requestsubmit(){
        var current_date = new Date().toLocaleString().slice(0,10);
        const postData = {
        "bid":localStorage.getItem('bid'),
        "gid":localStorage.getItem('gid'),
        "instantstatus":'0',
        "type":this.changedCategoryvalue,
        "reasontype":this.reasonvalue,
        "description":this.leaveform.get('discription').value,
        "compensativetype":this.leavetypevalue,
        "starttime":this.leaveform.get('fromtime').value,
        "endtime":this.leaveform.get('totime').value,
        "currshiftid":this.shiftid,
        "todate":this.leaveform.get('todate').value,
        "date":this.leaveform.get('fromdate').value,
        "currshifttype":this.shifttype,
        "ondutytype":this.onductytypevalue,
        "currminperday":"00:00:00"
     };
     console.log(postData);
     this.userService.leaveFormsubmit(postData)
            .subscribe((res) =>{
                console.log(res);
                var result = res;
                // var errorres = result.error;
                // var result = errorres.text;
                if(result == 'description'){
                         alert('Enter the description');
                    }else if(result == 'otp'){
                        alert('need to open otp modal');
                    }else if(result == '3'){
                        alert('already applied for this date');
                    }else if(result == '2'){
                        alert('holiday');
                    }else if(result == 'incorrect'){
                        alert('holiday');
                    }else if(result == 'incorrect'){
                        alert('date wrong');
                    }else if(result == 'timeout'){
                        alert(' permission time exceeds');
                    }else if(result == 'chktime'){
                        alert('check your type and time');
                    }else if (result == 'instant'){
                        alert('two days only allowed');
                    }else if(result == '1'){
                        this.leaveform.reset();
                        alert('applied successfully');
                    }
                    else{
                        alert('applied failed');
                    }
               
            });
    }
    instandapprovalbtn(){
       
        if(typeof this.leavetypevalue != 'undefined'){
            this.leavetypevalue =this.leavetypevalue;
        }else{
            this.leavetypevalue = null;
        }
        const postData = {
                "bid":localStorage.getItem('bid'),
                "gid":localStorage.getItem('gid'),
                "instantstatus":1,
                "type":this.changedCategoryvalue,
                "reasontype":this.reasonvalue,
                "description":this.leaveform.get('discription').value,
                "compensativetype":this.leavetypevalue,
                "starttime":this.leaveform.get('fromtime').value,
                "endtime":this.leaveform.get('totime').value,
                "currshiftid":this.shiftid,
                "todate":this.leaveform.get('todate').value,
                "date":this.leaveform.get('fromdate').value,
                "currshifttype":this.shifttype,
                "ondutytype":1,
                "currminperday":"00:00:00"
           
     };
     console.log(postData);
     this.userService.leaveFormsubmit(postData)
            .subscribe((res) =>{
                console.log(res);
                var result = res;
                // var errorres = result.error;
                // var result = errorres.text;
                if(result == 'description'){
                         alert('Enter the description');
                    }else if(result == 'otp'){
                        alert('need to open otp modal');
                    }else if(result == '3'){
                        alert('already applied for this date');
                    }else if(result == '2'){
                        alert('holiday');
                    }else if(result == 'incorrect'){
                        alert('holiday');
                    }else if(result == 'incorrect'){
                        alert('date wrong');
                    }else if(result == 'timeout'){
                        alert(' permission time exceeds');
                    }else if(result == 'chktime'){
                        alert('check your type and time');
                    }else if (result == 'instant'){
                        alert('two days only allowed');
                    }else if(result == '1'){
                        alert('applied successfully');
                    }
                    else{
                        alert('applied failed');
                    }
            },
            error => {
                
                var errorres = error.error;
                var result = errorres.text;
                    
                   
                    if(result == 'description'){
                         alert('Enter the description');
                    }else if(result == 'otp'){
                        this.instandapproval=false;
                        this.otpsubmit=true;
                        this.otp_display=true;
                        this.fullcontent=false;
                        alert('OTP sent your mail and mobile number');
                    }else if(result == '3'){
                        alert('already applied for this date');
                    }else if(result == '2'){
                        alert('holiday');
                    }else if(result == 'incorrect'){
                        alert('holiday');
                    }else if(result == 'incorrect'){
                        alert('date wrong');
                    }else if(result == 'timeout'){
                        alert(' permission time exceeds');
                    }else if(result == 'chktime'){
                        alert('check your type and time');
                    }else if (result == 'instant'){
                        alert('two days only allowed');
                    }else if(result == '1'){
                        alert('applied successfully');
                    }else{
                    // this.instandapproval=true;
                    // this.otpsubmit=false;
                    // this.otp_display=false;
                    // this.fullcontent=true;
                    alert("contact our tech team");
                }
                
            }
            );
    }
    otpsubmitbtn(){
        var otp = this.leaveform.get('otp').value
        if(otp){
            this.instandapproval=true;
            this.otpsubmit=false;
            this.otp_display=false;
            this.fullcontent=true;
            const postData = {
                "gid":localStorage.getItem('gid'),
                "bid":localStorage.getItem('bid'),
                "key":"approve",
                "otp":otp
            };
            this.userService.getotpsubmit(postData)
                .subscribe((res) =>{
                    if((res) && (res.data=="Approved")){
                        alert("Success");
                        this.leaveform.reset();
                    }else{
                        alert("Success");
                    }
            });
        }else{
            alert('enter otp');
        }
    }

    
    /**
     * On init
     */
    ngOnInit()
    {
        this.instentivemonths = this.datePipe.transform(new Date(),"MMM yyyy");
        this.util.profileHeader('hai');
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });

        this.myProfile = JSON.parse(localStorage.getItem("myProfile"));
        //this.leaveapproval = JSON.parse(localStorage.getItem('leaveapproval'));
        console.log(this.myProfile);
        this.shift = this.myProfile.shift;
        this.shiftid = this.myProfile.shiftid;
        this.shifttype = this.myProfile.shifttype;
        console.log(this.shift, this.shiftid, this.shifttype);
        this.displayleavebalance();
        this.displayleavebalance();
        this.leaveapproval = JSON.parse(localStorage.getItem('leaveapproval'));
        this.teamleaddata = JSON.parse(localStorage.getItem("teamleadlist"));
            console.log(this.teamleaddata)
             var status = this.teamleaddata.status;
            if(status == 1){
                console.log('success');
                this.empList = this.teamleaddata.data;
            }else{
                console.log('error');
                this.empList = [];
            }
        //force checkout list
        this.requestlistdata = JSON.parse(localStorage.getItem("checkoutapplylist"));
    }



    displayleavebalance(){
        const postData = {
            "gid":localStorage.getItem('gid'),
            "bid":localStorage.getItem('bid'),
            "key":"leaveBalance"
        };
        this.userService.userleavebalance(postData)
            .subscribe((res) =>{
                var leavebalancecl = res.data[0];
                var cl = leavebalancecl.CL;
                
              this.clleavesbalance = cl.leavesbalance;
              if(this.clleavesbalance > 0){
                this.leaveType = [{
                    "key": "CL",
                    "text": "Casual Leave"
                }]
              }else{
                this.leaveType = [
                {
                    "key": "Leave",
                    "text": "Leave"
                }]
              }
//leavebalance
            var leavebalancecl = res.data[0];
            var cl = leavebalancecl.CL;
            var leavebalanceunpaid = res.data[0];
            var unpaid = leavebalanceunpaid.unpaid;

            this.clleavesbalance = cl.leavesbalance;
            this.clleavescredited = cl.leavescredited;
            this.clleavestaken = cl.leavestaken ? cl.leavestaken : 0;

            this.unpaidleavescredited = unpaid.leavescredited;
            this.unpaidleavestaken = unpaid.leavestaken;
            this.unpaidleavesbalance = unpaid.leavesbalance;
        }) 
    } 

    getDates()
{
    this.changedRequestvalue = this.forcecheckoutform.get('requesttype').value;
    this.dates = this.forcecheckoutform.get('date').value;
    console.log(this.dates)
    const postData = {
        "bid":localStorage.getItem('bid'),
        "egid":localStorage.getItem('gid'),
        "hrgid":localStorage.getItem('gid'),
        "date":this.dates,
        "type":this.changedRequestvalue,
        "apiKey":"checkoutSelect",
        "description":"test"
    }
    this.userService.getForcecheck(postData)
        .subscribe((res) =>{
            var result = res.msg;
            console.log(result);
            this.forcecheckoutform.controls['exptime'].setValue(result.expected_checkin);
            this.forcecheckoutform.controls['actualtime'].setValue(result.actual_checkin);
            this.forcecheckoutform.controls['changetime'].setValue(result.actual_checkin);
            this.actualcheckin = result.actual_checkin;
            this.moduleid = result.id;
            })
    this.exptime_display = true;
    this.actualtime_display = true;
    this.changetime_display = true;
    this.reason_display = true;
}
forcesubmitbtn(){
    const postData = {
        "bid":localStorage.getItem('bid'),
        "egid":localStorage.getItem('gid'),
        "hrgid":localStorage.getItem('gid'),
        "apiKey":"checkOut",
        "moduleid":this.moduleid,
        "actualtime":this.actualcheckin,
        "changetime":this.forcecheckoutform.get('changetime').value,
        "date":this.dates,
        "description":this.forcecheckoutform.get('reason').value,
        "type":this.changedRequestvalue
    }
    console.log(postData);
    this.userService.getForcecheck(postData)
        .subscribe((res) =>{
            var result = res;
            console.log(result);
            
            })
}
changeRequest(e) {
    this.changedRequestvalue = this.forcecheckoutform.get('requesttype').value; 
};

increase(){
    this.date_count++;
    console.log(this.date_count);
    var myDate = new Date();
    myDate.setMonth(myDate.getMonth() - this.date_count);
    this.instentivemonths = this.datePipe.transform(myDate,"MMM yyyy");
    this.applylistdata(this.instentivemonths);
}
decrease(){
    
    console.log(this.date_count);
    if(this.date_count != 0){
    this.date_count--;
    var myDate = new Date();
    myDate.setMonth(myDate.getMonth() - this.date_count);
    this.instentivemonths = this.datePipe.transform(myDate,"MMM yyyy");
    this.applylistdata(this.instentivemonths);
    }
}

applylistdata(instentivemonths){
    this.checkout_date = this.datePipe.transform(instentivemonths,"yyyy-MM");
    const postData = {
        "bid":localStorage.getItem("bid"),
        "egid":localStorage.getItem("gid"),
        "date":this.checkout_date,
        "apiKey":"applyList"
    }
    this.userService.getCheckoutapplylist(postData)
        .subscribe((res) =>{
            console.log(res)
            var result = res.status
            if(result == 1){
                this.requestlistdata = res.data;
            }else{
                this.requestlistdata = [];
            }
            
            })
}

    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
    

}
