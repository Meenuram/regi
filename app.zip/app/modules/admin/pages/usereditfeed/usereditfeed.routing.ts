import { Route } from '@angular/router';
import { UsereditfeedComponent } from 'app/modules/admin/pages/usereditfeed/usereditfeed.component';

export const usereditfeedRoutes: Route[] = [
    {
        path     : '',
        component: UsereditfeedComponent
    }
];
