import { Route } from '@angular/router';
import { DocumentsComponent } from 'app/modules/admin/pages/documents/documents.component';

export const documentsRoutes: Route[] = [
    {
        path     : '',
        component: DocumentsComponent
    }
];
