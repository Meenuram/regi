import { NgModule } from '@angular/core';
import { ForceCheckoutComponent } from 'app/modules/admin/ui/content-layouts/common/demo-content/force-checkout.component';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { TreoNavigationModule } from '@treo/components/navigation';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { SharedModule } from 'app/shared/shared.module';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TreoCardModule } from '@treo/components/card';
import { LeaveformSidebarContentModule } from '../demo-sidebar-content/leaveform-sidebar-content.module';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatSelectModule } from '@angular/material/select';

@NgModule({
    declarations: [
        ForceCheckoutComponent
    ],
    imports     : [
        RouterModule.forChild([]),
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatInputModule,
        MatTooltipModule,
        TreoCardModule,
        MatMenuModule,
        MatSidenavModule,
        SharedModule,
        LeaveformSidebarContentModule,
        MatIconModule,
        MatProgressBarModule,
        TreoNavigationModule,
        MatCheckboxModule,
        MatIconModule,
        MatSelectModule,
        MatDatepickerModule,
        FormsModule
    ],
    exports     : [
        ForceCheckoutComponent
    ]
})
export class ForceCheckoutModule
{
}
