import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import {WebcamImage} from 'ngx-webcam';
import { Subject, Observable } from 'rxjs';
import { UserService } from 'app/shared/services/user.service';

@Component({
  selector: 'app-persondetails',
  templateUrl: './persondetails.component.html',
  styleUrls: ['./persondetails.component.scss']
})
export class PersondetailsComponent implements OnInit {
  userwebcam:boolean;
  myprofileimg:any;
  fileToUpload: any;
  imageUrl: any;

  webcamSrc:any;
  fileSrc:any;

  constructor(public dialogRef: MatDialogRef<PersondetailsComponent>, private userService:UserService) { 
    this.userwebcam = false; 
    this.webcamSrc = true;
    this.fileSrc = false;
  }

//
  public webcamImage: WebcamImage = null; 
    private trigger: Subject<void> = new Subject<void>(); 
    triggerSnapshot(): void {
        this.userwebcam = true; 
        this.trigger.next(); 
    } 
    handleImage(webcamImage: WebcamImage): void { 
      console.info('Saved webcam image', webcamImage.imageAsDataUrl); 
      var profile = webcamImage.imageAsDataUrl; 
      console.log(profile);
      const postData = profile;
      this.userService.profileImageupload(postData)
          .subscribe((res) =>{
          console.log(res);
          this.dialogRef.close();
          // window.location.reload();
      })
    } 
//
//image upload
handleFileInput(file: FileList) {
  this.fileSrc = true;
  this.webcamSrc = false;
  this.userwebcam = true; 
  this.fileToUpload = file.item(0);
  //Show image preview
  let reader = new FileReader();
  reader.onload = (event: any) => {
    this.imageUrl = event.target.result;
    console.log(this.imageUrl)
    this.userService.profileImageupload(this.imageUrl)
        .subscribe((res) =>{
        console.log(res);
        this.dialogRef.close();
        window.location.reload();
    })
  }
  reader.readAsDataURL(this.fileToUpload);
}
//image upload   
    public get triggerObservable(): Observable<void> { 
    return this.trigger.asObservable(); 
    } 
    

  ngOnInit(): void {
  }
    actionFunction() {
      alert("You have logged out.");
      this.closeModal();
    }

    // If the user clicks the cancel button a.k.a. the go back button, then\
    // just close the modal
    closeModal() {
      this.dialogRef.close();
    }
}
