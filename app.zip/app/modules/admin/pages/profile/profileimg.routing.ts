import { Route } from '@angular/router';
import { ProfileimgComponent } from './profileimg.component';
// import { ProfileimgComponent } from 'app/modules/admin/pages/profile/profileimg.component';

export const profileimgRoutes: Route[] = [
    {
        path     : '',
        component: ProfileimgComponent
    }
];
