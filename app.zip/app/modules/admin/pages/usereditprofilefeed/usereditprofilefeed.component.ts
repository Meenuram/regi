import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
import { Router,ActivatedRoute } from '@angular/router';
import { environment } from 'environments/environment';
import { DayPilot, DayPilotSchedulerComponent } from 'daypilot-pro-angular';
import { DatePipe } from '@angular/common';
import {TeamComponent} from 'app/modules/admin/ui/content-layouts/common/demo-content/team.component';
import * as _ from 'underscore';

@Component({
    selector       : 'usereditprofilefeed',
    templateUrl    : './usereditprofilefeed.component.html',
    styleUrls      : ['./usereditprofilefeed.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class UsereditprofilefeedComponent implements OnInit{
   
    myTeamsMember : any;
    fromSearch:any;
    topsales:any;
    newsfeed:any;
    cardData:any;
    fileinfo:any;
    category:any;
    getuploadimage:any;
    imagefilename:any;
    branchname:any;
    tablist:any;
    newsfeedinterval:any;
    getcardimages:any;
    displaylist:any;
    mybranch:any;
    mydepartment:any;
    mydesignation:any;
    myempid:any;
    myteamname:any;
    createddby:any;
    reportingid:any;
    datanews:any;
    profiledata:any;
    myProfiledata:any;
    feeddatalength:any;
    feedpageimages:any;
    pagespinner:Boolean=true;

     /**
     * Constructor
     *
     * @param {ActivatedRoute} _activatedRoute
     */
    constructor(private _activatedRoute: ActivatedRoute,private userService:UserService,private router: Router,private datePipe: DatePipe,private activatedRoute: ActivatedRoute)
    {
        this.pagespinner=true;
    }
viewtablist(){
    const postData = {
        "operation":"holidayList",
        "bid": localStorage.getItem('bid')
    };
    this.userService.broadcastfeeds(postData)
        .subscribe((res) =>{
            this.tablist = res.msg;
            localStorage.setItem("tablistdata",  JSON.stringify(this.tablist));
        })
    }
ngOnInit() {
    
        this.viewtablist();
        this.myProfiledata = setInterval(() => { 
            this.profiledata = JSON.parse(localStorage.getItem("myProfile"));
            if(this.profiledata){
                this.mybranch = this.profiledata[0].branch;
                this.mydepartment = this.profiledata[0].department;
                this.mydesignation = this.profiledata[0].designation;
                this.myempid = this.profiledata[0].employee_id;
                this.reportingid = this.profiledata[0].reporting_id;
                this.myteamname = this.profiledata[0].reporting_to;
                this.abcd();
                clearInterval(this.myProfiledata);
            }else{
                this.profiledata = JSON.parse(localStorage.getItem("myProfile"));
            }
        },500);
    
    //
        this.myTeamsMember = setInterval(() => { 
            this.datanews = localStorage.getItem("newsfeeddata");
            this.feedpageimages = localStorage.getItem("feedimages");
            if(this.datanews && this.feedpageimages){
                console.log("if interval");
               //if(this.datanews.length == this.feeddatalength){
                this.router.navigate(['/ui/cards']);
               //}
               this.pagespinner=false;
               clearInterval(this.myTeamsMember);
            }else{
                    this.datanews = localStorage.getItem("newsfeeddata");
                    this.feedpageimages = localStorage.getItem("feedimages");
                }
        },500);
}
abcd(){
    console.log('abcd')
    this.getcardimages = [];
    const postData = {
        "operation":"selectFeeds",
        "bid": localStorage.getItem('bid')
    };
    this.userService.broadcastfeeds(postData)
    .subscribe((res) =>{
        this.newsfeed = _.reject(res, function(item){ return (item.file_info == "null"); });
        
        for(var i=0;i<this.newsfeed.length;i++){
            this.cardData = JSON.parse(this.newsfeed[i].card_data);
            this.fileinfo = JSON.parse(this.newsfeed[i].file_info);
            this.category = JSON.parse(this.newsfeed[i].viewfor);
            this.createddby = this.newsfeed[i].created_by;
            this.newsfeed[i]['cardname'] = this.cardData.name
            this.newsfeed[i]['cardtitle'] = this.cardData.title
            this.newsfeed[i]['cardtype'] = this.cardData.cardtype
            this.newsfeed[i]['carddescription'] = this.cardData.description
            this.newsfeed[i]['imagefilename'] = this.fileinfo.s3_file_name
            this.displayuploadimage(this.fileinfo.s3_file_name);
            this.newsfeed[i]['totype'] = this.category.category
            this.newsfeed[i]['to'] = this.category.subcategory
            this.newsfeed[i]['WhoView'] = "OtherCard";
            if(this.category.category == "Department" && this.category.subcategory == this.mydepartment){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }else if(this.category.category == "Designation" && this.category.subcategory == this.mydesignation){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }else if(this.category.category == "Individual" && this.category.subcategory == this.myempid){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }else if(this.category.category == "Team" && this.category.subcategory == this.myempid){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }else if(this.category.category == "Team" && this.category.subcategory == this.reportingid){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }else if(this.category.category == "Branch" && this.category.subcategory == this.mybranch){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }else if(this.category.category == "All"){
                this.newsfeed[i]['WhoView'] = "MyCard";
            }
        }
        // console.log("Useredit--"+JSON.stringify(this.newsfeed))
        // localStorage.setItem("newsfeeddata",  JSON.stringify(this.newsfeed));
        
    })
}
//
displayuploadimage(s3_file_name){
    var s3_file = s3_file_name;
    const postData = {
        "process":"s3_signed_url",
        "request":"encrypt",
        // "gid":localStorage.getItem('feedpagegid'),
        "gid":this.createddby,
        "file_name":s3_file_name,
        "module":"hronboarding"
    }
    // console.log(postData)
    this.userService.feedsimageuploadselect(postData)
    .subscribe((res) =>{
        this.getuploadimage = res;
        this.getcardimages.push({imgvalue :this.getuploadimage.s3_signed_url,filevalue : s3_file});
        localStorage.setItem("feedimages",  JSON.stringify(this.getcardimages));
        for(var i=0;i<this.newsfeed.length;i++){
            for(var j=0;j<this.getcardimages.length;j++){
                if(this.newsfeed[i].imagefilename == this.getcardimages[j].filevalue){
                    this.newsfeed[i]['cardimage'] = this.getcardimages[j].imgvalue
                }
            }
        }
        localStorage.setItem("newsfeeddata",  JSON.stringify(this.newsfeed));
    })
}

}
