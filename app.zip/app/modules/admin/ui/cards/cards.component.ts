import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, QueryList, Renderer2, ViewChildren, ViewEncapsulation } from '@angular/core';
import { MatButtonToggleChange } from '@angular/material/button-toggle';
import { TreoCardComponent } from '@treo/components/card';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CardModalComponent } from 'app/modules/admin/pages/profile/card-modal/card-modal.component';
import * as _ from 'underscore';
import { UtilityService } from 'app/shared/services/utility.service';

@Component({
    selector       : 'cards',
    templateUrl    : './cards.component.html',
    styleUrls      : ['./cards.component.scss'],
    encapsulation  : ViewEncapsulation.None
    // changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardsComponent implements AfterViewInit
{
    filters: string[];
    numberOfCards: any;
    selectedFilter: string;
    newsdata:any;
    tablistevents:any;
    holidayname:any;
    getuploadimages:any;
    newsdatas:any;
    sortbyid:any;
    holidaynames:any;
    // Private
    @ViewChildren(TreoCardComponent, {read: ElementRef})
    private _treoCards: QueryList<ElementRef>;

    /**
     * Constructor
     *
     * @param {Renderer2} _renderer2
     */
    constructor(
        private _renderer2: Renderer2,
        public matDialog: MatDialog,
        public dialog: MatDialog,
        public util:UtilityService
    )
    {
        this.util.profileHeader('hai..');
       
        // this.sortbyid = _.sortBy(this.newsdata, 'id');
        this.util.invokeDataList.subscribe(value =>{
            setTimeout(() => {             
            this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
            // console.log(this.newsdata)
            this.newsdata = _.where(this.newsdata , {WhoView: "MyCard"})
            
            this.holidaynames=[]
            var tablistevents = JSON.parse(localStorage.getItem("tablistdata"));
            var holidayname = _.pluck(tablistevents, 'holiday');
            var listdata = _.sortBy(holidayname);
            for(var i=0;i<listdata.length;i++){
                var key=listdata[i].replace(/ /g,"_");
                if(key == "All"){
                    var count =  this.newsdata.length
                }else{
                    var count = this.newsdata.filter((obj) => obj.cardtype === key).length;
                }
                this.holidaynames.push({value1 :key,value2:count})
            } 
            this.filters = this.holidaynames;
            // console.log(this.newsdata)  
            // console.log(this.holidaynames)     
         }, 3000);
        });
    }
    ngOnInit() {
        this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
        this.newsdata = _.where(this.newsdata , {WhoView: "MyCard"})
        // console.log("card--"+JSON.stringify(this.newsdata));
        this.holidaynames=[];
        var tablistevents = JSON.parse(localStorage.getItem("tablistdata"));
        var holidayname = _.pluck(tablistevents, 'holiday');
        var listdata = _.sortBy(holidayname);
        for(var i=0;i<listdata.length;i++){
            var key=listdata[i].replace(/ /g,"_");
            if(key == "All"){
                var count =  this.newsdata.length
            }else{
                var count = this.newsdata.filter((obj) => obj.cardtype === key).length;
            }
            this.holidaynames.push({value1 :key,value2:count})
        }
        // Set the defaults  
        // this.filters = ['all', 'article', 'listing', 'list', 'info', 'shopping', 'pricing', 'testimonial', 'post', 'test'];
        // this.filters = ['all', 'Christmas-Cards', 'Newyear-Cards', 'Birthday-Cards', 'Appreciation-Cards', 'Service-Anneversary-Wishes', 'Diwali-Cards', 'Pongal-Cards'];
        this.filters = this.holidaynames;
        // console.log(this.filters)
        this.numberOfCards = {};
        this.selectedFilter = 'All';
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * After view init
     */
    ngAfterViewInit(): void
    {
        // Calculate the number of cards
        // this._calcNumberOfCards();

        // Filter the cards for the first time
        this._filterCards();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Private methods
    // -----------------------------------------------------------------------------------------------------

    private _calcNumberOfCards(): void
    {
        // Prepare the numberOfCards object
        this.numberOfCards = {};

        // Prepare the count
        let count = 0;

        // Go through the filters
        this.filters.forEach((filter) => {

            // For each filter, calculate the card count
            if ( filter === 'All' )
            {
                count = this._treoCards.length;
            }
            else
            {
                count = this.numberOfCards[filter] = this._treoCards.filter((treoCard) => treoCard.nativeElement.classList.contains('filter-' + filter)).length;
            }

            // Fill the numberOfCards object with the counts
            this.numberOfCards[filter] = count;
        });
    }

    /**
     * Filter the cards based on the selected filter
     *
     * @private
     */
    _filterCards(): void
    {
        // Go through all treo-cards
        this._treoCards.forEach((treoCard) => {

            // If the 'all' filter is selected...
            if ( this.selectedFilter === 'All' )
            {
                // Remove hidden class from all cards
                treoCard.nativeElement.classList.remove('hidden');
            }
            // Otherwise...
            else
            {
                // If the card has the class name that matches the selected filter...
                if ( treoCard.nativeElement.classList.contains('filter-' + this.selectedFilter) )
                {
                    // Remove the hidden class
                    treoCard.nativeElement.classList.remove('hidden');
                }
                // Otherwise
                else
                {
                    // Add the hidden class
                    treoCard.nativeElement.classList.add('hidden');
                }
            }
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * On filter change
     *
     * @param change
     */
    onFilterChange(change: MatButtonToggleChange): void
    {
        // Set the filter
        this.selectedFilter = change.value;
        if(this.selectedFilter != "All"){
            this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
            this.newsdata =  _.where(this.newsdata , {cardtype: this.selectedFilter});
            this.newsdata = _.where(this.newsdata , {WhoView: "MyCard"})
        }else{
            this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
            this.newsdata = _.where(this.newsdata , {WhoView: "MyCard"})
        }
        console.log(this.newsdata)
        // Filter the cards
        this._filterCards();
    }
    openShare() {
        this.dialog.open(CardModalComponent, {
            panelClass      : ['card-page-form'],
          data: {
          }
        });
      }

}
// localStorage.getItem("newsfeeddata");