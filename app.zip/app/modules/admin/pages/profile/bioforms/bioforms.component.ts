import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileInput } from 'ngx-material-file-input';
import * as _ from 'underscore';
import { UserService } from 'app/shared/services/user.service';

@Component({
    selector     : 'bioforms',
    templateUrl  : './bioforms.component.html',
    styleUrls    : ['./bioforms.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class BioformsComponent implements OnInit
{
    horizontalStepperForm: FormGroup;
    verticalStepperForm: FormGroup;

    userProfile:any;
    department:any;
    branch:any;
    dob:any;
    address1:any;
    address2:any;
    Mobile:any;
    MyShift:any;
    emp_id:any;
    name:any;
    fathername:any;
    personalmail:any;
    gender:any;
    status:any;
    nationality:any;
    language:any;
    blood:any;
    aadhaar:any;
    pan:any;
    zipcode:any;
    city:any;
    state:any;
    country:any;
    designation:any;
    doj:any;
    reportingto:any;
    extension:any;
    officemail:any;
    officemobile:any;
    accountnumber:any;
    bankbranch:any;
    bankname:any;
    ifsccode:any;
    pfno:any;
    uanno:any;
    esino:any;
    bioform:any;
    formdatas:any;
    directoryinfo:any;
    Personalinfo:any;
    bankaccountinfo:any;
    accountname:any;
    userbankname:any;
    useraccno:any;
    userbankbranch:any;
    userifsccode:any;
    userpfno:any;
    useruanno:any;
    useresino:any;
    useraddressLine1:any;
    useraddressLine2:any;
    userzipCode:any;
    usercity:any;
    userstate:any;
    usercountry:any;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,private userService:UserService
    )
    {
         // Vertical stepper form
         this.verticalStepperForm = this._formBuilder.group({
            step1: this._formBuilder.group({
                dateofjoining: [''],
                reportingto: [''],
                employeeid: [''],
                designation: [''],
                extension: [''],
                email   : [''],
                personalmobile: [''],
                officemobile: [''],
                shifttime: [''],
                branch: [''],
                department: ['']
            }),
            step2: this._formBuilder.group({
                name: [''],
                fathername: [''],
                mobilenumber : [''],
                dob : [''],
                personalmail : [''],
                gender : [''],
                maritalstatus : [''],
                nationality : [''],
                languageknown : [''],
                blood : [''],
                aadhaar : [''],
                pan : [''],
                zipcode : [],
                address1    : [''],
                address2    : [''],
                city : [''],
                state : [''],
                country : ['']
            }),
            step3: this._formBuilder.group({
                accountnumber : [''],
                accountname : [''],
                bankname : [''],
                bankbranch : [''],
                ifsccode : [''],
                pfnumber : [''],
                uannumber : [''],
                esinumber : ['']
            }),
            step4: this._formBuilder.group({
                pushNotifications: ['everything']
            })
        });
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {

        this.userProfile = JSON.parse(localStorage.getItem("myProfile"));
        // console.log(this.userProfile);
        this.userProfile = this.userProfile[0];
        // console.log(this.userProfile);
        // console.log( _.isArray(this.userProfile))

        //Directory
        this.emp_id = this.userProfile.employee_id;
        this.verticalStepperForm.patchValue({step1: {employeeid: this.emp_id}})
        this.designation = this.userProfile.designation;
        this.verticalStepperForm.patchValue({step1: {designation: this.designation}})
        this.doj = this.userProfile.doj;
        this.verticalStepperForm.patchValue({step1: {dateofjoining: this.doj}})
        this.reportingto = this.userProfile.reporting_to;
        this.verticalStepperForm.patchValue({step1: {reportingto: this.reportingto}})
        this.extension = this.userProfile.extention;
        this.verticalStepperForm.patchValue({step1: {extension: this.extension}})
        this.officemail = this.userProfile.officeemail;
        this.verticalStepperForm.patchValue({step1: {email: this.officemail}})
        this.personalmail = this.userProfile.personalmobile;
        this.verticalStepperForm.patchValue({step1: {personalmobile: this.personalmail}})
        this.officemobile = this.userProfile.officemobile;
        this.verticalStepperForm.patchValue({step1: {officemobile: this.officemobile}})
        this.MyShift = this.userProfile.myshifttime;
        this.verticalStepperForm.patchValue({step1: {shifttime: this.MyShift}})
        this.branch = this.userProfile.branch;
        this.verticalStepperForm.patchValue({step1: {branch: this.branch}})
        this.department = this.userProfile.department;
        this.verticalStepperForm.patchValue({step1: {department: this.department}})
        //Personal
        this.dob = this.userProfile.dob;
        this.verticalStepperForm.patchValue({step2: {dob: this.dob}})
        this.address1 = this.userProfile.AddressLine1;
        this.verticalStepperForm.patchValue({step2: {address1: this.address1}})
        this.address2 = this.userProfile.AddressLine2;
        this.verticalStepperForm.patchValue({step2: {address2: this.address2}})
        this.Mobile = this.userProfile.Mobile;
        this.verticalStepperForm.patchValue({step2: {mobilenumber: this.Mobile}})
        this.name = this.userProfile.name;
        this.verticalStepperForm.patchValue({step2: {name: this.name}})
        this.fathername = this.userProfile.FatherName;
        this.verticalStepperForm.patchValue({step2: {fathername: this.fathername}})
        this.personalmail = this.userProfile.personalemail;
        this.verticalStepperForm.patchValue({step2: {personalmail: this.personalmail}})
        this.gender = this.userProfile.Gender;
        this.verticalStepperForm.patchValue({step2: {gender: this.gender}})
        this.status = this.userProfile.MaritalStatus;
        this.verticalStepperForm.patchValue({step2: {maritalstatus: this.status}})
        this.nationality = this.userProfile.Nationality;
        this.verticalStepperForm.patchValue({step2: {nationality: this.nationality}})
        this.language = this.userProfile.LanguageKnown;
        this.verticalStepperForm.patchValue({step2: {languageknown: this.language}})
        this.blood = this.userProfile.Blood;
        this.verticalStepperForm.patchValue({step2: {blood: this.blood}})
        this.aadhaar = this.userProfile.aadhaar;
        this.verticalStepperForm.patchValue({step2: {aadhaar: this.aadhaar}})
        this.pan = this.userProfile.pan;
        this.verticalStepperForm.patchValue({step2: {pan: this.pan}})
        this.zipcode = this.userProfile.ZipCode;
        this.verticalStepperForm.patchValue({step2: {zipcode: this.zipcode}})
        this.city = this.userProfile.City;
        this.verticalStepperForm.patchValue({step2: {city: this.city}})
        this.state = this.userProfile.State;
        this.verticalStepperForm.patchValue({step2: {state: this.state}})
        this.country = this.userProfile.Country;
        this.verticalStepperForm.patchValue({step2: {country: this.country}})
        //BankAccount
        this.accountnumber = this.userProfile.accountnumber;
        console.log(this.accountnumber)
        this.verticalStepperForm.patchValue({step3: {accountnumber: this.accountnumber}})
        this.accountname = this.userProfile.accountname;
        this.verticalStepperForm.patchValue({step3: {accountname: this.accountname}})
        this.bankbranch = this.userProfile.bankbranch;
        this.verticalStepperForm.patchValue({step3: {bankbranch: this.bankbranch}})
        this.bankname = this.userProfile.bankname;
        this.verticalStepperForm.patchValue({step3: {bankname: this.bankname}})
        this.ifsccode = this.userProfile.ifsccode;
        this.verticalStepperForm.patchValue({step3: {ifsccode: this.ifsccode}})
        this.pfno = this.userProfile.pfno;
        this.verticalStepperForm.patchValue({step3: {pfnumber: this.pfno}})
        this.uanno = this.userProfile.uanno;
        this.verticalStepperForm.patchValue({step3: {uannumber: this.uanno}})
        this.esino = this.userProfile.esino;
        this.verticalStepperForm.patchValue({step3: {esinumber: this.esino}})
    }
    // savepersonalinfo(){
    //     this.bioform = this.verticalStepperForm.value;
    //     this.Personalinfo = this.bioform.step2;
    //     const postData = {
    //         "bid": localStorage.getItem('bid'),
    //         "gid": localStorage.getItem('gid'),
    //         "key":"addressUpdate",
    //         "AddressLine1": this.Personalinfo.address1,
    //         "AddressLine2": this.Personalinfo.address2,
    //         "ZipCode": this.Personalinfo.zipcode,
    //         "City": this.Personalinfo.city,
    //         "State": this.Personalinfo.state,
    //         "Country": this.Personalinfo.country
    //     }
    //     console.log(postData)
    //     this.userService.getAccountupdate(postData)
    //         .subscribe((res) =>{
    //             var status = res.status;
    //             console.log(status)
    //             this.useraddressLine1 = localStorage.setItem('AddressLine1', this.Personalinfo.address1);
    //             this.useraddressLine2 = localStorage.setItem('AddressLine2', this.Personalinfo.address2);
    //             this.userzipCode = localStorage.setItem('ZipCode', this.Personalinfo.zipcode);
    //             this.usercity = localStorage.setItem('City', this.Personalinfo.city);
    //             this.userstate = localStorage.setItem('State', this.Personalinfo.state);
    //             this.usercountry = localStorage.setItem('Country', this.Personalinfo.country);
    //         });
    // }
    saveforminfo(){
        this.bioform = this.verticalStepperForm.value;
        // this.directoryinfo = this.bioform.step1;
        // this.Personalinfo = this.bioform.step2;
        this.bankaccountinfo = this.bioform.step3;
        // console.log(this.bankaccountinfo);
        // this.formdatas = Object.assign(this.bioform.step1,this.bioform.step2,this.bioform.step3,this.bioform.step4);
        const postData = {
            // "bid": localStorage.getItem('bid'),
            // "gid": localStorage.getItem('gid'),
            // // "values": this.formdatas,
            // "key":"EmployeeDataUpdate",
            // "AddressLine1": this.Personalinfo.address1,
            // "AddressLine2": this.Personalinfo.address2,
            // "ZipCode": this.Personalinfo.zipcode,
            // "City": this.Personalinfo.city,
            // "State": this.Personalinfo.state,
            // "Country": this.Personalinfo.country,
            // // "salutions"
            // "name": this.Personalinfo.name,
            // // "lname"
            // "personal_mob": this.Personalinfo.Mobile,
            // "personal_mail": this.Personalinfo.personalmail,
            // "DateOfBirth": this.Personalinfo.dob,
            // "FatherName": this.Personalinfo.fathername,
            // "Gender": this.Personalinfo.gender,
            // "MaritalStatus": this.Personalinfo.status,
            // "Nationality": this.Personalinfo.nationality,
            // "PAN": this.Personalinfo.pan,
            // "AadhaarNo": this.Personalinfo.aadhaar,
            // // "hrname"
            // // "hrgid"

            //bank account
            "bid": localStorage.getItem('bid'),
            "gid": localStorage.getItem('gid'),
            "key":"EmployeeDataUpdate",
            "bankaccno": this.bankaccountinfo.accountnumber,
            "acname": this.bankaccountinfo.accountname,
            "bankname": this.bankaccountinfo.bankname,
            "branch": this.bankaccountinfo.bankbranch,
            "ifsccode": this.bankaccountinfo.ifsccode,
            "pfno": this.bankaccountinfo.pfnumber,
            "esino": this.bankaccountinfo.esinumber,
            "uanmo": this.bankaccountinfo.uannumber,
         };
         console.log(postData)
        //  this.userService.bioinfoupdate(postData)
        this.userService.getAccountupdate(postData)
            .subscribe((res) =>{
                var status = res;
                console.log(status)
                this.useraccno = localStorage.setItem('accountnumber', this.bankaccountinfo.accountnumber);
                this.userbankname = localStorage.setItem('bankname', this.bankaccountinfo.accountname);
                this.userbankname = localStorage.setItem('bankname', this.bankaccountinfo.bankname);
                this.userbankbranch = localStorage.setItem('bankbranch', this.bankaccountinfo.bankbranch);
                this.userifsccode = localStorage.setItem('ifsccode', this.bankaccountinfo.ifsccode);
                this.userpfno = localStorage.setItem('pfno', this.bankaccountinfo.pfnumber);
                this.useruanno = localStorage.setItem('uanno', this.bankaccountinfo.uannumber);
                this.useresino = localStorage.setItem('esino', this.bankaccountinfo.esinumber);
                if(status.status == '1'){
                    alert('Bank Account Updated');
                    // window.location.reload();
                    window.location.href = '#/pages/basicinfo';
                  }else if (status.status == '0'){
                    alert('Error');
                    window.location.reload();
                  }
            });
    }
}
