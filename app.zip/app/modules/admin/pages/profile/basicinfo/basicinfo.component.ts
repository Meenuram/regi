import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'app/shared/services/user.service';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { UtilityService } from 'app/shared/services/utility.service';

@Component({
    selector     : 'basicinfo',
    templateUrl  : './basicinfo.component.html',
    styleUrls    : ['./basicinfo.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class BasicinfoComponent implements OnInit
{
    isLinear = false;
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    userfname:any;
    usermobileno:any;
    userdob:any;
    userpemail:any;
    usergender:any;
    usermaritalStatus:any;
    usernationality:any;
    userlanguageKnown:any;
    userblood:any;
    useraadhaar:any;
    userpan:any;
    useraddressLine1:any;
    useraddressLine2:any;
    userzipCode:any;
    usercity:any;
    userstate:any;
    usercountry:any;
    //acc
    userbranch:any;
    useraccno:any;
    useraccountname:any;
    userbankname:any;
    userbankbranch:any;
    userifsccode:any;
    userpfno:any;
    useruanno:any;
    useresino:any;

    /**
     * Constructor
     *
     * @param {FormBuilder} _formBuilder
     */
    constructor(
        private _formBuilder: FormBuilder,
        private userService:UserService,public util:UtilityService
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        this.firstFormGroup = this._formBuilder.group({
            firstCtrl: ['', Validators.required]
          });
          this.secondFormGroup = this._formBuilder.group({
            secondCtrl: ['', Validators.required]
          });
        this.util.profileHeader('hai');
        this.userfname = localStorage.getItem('FatherName');
            if(this.userfname == 0 || this.userfname == "null"){
                this.userfname = '';
            }else{
                this.userfname = localStorage.getItem('FatherName');
            }

            this.usermobileno = localStorage.getItem('Mobile');
            if(this.usermobileno == 0 || this.usermobileno == "null"){
                this.usermobileno = '';
            }else{
                this.usermobileno = localStorage.getItem('Mobile');
            }

            this.userdob = localStorage.getItem('dob');
            if(this.userdob == 0 || this.userdob == "null"){
                this.userdob = '';
            }else{
                this.userdob = localStorage.getItem('dob');
            }

            this.userpemail = localStorage.getItem('personalemail');
            if(this.userpemail == 0 || this.userpemail == "null"){
                this.userpemail = '';
            }else{
                this.userpemail = localStorage.getItem('personalemail');
            }

            this.usergender = localStorage.getItem('Gender');
            if(this.usergender == 0 || this.usergender == "null"){
                this.usergender = '';
            }else{
                this.usergender = localStorage.getItem('Gender');
            }
            
            this.usermaritalStatus = localStorage.getItem('MaritalStatus');
            if(this.usermaritalStatus == 0 || this.usermaritalStatus == "null"){
                this.usermaritalStatus = '';
            }else{
                this.usermaritalStatus = localStorage.getItem('MaritalStatus');
            }
            
            this.usernationality = localStorage.getItem('Nationality');
            if(this.usernationality == 0 || this.usernationality == "null"){
                this.usernationality = '';
            }else{
                this.usernationality = localStorage.getItem('Nationality');
            }
            
            this.userlanguageKnown = localStorage.getItem('LanguageKnown');
            if(this.userlanguageKnown == 0 || this.userlanguageKnown == "null"){
                this.userlanguageKnown = '';
            }else{
                this.userlanguageKnown = localStorage.getItem('LanguageKnown');
            }
            
            this.userblood = localStorage.getItem('Blood');
            if(this.userblood == 0 || this.userblood == "null"){
                this.userblood = '';
            }else{
                this.userblood = localStorage.getItem('Blood');
            }
            
            this.useraadhaar = localStorage.getItem('aadhaar');
            if(this.useraadhaar == 0 || this.useraadhaar == "null"){
                this.useraadhaar = '';
            }else{
                this.useraadhaar = localStorage.getItem('aadhaar');
            }
            
            this.userpan = localStorage.getItem('pan');
            if(this.userpan == 0 || this.userpan == "null"){
                this.userpan = '';
            }else{
                this.userpan = localStorage.getItem('pan');
            }
            
            this.useraddressLine1 = localStorage.getItem('AddressLine1');
            if(this.useraddressLine1 == 0 || this.useraddressLine1 == "null"){
                this.useraddressLine1 = '';
            }else{
                this.useraddressLine1 = localStorage.getItem('AddressLine1');
            }
            
            this.useraddressLine2 = localStorage.getItem('AddressLine2');
            if(this.useraddressLine2 == 0 || this.useraddressLine2 == "null"){
                this.useraddressLine2 = '';
            }else{
                this.useraddressLine2 = localStorage.getItem('AddressLine2');
            }
            
            this.userzipCode = localStorage.getItem('ZipCode');
            if(this.userzipCode == 0 || this.userzipCode == "null"){
                this.userzipCode = '';
            }else{
                this.userzipCode = localStorage.getItem('ZipCode');
            }
            
            this.usercity = localStorage.getItem('City');
            if(this.usercity == 0 || this.usercity == "null"){
                this.usercity = '';
            }else{
                this.usercity = localStorage.getItem('City');
            }
            
            this.userstate = localStorage.getItem('State');
            if(this.userstate == 0 || this.usercity == "null"){
                this.userstate = '';
            }else{
                this.userstate = localStorage.getItem('State');
            }
            
            this.usercountry = localStorage.getItem('Country');
            if(this.usercountry == 0 || this.usercountry == "null"){
                this.usercountry = '';
            }else{
                this.usercountry = localStorage.getItem('Country');
            }
            //acc
            this.userbranch = localStorage.getItem('branch');
            if(this.userbranch == 0 || this.userbranch == "null"){
                this.userbranch = '';
            }else{
                this.userbranch = localStorage.getItem('branch');
            }

            this.useraccno = localStorage.getItem('accountnumber');
            // console.log(this.useraccno);
            if(this.useraccno == 0 || this.useraccno == 'null'){
                this.useraccno = '';
               
            }else{
                this.useraccno = localStorage.getItem('accountnumber');
            }

            this.useraccountname = localStorage.getItem('accountname');
            if(this.useraccountname == 0 || this.useraccountname == "null"){
                this.useraccountname = '';
            }else{
                this.useraccountname = localStorage.getItem('accountname');
            }

            this.userbankname = localStorage.getItem('bankname');
            if(this.userbankname == 0 || this.userbankname == "null"){
                this.userbankname = '';
            }else{
                this.userbankname = localStorage.getItem('bankname');
            }

            this.userbankbranch = localStorage.getItem('bankbranch');
            if(this.userbankbranch == 0 || this.userbankbranch == "null"){
                this.userbankbranch = '';
            }else{
                this.userbankbranch = localStorage.getItem('bankbranch');
                
            }

            this.userifsccode = localStorage.getItem('ifsccode');
            if(this.userifsccode == 0 || this.userifsccode == "null"){
                this.userifsccode = '';
                
            }else{
                this.userifsccode = localStorage.getItem('ifsccode');
            }

            this.userpfno = localStorage.getItem('pfno');
            if(this.userpfno == 0 || this.userpfno == "null"){
                this.userpfno = '';
            }else{
                this.userpfno = localStorage.getItem('pfno');
            }

            this.useruanno = localStorage.getItem('uanno');
            if(this.useruanno != 0 || this.useruanno != "null"){
                this.useruanno = '';
                
            }else{
                this.useruanno = localStorage.getItem('uanno');
            }

            this.useresino = localStorage.getItem('esino');
            if(this.useresino == 0 || this.useresino == "null"){                
                this.useresino = '';

            }else{
                this.useresino = localStorage.getItem('esino');
            }
    }
    // editbio(){
    //     window.open("#/pages/bioforms");
    // }
    editbio(){
        window.open("#/pages/bioforms", "_self");
        window.location.reload();
    }
}
