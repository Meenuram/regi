import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import {DayPilot, DayPilotSchedulerComponent} from 'daypilot-pro-angular';
import {DataService} from './data.service';
import {UndoService, HistoryItem} from "./undo.service";
import * as _ from 'underscore';
import EventData = DayPilot.EventData;
import SchedulerConfig = DayPilot.SchedulerConfig;
// interface DataResponse {
//     userId: number;
//     id: number;
//     title: string;
//     completed: boolean;
//   }
@Component({
    selector       : 'timesheet',
    templateUrl    : './timesheet.component.html',
    styleUrls      : ['./timesheet.component.scss'],
    encapsulation  : ViewEncapsulation.None
})
export class TimesheetComponent implements AfterViewInit{
   
    @ViewChild("scheduler")
  scheduler: DayPilotSchedulerComponent;

  events: any[] = [];
  tasklistdata:any;
  timesheetlistdata:any;
  eventlistdata:any;
  eventlist
  dps = new DayPilot.Calendar("scheduler");
  
  config: SchedulerConfig = {
    cellWidth: 40,
    timeHeaders: [{"groupBy":"Month"},{"groupBy":"Day","format":"d"}],
    scale: "Day",
    days: DayPilot.Date.today().daysInMonth(),
    startDate: DayPilot.Date.today().firstDayOfMonth(),

    onBeforeCellRender : args => {
      if (args.cell.start.getDatePart() <  DayPilot.Date.today()) {
        args.cell.properties.disabled=true;
        args.cell.properties.backColor = "#eee";
        
  
      }
      if (args.cell.start.getDatePart() >  DayPilot.Date.today()) {
        args.cell.properties.disabled=true;
        args.cell.properties.backColor = "#eee";
          // args.control.backColor = "#eee";
  
      }
  },
    onBeforeEventRender: args => {
      console.log(args);
      args.e.bubbleHtml =  args.e.text + "<br>" + "Hours Worked in this Task";
      args.data.backColor = '#6aa84f';
      args.data.borderColor = 'darker';
      args.data.fontColor = 'white';
      args.data.barHidden = true;
    },

    timeRangeSelectedHandling: "Enabled",
    onTimeRangeSelected: args => {
      let component = this;
      DayPilot.Modal.prompt("Enter your Time", "00:00:00").then(function(modal) {
        let dp = args.control;
        dp.clearSelection();
        if (!modal.result) { return; }
        let data = {
          start: args.start,
          end: args.end,
          id: DayPilot.guid(),
          resource: args.resource,
          text: modal.result
        };
        component.inserttaskdata(data);
        // dp.events.add(new DayPilot.Event(data));
        // component.us.add(data, "Event created.");
      });
    },

  };

    constructor(private ds: DataService, public us: UndoService,private userService:UserService)
    {
    }

    ngAfterViewInit(): void {
      this.tasklistdata = JSON.parse(localStorage.getItem("tasknamelist"));
      this.eventlistdata = JSON.parse(localStorage.getItem("eventlist"));
      console.log(this.eventlistdata)
        this.ds.getResources().subscribe(result =>{
          this.config.resources = this.tasklistdata;
          // this.config.resources = result;
        });
        var from = this.scheduler.control.visibleStart();
        var to = this.scheduler.control.visibleEnd();
        this.ds.getEvents(from, to).subscribe(result => {
          this.events = this.eventlistdata;
          console.log(this.events)
          // this.us.initialize(this.events);
        });
        
      }

      inserttaskdata(data){
        console.log(this.tasklistdata)
        var resourcename = _.where(this.tasklistdata, {id: data.resource});
        console.log(resourcename)
        console.log(resourcename[0].name)
        const postData = {
            "bid":localStorage.getItem("bid"),
            "gid":localStorage.getItem("gid"),
            "taskKey":"TaskManagement",
            "getType":"insertTask",
            "start": data.start.value,
            "end": data.end.value,
            "taskname":resourcename[0].name,
            "time":data.text,
            "resourceid":data.resource
        }
        console.log(postData);
        this.userService.getTasknames(postData)
            .subscribe((res) =>{
                console.log(res)
                var result = res.status
                this.eventListCalled();
            })
    }
    eventListCalled(){
      var eventdatalist = [];
        const postData = {
          "bid":localStorage.getItem("bid"),
          "gid":localStorage.getItem("gid"),
            "taskKey":"TaskManagement",
            "getType":"fetchTask",
            "date": "2020-09"
        };
        this.userService.getTasknames(postData)
        .subscribe((res) =>{
            this.eventlist = res.data;
            for(var i=0;i<this.eventlist.length;i++){
                eventdatalist.push({id: DayPilot.guid(), start: this.changedDateType(this.eventlist[i].start), end: this.changedDateType(this.eventlist[i].end), resource: this.eventlist[i].resourceid, text: this.eventlist[i].time});
            }
            console.log(eventdatalist);
            localStorage.setItem("eventlist", JSON.stringify(eventdatalist));
            var from = this.scheduler.control.visibleStart();
            var to = this.scheduler.control.visibleEnd();
            this.ds.getEvents(from, to).subscribe(result => {
              this.events = eventdatalist;
              console.log(this.events)
              // this.us.initialize(this.events);
            });
        })
    }
    
    changedDateType(date){
      return new DayPilot.Date(date);
  }
      
    
      undo(): void {
        let item: HistoryItem = this.us.undo();
    
        switch (item.type) {
          case "add":
            // added, need to delete now
            this.scheduler.control.events.remove(item.id);
            break;
          case "remove":
            // removed, need to add now
            this.scheduler.control.events.add(<EventData>item.previous);
            break;
          case "update":
            // updated
            this.scheduler.control.events.update(<EventData>item.previous);
            break;
        }
    
      }
    
      redo(): void {
        let item: HistoryItem = this.us.redo();
    
        switch (item.type) {
          case "add":
            // added, need to re-add
            this.scheduler.control.events.add(<EventData>item.current);
            break;
          case "remove":
            // removed, need to remove again
            this.scheduler.control.events.remove(item.id);
            break;
          case "update":
            // updated, use the new version
            this.scheduler.control.events.update(<EventData>item.current);
            break;
        }
    
      }

addtasklink(){
  window.open("../Tax-Declaration/eorganizer.php#", "_blank");
}

ngOnInit() {  

}
// ngAfterViewInit(): void {
//     const from = this.timesheet.control.visibleStart();
//     const to = this.timesheet.control.visibleEnd();
//     this.ds.getEvents(from, to).subscribe(result => {
//       this.events = result;
//     });
//   }

}