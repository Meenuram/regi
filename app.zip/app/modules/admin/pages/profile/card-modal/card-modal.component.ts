import { Component, OnInit, Inject, ViewEncapsulation } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Subject, Observable } from 'rxjs';
import { UserService } from 'app/shared/services/user.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as _ from 'underscore';
// import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { DatePipe } from '@angular/common';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
  selector: 'card-modal',
  templateUrl: './card-modal.component.html',
  styleUrls: ['./card-modal.component.scss'],
  providers: [ FormBuilder, DatePipe]
})
export class CardModalComponent implements OnInit {
  feedForm: FormGroup;
  emptotal:any;
  myname:any;
  individual:any;
  department:any;
  designation:any;
  selectedtype:any;
  emptyvalue:boolean;
  allvalue:boolean;
  alldepartment:boolean;
  alldesignation:boolean;
  allname:boolean;
  selectdesignation:any;
  selectall:any;
  selectdepartment:any;
  selectname:any;
  selectedtovalue:any;
  title:string="";
  description:string="";
  // from:any;
  tcode : string;
  first_date: any;
  current_date:any;
  image:any;
  imageSrc:any;
  public imagePath;
  imgURL: any;
  public message: string;
  filedata:any;
  localUrl: any[];
  imageupload:any;
  carddata:any;
  uploadimagename:any;
  myteammember:any;
  mytemname:any;
  myteam:any;
  mybranch:any;
  selectteamname:any;
  displaybranch:any;
  selectbranchname:any;
  displaybranchname:any;
  tablistevents:any;
  holidayname:any;
  cardtype:any;
  selectcardtype:any;
  newsdata:any;
  createdby:any;
  empbid:any;
  teamleaddata:any;
  alltlname:any;
  testdata:any;
  emaildata:any;

  Type = [
    {value: 'Department', viewValue: 'Department'},
    {value: 'Designation', viewValue: 'Designation'},
    {value: 'Individual', viewValue: 'Individual'},
    {value: 'Team', viewValue: 'Team'},
    {value: 'Branch', viewValue: 'Branch'},
    {value: 'All', viewValue: 'All'}
  ];
  
  
  constructor(private userService:UserService,public dialogRef: MatDialogRef<CardModalComponent>,private datePipe: DatePipe,public util:UtilityService) { 
    this.emptyvalue=true;
    this.alldepartment=false;
    this.alldesignation=false;
    this.allname=false;
    this.myteam=false;
    this.mybranch=false;
    this.allvalue=false;
    this.util.profileHeader('hai..');
  }

    

  ngOnInit(): void {
    // this.branch = localStorage.getItem('branch');
    // this.reportingto = localStorage.getItem('reporting_to');
    this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
    this.createdby = this.newsdata[0].created_by;
    this.empbid = this.newsdata[0].bid;
    // console.log(this.newsdata,this.createdby);
    var date = new Date(); 
    this.current_date = this.datePipe.transform(new Date(),"yyyy-MM-dd, h:mm a");
    // console.log(this.current_date)

    this.myname = localStorage.getItem('myname');
    //
    this.tablistevents = JSON.parse(localStorage.getItem("tablistdata"));
    this.holidayname = _.pluck(this.tablistevents, 'holiday')
    //remove element
    this.holidayname.forEach((element,index)=>{
      if(element=="All") this.holidayname.splice(index,1);
    });
    //end
    this.emptotal = JSON.parse(localStorage.getItem("totalempls"));
    console.log(this.emptotal)
    // this.myteammember = JSON.parse(localStorage.getItem("myteam"));
    // this.mytemname = _.uniq(_.pluck(this.myteammember, 'name'));
    this.teamleaddata = JSON.parse(localStorage.getItem("teamleaddata"));
    this.designation = _.uniq(_.pluck(this.emptotal, 'designation'));
    this.department = _.uniq(_.pluck(this.emptotal, 'department'));
    // this.individual = _.where(this.emptotal,'name');
    this.displaybranch = JSON.parse(localStorage.getItem("branchdetails"));
    this.displaybranchname = _.uniq(_.pluck(this.displaybranch, 'officename'));
  }

  // selectOption(event) {
  //   this.holidayname = event.target.value;
  //   console.log(this.holidayname);
  // }
 

  changeType(event){
    // this.selectedtype = e.value;
    this.selectedtype = event.target.value;
    if(this.selectedtype == "Department"){

      this.emptyvalue=false;
      this.alldepartment=true;
      this.alldesignation=false;
      this.allname=false;
      this.myteam=false;
      this.mybranch=false;
      this.allvalue=false;

    }else if(this.selectedtype == "Designation"){

      this.emptyvalue=false;
      this.alldepartment=false;
      this.alldesignation=true;
      this.allname=false;
      this.myteam=false;
      this.mybranch=false;
      this.allvalue=false;

    }else if(this.selectedtype == "Individual"){
    
      this.emptyvalue=false;
      this.alldepartment=false;
      this.alldesignation=false;
      this.allname=true;
      this.myteam=false;
      this.mybranch=false;
      this.allvalue=false;

    }else if(this.selectedtype == "Team"){
    
      this.emptyvalue=false;
      this.alldepartment=false;
      this.alldesignation=false;
      this.allname=false;
      this.myteam=true;
      this.mybranch=false;
      this.allvalue=false;

    }else if(this.selectedtype == "Branch"){
    
      this.emptyvalue=false;
      this.alldepartment=false;
      this.alldesignation=false;
      this.allname=false;
      this.myteam=false;
      this.mybranch=true;
      this.allvalue=false;

    }else if(this.selectedtype == "All"){
    
      this.emptyvalue=false;
      this.alldepartment=false;
      this.alldesignation=false;
      this.allname=false;
      this.myteam=false;
      this.mybranch=false;
      this.allvalue=true;

    }
  }
  changeCardType(event){
    this.selectcardtype = event.target.value;
    // console.log(this.selectcardtype)
  }
  changeDepartment(event){
    this.selectdepartment = event.target.value;
    this.selectedtovalue = event.target.value;
  }
  changeDesignation(event){
    this.selectdesignation = event.target.value;
    this.selectedtovalue = event.target.value;
  }
  changeName(event){
    this.selectname = event.target.value;
    this.selectedtovalue = event.target.value;
  }
  changeTeam(event){
    this.selectteamname = event.target.value;
    this.selectedtovalue = event.target.value;
  }
  changeBranch(event){
    this.selectbranchname = event.target.value;
    this.selectedtovalue = event.target.value;
  }
  // changeAll(event){
  //   this.selectall = event.target.value;
  //   console.log(this.selectall)
  //   this.selectedtovalue = event.target.value;
  // }
  // onFileUpload(event) {
  //   const reader = new FileReader();
  //   if(event.target.files && event.target.files.length) {
  //     const [file] = event.target.files;
  //     reader.readAsDataURL(file);
  //     console.log(reader.readAsDataURL(file));
  //     reader.onload = () => {
  //       this.imageSrc = reader.result as string;
  //       this.myForm.patchValue({
  //         fileSource: reader.result
  //       });
  //     };
  //   }
  // } 


  preview(files) {
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    this.filedata = files[0];
    console.log(this.filedata)
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
      // console.log(this.imgURL)
    }
    //
    let input = new FormData();
    input = new FormData();
    input.append("process", "DocumentUpload");
    input.append("request","encrypt");
    input.append("document_type","bill");
    // input.append("bid", "T242M21jc0pnVVlUWjhSNytmL1BuUT09");
    // input.append("gid","Qmd3VTEvdmZSbWJTc3lEVkNjVlBPQT09");
    input.append("bid", localStorage.getItem('feedpagebid'));
    input.append("gid",localStorage.getItem('feedpagegid'));
    input.append("file",this.filedata);
    input.append("module","hronboarding");
    // console.log(input)
    this.userService.feedsimageupload(input)
          .subscribe((res) =>{
          this.imageupload = res;
          console.log(this.imageupload)
          this.uploadimagename = this.imageupload.s3_file_name;
          localStorage.setItem("s3_file_name", (this.uploadimagename));
      })
  }
 
  acceptCheckin(){
    if(this.selectedtype == "All"){
      this.selectedtovalue = "All"
    }
    this.carddata = {name: this.myname, cardtype:this.selectcardtype, title: this.title, description: this.description};
    const postData = {
            "operation":"feeds",
            "module":"insert",
            "type":"file",
            "bid":localStorage.getItem('bid'),
            "created_by":localStorage.getItem('gid'),
            "category":this.selectedtype,
            "subcategory":this.selectedtovalue,
            "image":this.imageupload,
            "card_data":this.carddata
    }
    this.userService.broadcastfeeds(postData)
          .subscribe((res) =>{
          var carddetails = res;
          this.emaildata = carddetails.to;
          this.message="<!DOCTYPE html><html><body><p>&nbsp;</p><p class='c1'><span style='overflow: hidden; display: inline-block; margin: -6px 0.00px; border: 0.00px solid #000000; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px); width: 172.00px; height: 24.50px;'><img alt='Logo' src='https://conqhr.com/assets/images/logo.png' style='margin-left: 0.00px; margin-top: 0.00px; transform: rotate(0.00rad) translateZ(0px); -webkit-transform: rotate(0.00rad) translateZ(0px);'></span><span class='c14'>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span></p><hr><p class='c1'><span class='c14'>&nbsp;</span></p><p style='color: #000;font-family: Arial;'>Dear <b>All</b>,<br><br>&emsp;&emsp;&emsp;&emsp;&emsp; "+''+this.description+''+"</b>.</p><p>&nbsp;</p></body></html>";
          if(carddetails.status == '1'){
            const postData = {
              "to":this.emaildata,
              "bcc":[],
              "cc":[],
              "subject":"Notification message",
              "message":this.message,
              "notification":true,
              "from":{"value":[{"address":"conqhr@indiafilings.com", "name":"ConqHR"}]},
              "save":false
            }
            this.userService.getnotification(postData)
            .subscribe((res) =>{
            })
            this.util.cardPage('hai');
            this.dialogRef.close();
          }else if (carddetails.status == '0'){
            alert('Error');
          }
          
      })
  }
  closeModal() {
    this.dialogRef.close();
  }

    
}
