import { Route } from '@angular/router';
import { OnboardemailmodalComponent } from './onboardemailmodal.component';
// import { ProfileimagecapComponent } from 'app/modules/admin/pages/profileimagecap/profileimagecap.component';

export const OnboardemailmodalRoutes: Route[] = [
    {
        path     : '',
        component: OnboardemailmodalComponent
    }
];
