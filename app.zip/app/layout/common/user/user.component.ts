import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { User } from 'app/layout/common/user/user.types';
import { UserService } from 'app/layout/common/user/user.service';
import { UtilityService } from 'app/shared/services/utility.service';
import CryptoJS from 'crypto-js';
import {HttpClient, HttpHeaders} from '@angular/common/http';

const httpOption = {
    headers: new HttpHeaders({
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json; charset=utf-8',
    "X-Requested-With": "XMLHttpRequest"})
  };

@Component({
    selector       : 'user',
    templateUrl    : './user.component.html',
    styleUrls      : ['./user.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush,
    exportAs       : 'user'
})
export class UserComponent implements OnInit, OnDestroy, DoCheck
{
    sendjson(arg0: string, sendjson: any) {
        throw new Error("Method not implemented.");
    }
    @Input()
    showAvatar: boolean;
    
    
    // Private
    private _unsubscribeAll: Subject<any>;
    private _user: User;

    /**
     * Constructor
     *
     * @param {ChangeDetectorRef} _changeDetectorRef
     * @param {Router} _router
     * @param {UserService} _userService
     */
    myProfileImg:any;
    myProfileName:any;
    gender:any;
    showimage:any;
    profileImage:any;
    mymail:any;
    mypan:any;
    eqlcardtoken:any;
    
    constructor(
        private _changeDetectorRef: ChangeDetectorRef,
        private _router: Router,
        private _userService: UserService,
        public util:UtilityService,
        private http:HttpClient
    )
    {
        this.util.invokeProfileHeader.subscribe(value =>{
            this.refreshPRofileData();

        });
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.showAvatar = true;

        
    }

    
    // CryptoJSAesEncrypt(passphrase, plain_text){

    //     var salt = CryptoJS.lib.WordArray.random(256);
    //     var iv = CryptoJS.lib.WordArray.random(16);
    //     //for more random entropy can use : https://github.com/wwwtyro/cryptico/blob/master/random.js instead CryptoJS random() or another js PRNG
    
    //     var key = CryptoJS.PBKDF2(passphrase, salt, { hasher: CryptoJS.algo.SHA512, keySize: 64/8, iterations: 999 });
    
    //     var encrypted = CryptoJS.AES.encrypt(plain_text, key, {iv: iv});
    
    //     var data = {
    //         ciphertext : CryptoJS.enc.Base64.stringify(encrypted.ciphertext),
    //         salt : CryptoJS.enc.Hex.stringify(salt),
    //         iv : CryptoJS.enc.Hex.stringify(iv)    
    //     }
    
    //     return JSON.stringify(data);
    // }

    testencryptData(){
        var key = "s3cr3tk3y";
        var text = "welcome to my bugs";
        var result = CryptoJS.AES.encrypt(text, key);
        console.log({
            ciphertext: result.ciphertext.toString(), 
            iv: result.iv.toString(), 
            salt: result.salt.toString(), 
            key: result.key.toString()
        })
    }
        

    // EQLcard(){
    //     var obj = { email: "demo@indiafilings.com", pan: 'XXXXX1234X' };
    //     var sendjson= JSON.stringify(obj);
    // }

    encryptData() {
        this.eqlcardtoken = localStorage.getItem('eqltoken');
        // var obj = { email: this.mymail, pan: this.mypan };
        // var sendjson= JSON.stringify(obj);
        // console.log(CryptoJS.AES.encrypt(sendjson, '').toString());
        // var postData = CryptoJS.AES.encrypt(sendjson, '').toString();
        var postData = this.eqlcardtoken;
        console.log(postData)
        let apiUrl = 'https://kyc.eql.app/index.php?token='+postData;
        window.open(apiUrl); 
        // this.http.post(apiUrl,postData,httpOption).subscribe((res) =>{
        //     console.log(res);
        // });
        // this._userService.eqlcard(postData)
        // .subscribe((res) =>{
        // });
      }
      switchbusiness(){
        window.open("../main/business-list.php", "_blank");
      }
      eorganizer(){
        window.open("../Tax-Declaration/eorganizer.php#", "_blank");
      }
      mywallet(){
        window.open("../team-appraisal/wallet.php", "_blank");
      }
      taxdeclaration(){
        window.open("../Tax-Declaration/employee-benefits.php", "_blank");
      }
      incometaxsheet(){
        window.open("../main/incometax-sheet.php", "_blank");
      }
      signoutlink(){
        localStorage.clear();
        window.open("https://auth.workid.global/login?operation=logout&state=conqhremployee&cid=rm7c7ooos59384kkkea8rc7hd");
        // localStorage.removeItem('userimage');
        // localStorage.removeItem('myprofileimg');
        // localStorage.removeItem('myname');  
        // localStorage.removeItem('name');
        // localStorage.removeItem('mymailid');
        // localStorage.removeItem('mypan');  
        // localStorage.removeItem('Gender');     
        // localStorage.removeItem('designation');
        // localStorage.removeItem('following');
        // localStorage.removeItem('team');
        // localStorage.removeItem("myProfile");
        
      }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Setter & getter for user
     *
     * @param value
     */
    @Input()
    set user(value: User)
    {
        // Save the user
        this._user = value;


        // Store the user in the service
        this._userService.user = value;
    }

    get user()
    {
        return this._user;
    }
    errorImage(){
        this.showAvatar = false;
        if(this.gender == 'male'){
            this.myProfileImg = "https://de1.conqhr.com/images/male.jpeg"  

        }else{
            this.myProfileImg = "https://de1.conqhr.com/images/female.jpeg"    
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------
    ngDoCheck(){
       
    }
    /**
     * On init
     */
    ngOnInit(): void{

    }
    refreshPRofileData()
    {
   
            this.myProfileImg = localStorage.getItem('myprofileimg');
            this.myProfileName = localStorage.getItem('myname');
            this.gender = localStorage.getItem('Gender');
            this.mymail= localStorage.getItem('mymailid');
            this.mypan = localStorage.getItem('mypan');  
           

    this._user = {avatar: this.myProfileImg,
        email: this.myProfileName,
        id: "cfaad35d-07a3-4447-a6c3-d8c3d54fd5df",
        name: "Andrew Watkins",
        status: "online"}
        this.showAvatar = true;
        this.user.avatar =  this.myProfileImg;

    }


    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Update the user status
     *
     * @param status
     */
    updateUserStatus(status): void
    {
        // Update the user data
        this.user.status = status;

        // Update the user on the server
        this._userService.update(this.user);
    }

    /**
     * Sign out
     */
    signOut(): void
    {
        this._router.navigate(['/sign-out']);
    }
}
