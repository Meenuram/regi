import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit, Inject, ElementRef, HostListener } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { Router } from '@angular/router';
import { TeamComponent } from 'app/modules/admin/ui/content-layouts/common/demo-content/team.component';
import { ModernLayoutComponent } from 'app/layout/layouts/horizontal/modern/modern.component';
import {FormsLayoutsComponent} from 'app/modules/admin/ui/forms/layouts/layouts.component';
import { UtilityService } from 'app/shared/services/utility.service';
import { DatePipe } from '@angular/common';
import * as _ from 'underscore';
import { environment } from 'environments/environment';
import { FormControl, FormGroup ,FormBuilder,Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';

@Component({
    selector       : 'officefeed',
    templateUrl    : './officefeed.component.html',
    styleUrls      : ['./officefeed.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})

export class OfficefeedComponent implements OnInit{
    leftscrollvalue:any;
    @HostListener("window:scroll", ["$event"])
    onWindowScroll() {
        // console.log('hai'+document.documentElement.scrollTop)
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
     if(pos == max )   {
     //Do your action here
     }
        if (document.documentElement.scrollTop > 100) {
            this.leftscrollvalue = "abcd" ;
        } else {
            this.leftscrollvalue = "" ;
        }
    }
    /**
     * Constructor
     */
     userProfile :any;
     userTeam : any;
     following:any;
     userfollowingTeam : any;
    usertotalemp : any;
    useratoff : any;
    usernotoff : any;
     public data:any=[];
     userSession:any;
     UserTeamimage:any;
     userimgs:any;
     dataCheck:any;
     allMemberTeams: any;
     teammebergid:any;
     userid:any;
     leaveapproval:any;
     department:any;
     branch:any;
     dob:any;
     AddressLine2:any;
     Mobile:any;
     adress:any;
     MyShift:any;
     profilecredit:any;
   // storage: any;
   userTeam11:any;
   myteammember:any;
   myTeamsMember:any;
   walletData:any;
   walletbalance:any;

   userTeamMember:any;
   gettopsales:any;
   first_date:any;
   current_date:any;
   yesterday:any;
   support:any;
   sendotpmobile:any;
   personalsendotp:any;
   otpverifyform:any;
   personalnumber:any;
   officialnumber:any;
   otpvarification:any;
   mobileverified:any;
   verifiedstatus:any;
   officemobile:any;
   reportingto:any;
   salaryDatas:any;
    salaryleaves:any;
    salaryattendance:any;
    salarykeyvalues:any;
    salaryctcbreakup:any;
    salaryunset:any;
    salarydeductions:any;
    daysworked:any;
    sundays:any;
    holiday:any;
    totalleaves:any;
    paidleave:any;
    unpaidleaves:any;
    monthlyctc:any;
    grossbasics:any;
    earnings:any;
    salarypaiddeductions:any;
    netpay:any;
    ctcbreak:any;
    netpayable:any;
    monthlybasic:any;
    mbhouserent:any;
    mbmediacal:any;
    mbconveyence:any;
    mbtotal:any;
    monthearning:any;
    earninghra:any;
    earningmedical:any;
    earningconveyance:any;
    earningtotals:any;
    deductionpt:any;
    deductionvvpf:any;
    deductionvpf:any;
    deductionvesi:any;
    deductionvgmonthly:any;
    deductionvcumulative:any;
    deductionvmonthly:any;
    deductionvprept:any;
    deductionvtds:any;
    deductionvsecdeposit:any;
    deductionvintax:any;
    deductionvprotax:any;
    adddeductions:any;
    workingdays:any;
    deductiontotal:any;
    noofdays:any;
    prevmonth:any;
    paidsalaryyear:any;
    paidsalarymonth:any;
    leavenetpayable:any;
    paidunpaidLeaves:any;
    username:any;
    userimage:any;
    userdesignation:any;
    checkDoc:any;
    companyname:any;
    officename:any;
    newsdata:any;
    feedsdata:any;
    getyear:any;
    datesplit:any;
    holidaynames:any;
    getreportdata:any;
    getcompanyinfo:any;
    purchaseinfo:any;
    salesinfo:any;
    receiptsinfo:any;
    paymentsinfo:any;
    productinfo:any;
    contactinfo:any;
    attendanceinfo:any;
    documentsinfo:any;
    contactlist:any;
    contactcount:any;
    document_info:any;
    purchasedate:boolean = false;
    documentdate:boolean = false;
    salesdate:boolean = false;
    receiptdate:boolean = false;
    paymentsdate:boolean = false;
    productdate:boolean = false;
    contactdate:boolean = false;
    attendancedate:boolean = false;
    morecontact:boolean = false;
    morecontacthide:boolean = false;
    getday:any;
    current_dates:any;
    earlycount:any;
    ontimecount:any;
    latecount:any;
    ondutycount:any;
    attended:any;
    productlist:any;
    productprice:any;
    emptyrecords:any;
    showrecords:any;
    norecords:any;
   
    constructor(
        @Inject(SESSION_STORAGE) private storage: StorageService,public elementRef: ElementRef,
    private userService:UserService,private router: Router,public util:UtilityService,private datePipe: DatePipe, private formBuilder: FormBuilder)
    {
        this.otpvarification = this.formBuilder.group({
            mobilenumber: [null, [ Validators.required ]],
            otp: [null, [ Validators.required ]]
        });
        this.util.profileHeader('hai..');
    }

    displayedColumns = ['date', 'count', 'amount'];
    dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

    ngOnInit() {
        // this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
        // var recentnews = _.sortBy(this.newsdata, 'created_on'); 
        // this.feedsdata = recentnews.reverse();
        //////////////
        // this.newsdata = JSON.parse(localStorage.getItem("newsfeeddata"));
        // this.newsdata = _.where(this.newsdata , {WhoView: "MyCard"})
        // var recentnews = _.sortBy(this.newsdata, 'created_on'); 
        // this.feedsdata = recentnews.reverse();
        var dte = new Date();
        dte.setDate(dte.getDate());
        // var current_date = this.datePipe.transform(dte,"MMMM d, yyyy");
        this.current_dates = this.datePipe.transform(dte,"EEEE, dd-MMM-yyyy");
        // this.getday = this.datePipe.transform(dte,"dd-MMM-yyyy");
        // console.log(this.getday)


        this.getreportdata = JSON.parse(localStorage.getItem("accountingreport"));
        // if(this.getreportdata.status == null){
        //     console.log("else if")
        //     this.showrecords = false;
        //     this.norecords = true;
        // }else{
            // this.getreportdata.status == 0 || this.getreportdata.status == 1
        //     console.log("if")
        //     this.showrecords = true;
        //     this.norecords = false;
        //     this.getreportdata = this.getreportdata;
        // }

    // if(this.getreportdata.status != null){
        // this.getday = localStorage.getItem("reportdates")
        // console.log(this.getday)
        this.getcompanyinfo = this.getreportdata.company_details;

        var testdata = [];
        this.purchaseinfo = this.getreportdata.purchase_details;
        if(this.purchaseinfo == null){
            this.purchasedate = false;
            this.purchaseinfo = 'No Record Found';
            testdata.push("Purchase Invoive");
        }else{
            this.purchasedate = true;
            this.purchaseinfo = this.getreportdata.purchase_details;
        }

        this.salesinfo = this.getreportdata.sales_details;
        if(this.salesinfo == null){
            this.salesdate = false;
            this.salesinfo = 'No Record Found';
            testdata.push("Sales Invoice");
        }else{
            this.salesdate = true;
            this.salesinfo = this.getreportdata.sales_details;
        }

        this.receiptsinfo = this.getreportdata.receipt_details;
        if(this.receiptsinfo == null){
            this.receiptdate = false;
            this.receiptsinfo = 'No Record Found';
            testdata.push("Receipts");
        }else{
            this.receiptdate = true;
            this.receiptsinfo = this.getreportdata.receipt_details;
        }

        this.paymentsinfo = this.getreportdata.payments_details;
        if(this.paymentsinfo == null){
            this.paymentsdate = false;
            this.paymentsinfo = 'No Record Found';
            testdata.push("Payments");
        }else{
            this.paymentsdate = true;
            this.paymentsinfo = this.getreportdata.payments_details;
        }

        this.productinfo = this.getreportdata.product_creation;
        this.productlist = this.productinfo.product_list;
        for(var i=0;i<this.productlist.length;i++){
            var stringToReplace = this.productlist[i].Catalog;
            var desired = stringToReplace.replace(/[/+/]/gi, ' ');
            this.productlist[i]['replacetype'] = desired;
        }
        if(this.productlist == null || this.productlist == ""){
            this.productdate = false;
            this.productlist = 'No Record Found';
            testdata.push("Product Creation");
        }else{
            this.productdate = true;
            this.productlist = this.productinfo.product_list;
            for(var i=0;i<this.productlist.length;i++){
                this.productprice = this.productlist[i].variations;
                console.log(this.productprice)
                this.productlist[i]['getproductprice'] = this.productprice[0].Price;
            }
            console.log(this.productlist)
        }
        

        this.contactinfo = this.getreportdata.contact_creation;
        if(this.contactinfo.Contact.count > 6){
           this.contactcount = this.contactinfo.Contact.count-6
           this.morecontact = true;
        //    this.morecontacthide = false;
        }else{
            this.morecontact = false;
            // this.morecontacthide = true;
        }
        // this.contactcount = this.contactinfo.Contact.count-6;
        // console.log(this.contactinfo.Contact.count)
        this.contactlist = this.contactinfo.contact_list;
        for(var i=0;i<this.contactlist.length;i++){
            var stringToReplace = this.contactlist[i].cxname;
            var desired = stringToReplace.replace(/[/+/]/gi, ' ');
            this.contactlist[i]['replacetype'] = desired;
        }
        
        if(this.contactlist == null || this.contactlist == ""){
            this.contactdate = false;
            this.contactlist = 'No Record Found';
            testdata.push("Contact Creation");
        }else{
            this.contactdate = true;
            this.contactlist = this.contactinfo.contact_list;
        }

        this.attendanceinfo = this.getreportdata.attendance_data;
        this.earlycount = this.attendanceinfo.early;
        this.ontimecount = this.attendanceinfo.ontime;
        this.latecount = this.attendanceinfo.late;
        this.ondutycount = this.attendanceinfo.onduty;
        if(this.attendanceinfo == null || this.attendanceinfo == ""){
            this.attendancedate = false;
            this.attendanceinfo = 'Attendance Not Setup';
            testdata.push("Attendance");
        }else{
            this.attendancedate = true;
            this.attendanceinfo = this.getreportdata.attendance_data;
            this.attended = this.earlycount + this.ontimecount + this.latecount + this.ondutycount;
        }

        this.documentsinfo = this.getreportdata.documents;
        this.documentsinfo = JSON.parse(JSON.stringify(this.documentsinfo).split('"Purchase Invoice":').join('"Purchase_Invoice":').split('"Bank Statement":').join('"Bank_Statement":'));
        this.document_info = JSON.stringify(this.documentsinfo);
        // if(this.document_info == null || this.documentsinfo.Other==0 || this.documentsinfo.Invoice==0 || this.documentsinfo.Receipt==0 || this.documentsinfo.Bank_Statement==0 || this.documentsinfo.Purchase_Invoice==0){
        if(this.document_info == null){
            this.documentdate = false;
            this.document_info = 'No Record Found';
            testdata.push("Documents");
        }else{
            this.documentdate = true;
            this.document_info = JSON.stringify(this.documentsinfo);
        }
    // }
        //
        this.emptyrecords = '';
        if(testdata) {
            this.emptyrecords = testdata.join();
        }
        /////////////
        
        
        this.companyname = localStorage.getItem('bidname');
        if(this.companyname == "VERVE FINANCIAL SERVICES PRIVATE LIMITED"){
            this.officename = true;
        }else{
            this.officename = false;
        }
        //
        this.userid = localStorage.getItem('gid');
        localStorage.setItem('teammebergid',this.userid);
        this.teammebergid = localStorage.getItem('teammebergid');
        // this.userTeam = JSON.parse(localStorage.getItem("profileteamimage"));
        this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
        // localStorage.setItem("teamleadlist", JSON.stringify(res));
        this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
        // this.myTeamsMember = setInterval(() => { 
        //     this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
        //     if(this.UserTeamimage == null){
                
        //     }else{
        //         this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
        //         this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
        //         clearInterval(this.myTeamsMember)
        //     }
        // },500);
        
        //salary
        var years = new Date().getFullYear();
        var month = new Date().getMonth()+1;
        this.noofdays = new Date(years, month, 0).getDate();
        var todaydate = new Date().toLocaleString();
       
        // this.salaryDatas = JSON.parse(localStorage.getItem("salaryData"));
        
        // if(this.salaryDatas){
        //     this.getSalaryDetails();
        // }
        
        this.userProfile = JSON.parse(localStorage.getItem("myProfile"));
        this.userProfile = this.userProfile[0];
        // console.log(this.userProfile);
            // this.department = this.userProfile.department;
            // this.branch = this.userProfile.branch;
            // this.dob = this.userProfile.dob;
            // this.adress = this.userProfile.AddressLine2;
            // this.Mobile = this.userProfile.Mobile;
            //
            // this.username = localStorage.getItem("myname");
            // this.userimage = this.userProfile.image;
            // this.userdesignation = this.userProfile.designation;
            // if(this.userid == this.teammebergid){
            //     this.checkDoc =true;
            // }else{
            //     this.checkDoc =false;
            // }
            //
            this.otpvarification.controls['mobilenumber'].setValue(this.Mobile);
            this.MyShift = this.userProfile.myshifttime;
            this.verifiedstatus = this.userProfile.isverified;
            if(this.verifiedstatus==1){
               this.mobileverified=true;
            }else{
                this.mobileverified=false;
            }
            // this.userService.getUserTeamimage()
            // .subscribe((res) =>{
            //     localStorage.setItem("teamimage",  JSON.stringify(res.data));
            //     this.UserTeamimage =  JSON.stringify(res.data);
            // }, err => {
            //     console.log('Error', err);
                
            // })

            //1st card
            this.userimage = localStorage.getItem('myprofileimg');
            this.username =  localStorage.getItem('myname');
            this.Mobile = localStorage.getItem('mymobile');
            this.userdesignation =  localStorage.getItem('mydesignation');
            this.branch = localStorage.getItem('mybranch');
            this.userid = localStorage.getItem('gid');
            this.teammebergid = localStorage.getItem('teammebergid');
            if(this.userid == this.teammebergid){
                this.checkDoc =true;
            }else{
                this.checkDoc =false;
            }

        
            this.getUserProfile();
            // //this.getUserTeamimageFunction();
            // this.getTeamImage();
            //wallet
            this.walletData = JSON.parse(localStorage.getItem("getwalletdata"));
            // this.walletbalance = this.walletData.credit - this.walletData.debit;
            // console.log(this.walletbalance);
            if(this.walletData.status==1){
                this.profilecredit = this.walletData.credit;
                if(!this.walletData){
                    this.walletbalance =0;
                }else if(this.walletData.credit == 0 && this.walletData.credit == 0 && this.walletData.debit == 0){
                this.walletbalance =0;
                }else if(this.walletData.status == 0){
                    this.walletbalance =0;
                    this.walletData.credit = 0;
                    this.walletData.debit = 0;
                }else{
                    this.walletbalance = this.walletData.credit - this.walletData.debit;
                }
            }else{
                this.profilecredit = 0;
                this.walletbalance = 0;
            }
    
            //topsales
            this.gettopsales = JSON.parse(localStorage.getItem("topthreesales"));
            // this.gettopsales = [];
            var date = new Date(); 
            var firstDay = new Date(date.getFullYear(),date.getMonth(), 1);
            this.first_date = this.datePipe.transform(firstDay,"MMMM, yyyy");
            // this.current_date = this.datePipe.transform(salesdate,"MMMM d, yyyy");
            this.current_date = localStorage.getItem("salesdate");
    
            this.support=true;
            this.sendotpmobile=true;
            this.personalsendotp=true;
            this.personalnumber=true;
            this.officialnumber=true;
    }
    
    
    getUserProfile() {
        const postData = {
            // "gid":usersession.gid,
            // "bid":usersession.bid,
            "gid":localStorage.getItem('gid'),
            "bid":localStorage.getItem('bid'),
            // "key":"getEmpData"
            "operation": btoa(localStorage.getItem('gid') + 'TXhfVjJ4amVHUXhTa2hTYWtKYVZWUXdPUT09'),
            // "secret": localStorage.getItem('secret')
            "secret": environment.ANOTHER_API_SECRET
            };
            // console.log(postData)
        this.userService.getUserProfile(postData)
        .subscribe((res) =>{
            localStorage.setItem('userimage', res.data[0].image);
            localStorage.setItem('myprofileimg', res.data[0].image);
            localStorage.setItem('name', res.data[0].name);
            localStorage.setItem('mydepartment', res.data[0].department);
            localStorage.setItem('myname', res.data[0].name);
            localStorage.setItem('FatherName', res.data[0].FatherName);
            localStorage.setItem('Mobile', res.data[0].Mobile);
            localStorage.setItem('dob', res.data[0].dob);
            localStorage.setItem('personalemail', res.data[0].personalemail);
            localStorage.setItem('Gender', res.data[0].Gender);
            localStorage.setItem('MaritalStatus', res.data[0].MaritalStatus);
            localStorage.setItem('Nationality', res.data[0].Nationality);
            localStorage.setItem('LanguageKnown', res.data[0].LanguageKnown);
            localStorage.setItem('Blood', res.data[0].Blood);
            localStorage.setItem('aadhaar', res.data[0].aadhaar);
            localStorage.setItem('pan', res.data[0].pan);
            localStorage.setItem('AddressLine1', res.data[0].AddressLine1);
            localStorage.setItem('AddressLine2', res.data[0].AddressLine2);
            localStorage.setItem('ZipCode', res.data[0].ZipCode);
            localStorage.setItem('City', res.data[0].City);
            localStorage.setItem('State', res.data[0].State);
            localStorage.setItem('Country', res.data[0].Country);
            localStorage.setItem('employee_id', res.data[0].employee_id);
            localStorage.setItem('designation', res.data[0].designation);
            localStorage.setItem('doj', res.data[0].doj);
            localStorage.setItem('reporting_to', res.data[0].reporting_to);
            localStorage.setItem('extention', res.data[0].extention);
            localStorage.setItem('officeemail', res.data[0].officeemail);
            localStorage.setItem('personalmobile', res.data[0].personalmobile);
            localStorage.setItem('officemobile', res.data[0].officemobile);
            localStorage.setItem('shift', res.data[0].myshifttime);
            localStorage.setItem('branch', res.data[0].branch);
            localStorage.setItem('branch', res.data[0].branch);
            localStorage.setItem('accountnumber', res.data[0].accountnumber);
            localStorage.setItem('accountname', res.data[0].accountname);
            localStorage.setItem('bankname', res.data[0].bankname);
            localStorage.setItem('bankbranch', res.data[0].bankbranch);
            localStorage.setItem('ifsccode', res.data[0].ifsccode);
            localStorage.setItem('pfno', res.data[0].pfno);
            localStorage.setItem('uanno', res.data[0].uanno);
            localStorage.setItem('esino', res.data[0].esino);
            localStorage.setItem('following', res.following);
            localStorage.setItem('team', res.team.length);
            localStorage.setItem('teamgid', res.team.gid);
            
            this.userProfile = res.data;
            
            // this.userTeam = res.team;
            localStorage.setItem('teampagevalues', JSON.stringify(res.team));
            this.userTeam11 = JSON.parse(localStorage.getItem('teampagevalues'));
            
            this.following = res.following;
            this.userfollowingTeam = res.followingarray;
            this.usertotalemp = res.totalEmp;
            this.useratoff = res.atoffc;
            this.usernotoff = res.notoffc;
            this.leaveapproval = res.approvals;
            localStorage.setItem("myProfile", JSON.stringify(this.userProfile));
            localStorage.setItem("leaveapproval", JSON.stringify(this.leaveapproval));
            
            localStorage.setItem("userimgssec", JSON.stringify(this.userimgs));
      
        }, err => {
            console.log('Error', err);
            
        })
    }
    
    viewTeam(gid){
        //console.log(gid);
        localStorage.setItem("teammebergid", gid);
        // this.util.profileHeader('hai');
        this.router.navigate(['/ui/content-layouts/left-sidebar/fullheight/basic/team']);
        // let myCompOneObj = new TeamComponent(null,null,null);
        // myCompOneObj.hellofunction();   
    }
    teamsNAmeChange(names){
        var changedname = names.split(" ", 1);
        return changedname[0];
    }
    
    
    eqlcardpage(){
        window.open("https://app.ledgers.cloud/m/app/module/?m=eql", "_blank");
    }
    

}

//table
export interface Element {
    date: string;
    count: number;
    amount: string;
 }
//table
//table
const ELEMENT_DATA: Element[] = [
    {date: '03-Feb-2021', count: 40, amount: "4,26,938"},
    {date: '03-Feb-2021', count: 40, amount: "4,26,938"},
 ];
//table
