import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardemailmodalComponent } from './onboardemailmodal.component';

describe('OnboardemailmodalComponent', () => {
  let component: OnboardemailmodalComponent;
  let fixture: ComponentFixture<OnboardemailmodalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardemailmodalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardemailmodalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
