import { Route } from '@angular/router';
import { BasicinfoComponent } from './basicinfo.component';

export const basicinfoRoutes: Route[] = [
    {
        path     : '',
        component: BasicinfoComponent
    }
];
