import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {DayPilot} from 'daypilot-pro-angular';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class DataService {

  resources: any[] = [
    { name: "Resource 1", id: 1},
    { name: "Resource 2", id: "2"},
    { name: "Resource 3", id: "3"},
    { name: "Resource 4", id: "4"},
    { name: "Resource 5", id: "5"},
    { name: "Resource 6", id: "6"},
    { name: "Resource 7", id: "7"},
    { name: "Resource 8", id: "8"}
  ];
  

  events: any[] = [
    {
      id: DayPilot.guid(),
      resource: "2",
      start: new DayPilot.Date("2020-09-02T00:00:00"),
      end: new DayPilot.Date("2020-09-03T00:00:00"),
      text: "09:30:20"
    },{
      id: DayPilot.guid(),
      resource: "3",
      start: DayPilot.Date.today().firstDayOfMonth().addDays(6),
      end: DayPilot.Date.today().firstDayOfMonth().addDays(9),
      text: "14:15:00"
    }
  ];

  constructor(private http : HttpClient){
  }

  getEvents(from: DayPilot.Date, to: DayPilot.Date): Observable<any[]> {

    // simulating an HTTP request
    return new Observable(observer => {
      setTimeout(() => {
        observer.next(this.events);
        observer.complete();
      }, 200);
    });
  }

  getResources(): Observable<any[]> {

    // simulating an HTTP request
    return new Observable(observer => {
      setTimeout(() => {
        observer.next(this.resources);
        observer.complete();
      }, 200);
    });
  }

}
