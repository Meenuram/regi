import { Route } from '@angular/router';
import { OfficefeedComponent } from './officefeed.component';

export const officefeedRoutes: Route[] = [
    {
        path     : '',
        component: OfficefeedComponent
    }
];
