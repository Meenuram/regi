import { AfterViewInit, ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ApexOptions } from 'ng-apexcharts';
import { FinanceService } from 'app/modules/admin/dashboards/finance/finance.service';
import { UserService } from 'app/shared/services/user.service';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';
import { UtilityService } from 'app/shared/services/utility.service';

@Component({
    selector       : 'finance',
    templateUrl    : './finance.component.html',
    styleUrls      : ['./finance.component.scss']
})
export class FinanceComponent implements OnInit, AfterViewInit, OnDestroy
{
    data: any;
    accountBalanceOptions: ApexOptions;
    recentTransactionsDataSource: MatTableDataSource<any>;
    recentTransactionsTableColumns: string[];

    salaryDatas:any;
    salaryleaves:any;
    salaryattendance:any;
    salarykeyvalues:any;
    salaryctcbreakup:any;
    salaryunset:any;
    salarydeductions:any;
    daysworked:any;
    sundays:any;
    holiday:any;
    totalleaves:any;
    paidleave:any;
    unpaidleaves:any;
    monthlyctc:any;
    grossbasics:any;
    earnings:any;
    salarypaiddeductions:any;
    netpay:any;
    ctcbreak:any;
    netpayable:any;
    monthlybasic:any;
    mbhouserent:any;
    mbmediacal:any;
    mbconveyence:any;
    mbtotal:any;
    monthearning:any;
    earninghra:any;
    earningmedical:any;
    earningconveyance:any;
    earningtotals:any;
    deductionpt:any;
    deductionvvpf:any;
    deductionvpf:any;
    deductionvesi:any;
    deductionvgmonthly:any;
    deductionvcumulative:any;
    deductionvmonthly:any;
    deductionvprept:any;
    deductionvtds:any;
    deductionvsecdeposit:any;
    deductionvintax:any;
    deductionvprotax:any;
    adddeductions:any;
    workingdays:any;
    deductiontotal:any;
    current_date:any;
    userwalletdetails:any;
    seriesData:any;
    mySalaryData:any;
    ageOptions: ApexOptions;
    languageOptions: ApexOptions;
    donutchartdata:[];
    dataofchart:any;
    xchartdata:any;
    ychartdata:any;
    attendanceData:any;
    attendancelabel:any;
    attendanceseries:any;
    serieswalletData:any;
    walletData:any;
    walletlabel:any;
    walletseries:any;
    walletbalance:any;
    noofdays:any;
    emptyChartData:boolean = false;
    prevmonth:any;
    paidsalaryyear:any;
    paidsalarymonth:any;
    leavenetpayable:any;
    paidunpaidLeaves:any;
    incentivesdata:any;
    higestsalesamt:any;

    @ViewChild('recentTransactionsTable', {read: MatSort})
    recentTransactionsTableMatSort: MatSort;

    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {FinanceService} _financeService
     */
    constructor(
        private _financeService: FinanceService,private userService:UserService,private datePipe: DatePipe,public util:UtilityService
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.recentTransactionsDataSource = new MatTableDataSource();
        this.recentTransactionsTableColumns = ['SalaryComponents', 'MonthlyCTC', 'EarningsforJUL'];
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        
        // var myVariable = new Date()
        var makeDate = new Date();
        makeDate = new Date(makeDate.setMonth(makeDate.getMonth() - 1));
        
        
        this.current_date = this.datePipe.transform(new Date(),"MMMM, yyyy");
        this.util.profileHeader('hai');
        var years = new Date().getFullYear();
        var month = new Date().getMonth()+1;
        this.noofdays = new Date(years, month, 0).getDate();
        var todaydate = new Date().toLocaleString();
        // console.log(this.datePipe.transform(todaydate,"yyyy-MM"));
        this.salaryDatas = JSON.parse(localStorage.getItem("salaryData"));
        
        if(this.salaryDatas){
            this.getSalaryDetails();
        }
        
        //incentives
    //     this.incentivesdata = JSON.parse(localStorage.getItem("getincentivedata"));
    //     var maxincentive = this.incentivesdata[0];
    //    var higestsales =  _.max(maxincentive.data, function(incentivesdata){ 
    //     return incentivesdata.y; 
    // });
    // this.higestsalesamt = higestsales.y;
        //wallet
        this.walletData = JSON.parse(localStorage.getItem("getwalletdata"));
        this.walletlabel = ["Total Pay","Total Credit", "Total Debit"];
        this.walletseries = [this.walletData.credit,this.walletData.credit,this.walletData.debit];
        if(!this.walletData){
            this.emptyChartData=true;
            this.walletbalance =0;
        }else if(this.walletData.credit == 0 && this.walletData.credit == 0 && this.walletData.debit == 0){
        this.emptyChartData=true;
        this.walletbalance =0;
        }else if(this.walletData.status == 0){
            this.emptyChartData=true;
            this.walletbalance =0;
        }else{
            this.walletbalance = this.walletData.credit - this.walletData.debit;
        }

        //attendance
        //this.seriesData = JSON.parse(localStorage.getItem("getwalletdata"));
        this.attendanceData = JSON.parse(localStorage.getItem("getattendancedata"));
        this.attendancelabel = ["Ontime","Late"];
        this.attendanceseries = [this.attendanceData.ontime,this.attendanceData.late];
        // Get the data
        this._financeService.data$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((data) => {

                // Store the data
                this.data = data;
                var abcd = this.data.accountBalance.series;
                console.log(abcd);
                this.dataofchart = abcd[0].data;
                this.xchartdata = _.pluck(this.dataofchart, 'x');
                this.ychartdata = _.pluck(this.dataofchart, 'y');
                

                // Store the table data
                this.recentTransactionsDataSource.data = data.recentTransactions;

                // Prepare the chart data
                this._prepareChartData();
                this._preparedonutChartData();
                this._prepareattendChartData();
                
            });
                // console.log(this.seriesData);
                
                // this.donutchartdata = [];
                // for(var i=0;i<this.dataofchart.length;i++){
                //     this.dataofchart[i]['series'] = this.dataofchart[i].x;
                //     this.dataofchart[i]['labels'] = this.dataofchart[i].y;
                //     var xdata = this.dataofchart[i].x;
                   
                // }
                // this.donutchartdata.push(this.dataofchart);
            
    }

    // getWallet(){
    //     this.userService.getWallet()
    //     .subscribe((res) =>{

    //     this.userwalletdetails = res.msg;
    //     this.seriesData = [
    //         {
    //             name: 'Predicted',
    //             data: this.userwalletdetails
    //         }
    //     ]
    //     // console.log(_.where(this.userwalletdetails, {transaction_type:"credit"}));
    //     console.log(this.seriesData);
    //     console.log('getWallet');
    //     this._prepareChartData();
    //     })
    // }
    

    getSalaryDetails() {
        this.salaryDatas = JSON.parse(localStorage.getItem("salaryData"));
        console.log(this.salaryDatas)
        this.salaryleaves = this.salaryDatas.leaves[0];
        if(this.salaryleaves){
        this.totalleaves = this.salaryleaves.Total_No_of_Leaves_Taken;
        if(this.totalleaves == null){
            this.totalleaves = 'NA';
        }else{
            this.totalleaves = this.salaryDatas.Total_No_of_Leaves_Taken;
        }
        console.log(this.salaryleaves.Paid_Leave, this.salaryleaves.Unpaid_Leaves)
        this.paidleave = this.salaryleaves.Paid_Leave;
        // if(this.paidleave == null || this.paidleave == 0){
        //     this.paidleave = 'NA';
        // }else{
        //     this.paidleave = this.salaryleaves.Paid_Leave;
        // }
        this.unpaidleaves = this.salaryleaves.Unpaid_Leaves;
        // if(this.unpaidleaves == null || this.unpaidleaves == 0){
        //     this.unpaidleaves = 'NA';
        // }else{
        //     this.unpaidleaves = this.salaryleaves.Unpaid_Leaves;
        // }
        if(this.paidleave == null && this.unpaidleaves == null){
            this.paidunpaidLeaves = "NA";   
        }else if(this.paidleave > 0 && this.unpaidleaves == 0){
            this.paidunpaidLeaves = Number(this.paidleave) + Number(0);
        }else if(this.paidleave == 0 && this.unpaidleaves > 0){
            this.paidunpaidLeaves = Number(0) + Number(this.unpaidleaves);
        }else if(this.paidleave == 0 && this.unpaidleaves == 0){
            this.paidunpaidLeaves = "NA";  
        }else{
            this.paidunpaidLeaves = Number(this.paidleave) + Number(this.unpaidleaves);
        }
        console.log(this.paidunpaidLeaves)
       }

       //paid salary month and data
       this.paidsalarymonth = this.salaryDatas.month;
       this.paidsalaryyear = this.salaryDatas.year;
       if(this.paidsalarymonth == null && this.paidsalaryyear == null){
        this.prevmonth = "NA";
       }else{
        this.prevmonth = this.paidsalarymonth + " , " + this.paidsalaryyear;

       }
       


        this.monthlyctc = this.salaryDatas.ctctotal;
        if(this.monthlyctc == null){
            this.monthlyctc = 'NA';
        }else{
            this.monthlyctc = this.salaryDatas.ctctotal;
        }
        this.grossbasics = this.salaryDatas.grossbasic;
        if(this.grossbasics == null){
            this.grossbasics = 'NA';
        }else{
            this.grossbasics = this.salaryDatas.grossbasic;
        }
        this.earnings = this.salaryDatas.grosstotal;
        if(this.earnings == null){
            this.earnings = 'NA';
        }else{
            this.earnings = this.salaryDatas.grosstotal;
        }
        //this.deductions = this.salaryDatas.grossbasic;
        this.netpay = this.salaryDatas.payout;
        if(this.netpay == null){
            this.netpay = 'NA';
        }else{
            this.netpay = this.salaryDatas.payout;
        }

        this.salarypaiddeductions = this.salaryDatas.deductions[0];
        if(this.salarypaiddeductions == null){
            this.salarypaiddeductions = 'NA';
        }else{
            this.salarypaiddeductions = this.salaryDatas.deductions;
        }
        if(this.salarypaiddeductions){
        this.deductionpt = this.salarypaiddeductions.PT;
        this.deductionvvpf = this.salarypaiddeductions.VPF;
        this.deductionvpf = this.salarypaiddeductions.Employee_PF;
        this.deductionvesi = this.salarypaiddeductions.Employee_ESI;
        this.deductionvgmonthly = this.salarypaiddeductions.Gratuity_Monthly;
        this.deductionvcumulative = this.salarypaiddeductions.Gratuity_Cumulative;
        this.deductionvmonthly = this.salarypaiddeductions.SuperAnnuation_monthly;
        this.deductionvprept = this.salarypaiddeductions.prept;
        this.deductionvtds = this.salarypaiddeductions.TDS;
        this.deductionvsecdeposit = this.salarypaiddeductions.SECURITY_DEPOSIT;
        this.deductionvintax = this.salarypaiddeductions.Income_tax;
        this.deductionvprotax = this.salarypaiddeductions.Professional_Tax;
        }
       
        var deductionarr =  this.salaryDatas.deductions[0];
        console.log(deductionarr)
        if(deductionarr){
        this.deductiontotal = 0;
        for (var key in deductionarr) {
            this.deductiontotal = Number(deductionarr[key]) + this.deductiontotal;
            console.log(this.deductiontotal)
        };
    }
    if(this.deductiontotal == null){
        this.deductiontotal = 'NA';
    }else{
        this.deductiontotal = this.deductiontotal;
    }

        this.monthlybasic = this.salaryDatas.ctcbasic;
        if(this.monthlybasic == null){
            this.monthlybasic = 'NA';
        }else{
            this.monthlybasic = this.salaryDatas.ctcbasic;
        }
        this.monthearning = this.salaryDatas.grossbasic;
        if(this.monthearning == null){
            this.monthearning = 'NA';
        }else{
            this.monthearning = this.salaryDatas.grossbasic;
        }
        this.leavenetpayable = this.salaryDatas.netpayable;
        if(this.leavenetpayable == null){
            this.leavenetpayable = 'NA';
        }else{
            this.leavenetpayable = this.salaryDatas.netpayable;
        }

        this.salaryattendance = this.salaryDatas.attendance[0];
        if(this.salaryattendance == null){
            this.salaryattendance = 'NA';
        }else{
            this.salaryattendance = this.salaryDatas.attendance[0];
        }
        if(this.salaryattendance){
        this.workingdays = this.salaryattendance.Working_Days_of_Company_Excluding_Sundays_Holidays;
        if(this.workingdays == null || this.workingdays == 0){
            this.workingdays = 'NA';
        }else{
            this.workingdays = this.salaryattendance.Working_Days_of_Company_Excluding_Sundays_Holidays;
        }
        this.daysworked = this.salaryattendance.Actual_Worked_Days_Paid_Leaves;
        if(this.daysworked == null){
            this.daysworked = 'NA';
        }else{
            this.daysworked = this.salaryattendance.Actual_Worked_Days_Paid_Leaves;
        }
        this.sundays = this.salaryattendance.Sundays_Holidays;
        if(this.sundays == null){
            this.sundays = 'NA';
        }else{
            this.sundays = this.salaryattendance.Sundays_Holidays;
        }
        this.holiday = this.salaryattendance.Holiday_Present;
        if(this.holiday == null){
            this.holiday = 'NA';
        }else{
            this.holiday = this.salaryattendance.Holiday_Present;
        }
        }
        this.netpayable = this.daysworked == null? 0 : this.daysworked;
        this.netpayable = Number(this.netpayable) + Number(this.sundays) + Number(this.holiday);

        this.salarykeyvalues = this.salaryDatas.keyvalues;

        this.salaryctcbreakup = this.salaryDatas.ctcbreakup[0];
        if(this.salaryctcbreakup == null){
            this.salaryctcbreakup = [];
        }
        // console.log(this.salaryctcbreakup);
        // var salaryctcbreakup = this.salaryDatas.ctcbreakup;
        if(this.salaryctcbreakup){

        this.ctcbreak = this.salaryctcbreakup.ESI_total;
        if(this.ctcbreak == null){
            this.ctcbreak = 'NA';
        }else{
            this.ctcbreak = this.salaryctcbreakup.ESI_total;
        }
        this.mbhouserent = this.salaryctcbreakup.Hra;
        if(this.mbhouserent == null){
            this.mbhouserent = 'NA';
        }else{
            this.mbhouserent = this.salaryctcbreakup.Hra;
        }
        this.mbmediacal = this.salaryctcbreakup.MedicalInsurance;
        if(this.mbmediacal == null){
            this.mbmediacal = 'NA';
        }else{
            this.mbmediacal = this.salaryctcbreakup.MedicalInsurance;
        }
        this.mbconveyence = this.salaryctcbreakup.ConveyanceAllowance;
        if(this.mbconveyence == null){
            this.mbconveyence = 'NA';
        }else{
            this.mbconveyence = this.salaryctcbreakup.ConveyanceAllowance;
        }
        this.mbtotal = this.salaryctcbreakup.CTC_Per_Month;
        if(this.mbtotal == null){
            this.mbtotal = 'NA';
        }else{
            this.mbtotal = this.salaryctcbreakup.CTC_Per_Month;
        }
        }

        this.salaryunset = this.salaryDatas.unset;

        this.salarydeductions = this.salaryDatas.grossearnings[0];
        if(this.salarydeductions == null){
            this.salarydeductions = 'NA';
        }else{
            this.salarydeductions = this.salaryDatas.grossearnings[0];
        }

        if(this.salarydeductions){
        this.earninghra = this.salarydeductions.Hra;
        if(this.earninghra == null){
            this.earninghra = 'NA';
        }else{
            this.earninghra = this.salarydeductions.Hra;
        }
        this.earningmedical = this.salarydeductions.MedicalAllowance;
        if(this.earningmedical == null){
            this.earningmedical = 'NA';
        }else{
            this.earningmedical = this.salarydeductions.MedicalAllowance;
        }
        this.earningconveyance = this.salarydeductions.ConveyanceAllowance;
        if(this.earningconveyance == null){
            this.earningconveyance = 'NA';
        }else{
            this.earningconveyance = this.salarydeductions.ConveyanceAllowance;
        }
        this.earningtotals = this.salarydeductions.GrossTotal;
        if(this.earningtotals == null){
            this.earningtotals = 'NA';
        }else{
            this.earningtotals = this.salarydeductions.GrossTotal;
        }
        }
    }
    /**
     * After view init
     */
    ngAfterViewInit(): void
    {
        // Make the data source sortable
        this.recentTransactionsDataSource.sort = this.recentTransactionsTableMatSort;
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Private methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Prepare the chart data from the data
     *
     * @private
     */
    private _prepareChartData(): void
    {
        
        // Account balance
        this.accountBalanceOptions = {
            chart  : {
                animations: {
                    speed           : 400,
                    animateGradually: {
                        enabled: false
                    }
                },
                fontFamily: 'inherit',
                foreColor : 'inherit',
                width     : '100%',
                height    : '100%',
                type      : 'area',
                sparkline : {
                    enabled: true
                }
            },
            colors : ['#A3BFFA', '#667EEA'],
            fill   : {
                colors : ['#CED9FB', '#AECDFD'],
                opacity: 0.5,
                type   : 'solid'
            },
            series : this.incentivesdata,
            stroke : {
                curve: 'straight',
                width: 2
            },
            tooltip: {
                // theme: 'dark',
               
                y    : {
                    formatter: (value) => {
                        return '₹' + value;
                    }
                }
            },
            xaxis  : {
                // type: 'datetime'
            }
        };
    }

    private _preparedonutChartData(): void
    {
        // Age
        this.ageOptions = {
            chart      : {
                animations: {
                    speed           : 400,
                    animateGradually: {
                        enabled: false
                    }
                },
                fontFamily: 'inherit',
                foreColor : 'inherit',
                height    : '100%',
                type      : 'donut',
                sparkline : {
                    enabled: true
                }
            },
            colors     : ['#DD6B20', '#F6AD55', '#985606'],
            labels     : this.walletlabel,
            plotOptions: {
                pie: {
                    expandOnClick: false,
                    donut        : {
                        size: '70%'
                    }
                }
            },
            series     : this.walletseries,
            states     : {
                hover : {
                    filter: {
                        type: 'none'
                    }
                },
                active: {
                    filter: {
                        type: 'none'
                    }
                }
            },
            tooltip    : {
                enabled        : true,
                fillSeriesColor: false,
                theme          : 'dark'
            }
        };
    }
    private _prepareattendChartData(): void
    {
     // Language
     this.languageOptions = {
        chart      : {
            animations: {
                speed           : 400,
                animateGradually: {
                    enabled: false
                }
            },
            fontFamily: 'inherit',
            foreColor : 'inherit',
            height    : '100%',
            type      : 'donut',
            sparkline : {
                enabled: true
            }
        },
        colors     : ['#28a745', '#dc3545'],
        labels     : this.attendancelabel,
        plotOptions: {
            pie: {
                expandOnClick: false,
                donut        : {
                    size: '70%'
                }
            }
        },
        series     : this.attendanceseries,
        states     : {
            hover : {
                filter: {
                    type: 'none'
                }
            },
            active: {
                filter: {
                    type: 'none'
                }
            }
        },
        tooltip    : {
            enabled        : true,
            fillSeriesColor: false,
            theme          : 'dark'
        }
    };
}

     

    

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Track by function for ngFor loops
     *
     * @param index
     * @param item
     */
    trackByFn(index: number, item: any): any
    {
        return item.id || index;
    }
}
