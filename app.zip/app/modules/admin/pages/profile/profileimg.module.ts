import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TreoCardModule } from '@treo/components/card';
import { SharedModule } from 'app/shared/shared.module';
import { ProfileimgComponent } from './profileimg.component';
import { profileimgRoutes } from './profileimg.routing';
// import { PersondetailsComponent } from './persondetails/persondetails.component';
import { WebcamModule } from 'ngx-webcam';
import { MatExpansionModule } from '@angular/material/expansion';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
// import { PersondetailsComponent } from './persondetails/persondetails.component';

@NgModule({
    declarations: [
        ProfileimgComponent
        // PersondetailsComponent
    ],
    imports     : [
        RouterModule.forChild(profileimgRoutes),
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatTooltipModule,
        TreoCardModule,
        SharedModule,
        WebcamModule,
        MatExpansionModule,
        MatProgressSpinnerModule
    ]
})
export class ProfileimgModule
{
}
