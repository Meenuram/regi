import { Component, ViewEncapsulation } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
    selector     : 'documents',
    templateUrl  : './documents.component.html',
    styleUrls    : ['./documents.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class DocumentsComponent
{
    userDocuments : any;
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */
    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,
        private userService:UserService,public util:UtilityService
        )
    {
        this.getUserDocuments();
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';
        // Set the defaults
        this.menuData = [
            {
                //title   : 'Actions',
                //subtitle: 'Task, project & team',
                type    : 'group',
                children: [
                    {
                        title: 'Personal Details',
                        type : 'basic',
                        icon : 'add_circle',
                        link: 'test'
                    },
                    {
                        title: 'Employee Details',
                        type : 'basic',
                        icon : 'people_alt',
                        link: 'employeedetails'
                    },
                    {
                        title: 'Account Details',
                        type : 'basic',
                        icon : 'work',
                        link: 'accountdetails'
                    },
                    {
                        title: 'Team',
                        type : 'basic',
                        icon : 'person_outline',
                        link: 'team'
                    },
                    {
                        title: 'Documents',
                        type : 'basic',
                        icon : 'person_outline',
                        link: 'hj'
                    },
                    {
                        title   : 'Calender',
                        type    : 'basic',
                        icon    : 'assignment_ind',
                        link: 'calender'
                    }
                ]
            }
        ];
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
    getUserDocuments() {
        this.userService.getUserDocuments()
        .subscribe((res) =>{
            var Documents = res.doclist;
            console.log(Documents)
            for(var i=0;i<Documents.length;i++){
                var stringToReplace = Documents[i].type;
                var desired = stringToReplace.replace(/[/_/]/gi, ' ');
                console.log(desired)
                Documents[i]['replacetype'] = desired;
             }
             this.userDocuments = Documents;
            console.log(this.userDocuments);
        }, err => {
            console.log('Error', err);
            
        })
    }

}
