import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-persondetails',
  templateUrl: './persondetails.component.html',
  styleUrls: ['./persondetails.component.scss']
})
export class PersondetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
