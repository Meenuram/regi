import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
interface DataResponse {
    userId: number;
    id: number;
    title: string;
    completed: boolean;
  }
@Component({
    selector       : 'documents',
    templateUrl    : './documents.component.html',
    styleUrls      : ['./documents.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DocumentsComponent implements OnInit{
   
     userDocuments : any;
     //documentslist : any;
    constructor(private userService:UserService)
    {
        this.getUserDocuments();
    }

ngOnInit() {   
}

getUserDocuments() {
    this.userService.getUserDocuments()
    .subscribe((res) =>{
        var Documents = res.doclist;
        for(var i=0;i<Documents.length;i++){
            var stringToReplace = Documents[i].type;
            var desired = stringToReplace.replace(/[/_/]/gi, ' ');
            Documents[i]['replacetype'] = desired;
         }
         this.userDocuments = Documents;
        
        console.log(this.userDocuments);
    }, err => {
        console.log('Error', err);
        
    })
}


}