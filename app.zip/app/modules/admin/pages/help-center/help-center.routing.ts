import { Route } from '@angular/router';
import { HelpCenterComponent } from 'app/modules/admin/pages/help-center/help-center.component';
import { HelpCenterLeaderBoardComponent } from 'app/modules/admin/pages/help-center/leader-board/leader-board.component';
import { HelpCenterGuidesComponent } from 'app/modules/admin/pages/help-center/guides/guides.component';
import { HelpCenterGuidesCategoryComponent } from 'app/modules/admin/pages/help-center/guides/category/category.component';
import { HelpCenterGuidesGuideComponent } from 'app/modules/admin/pages/help-center/guides/guide/guide.component';
import { HelpCenterSupportComponent } from 'app/modules/admin/pages/help-center/support/support.component';
import { HelpCenterLeaderBoardResolver, HelpCenterGuidesCategoryResolver, HelpCenterGuidesGuideResolver, HelpCenterGuidesResolver, HelpCenterMostAskedLeaderBoardResolver } from 'app/modules/admin/pages/help-center/help-center.resolvers';

export const helpCenterRoutes: Route[] = [
    {
        path     : '',
        component: HelpCenterComponent,
        resolve  : {
            faqs: HelpCenterMostAskedLeaderBoardResolver
        }
    },
    {
        path     : 'leader-board',
        component: HelpCenterLeaderBoardComponent,
        resolve  : {
            leaderboard: HelpCenterLeaderBoardResolver
        }
    },
    {
        path    : 'guides',
        children: [
            {
                path     : '',
                component: HelpCenterGuidesComponent,
                resolve  : {
                    guides: HelpCenterGuidesResolver
                }
            },
            {
                path    : ':categorySlug',
                children: [
                    {
                        path     : '',
                        component: HelpCenterGuidesCategoryComponent,
                        resolve  : {
                            guides: HelpCenterGuidesCategoryResolver
                        }
                    },
                    {
                        path     : ':guideSlug',
                        component: HelpCenterGuidesGuideComponent,
                        resolve  : {
                            guide: HelpCenterGuidesGuideResolver
                        }
                    }
                ]
            }
        ]
    },
    {
        path     : 'support',
        component: HelpCenterSupportComponent
    }
];
