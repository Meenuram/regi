import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit, Inject } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { ThirdPartyDraggable } from '@fullcalendar/interaction';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { Router } from '@angular/router';
import { TeamComponent } from 'app/modules/admin/ui/content-layouts/common/demo-content/team.component';
import { ModernLayoutComponent } from 'app/layout/layouts/horizontal/modern/modern.component';
import {FormsLayoutsComponent} from 'app/modules/admin/ui/forms/layouts/layouts.component';
import { UtilityService } from 'app/shared/services/utility.service';
import { DatePipe } from '@angular/common';
import * as _ from 'underscore';
import { environment } from 'environments/environment';
import { FormControl, FormGroup ,FormBuilder,Validators } from '@angular/forms';

@Component({
    selector       : 'publicwall',
    templateUrl    : './publicwall.component.html',
    styleUrls      : ['./publicwall.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PublicwallComponent implements OnInit{
    /**
     * Constructor
     */
     userProfile :any;
     userTeam : any;
     following:any;
     userfollowingTeam : any;
    usertotalemp : any;
    useratoff : any;
    usernotoff : any;
     public data:any=[];
     userSession:any;
     UserTeamimage:any;
     userimgs:any;
     dataCheck:any;
     allMemberTeams: any;
     teammebergid:any;
     userid:any;
     leaveapproval:any;
     department:any;
     branch:any;
     dob:any;
     AddressLine2:any;
     Mobile:any;
     adress:any;
     MyShift:any;
     profilecredit:any;
   // storage: any;
   userTeam11:any;
   myteammember:any;
   myTeamsMember:any;
   walletData:any;
   walletbalance:any;

   userTeamMember:any;
   gettopsales:any;
   first_date:any;
   current_date:any;
   yesterday:any;
   support:any;
   sendotpmobile:any;
   personalsendotp:any;
   otpverifyform:any;
   personalnumber:any;
   officialnumber:any;
   otpvarification:any;
   mobileverified:any;
   verifiedstatus:any;
   officemobile:any;
   reportingto:any;
   
    constructor(
        @Inject(SESSION_STORAGE) private storage: StorageService,
    private userService:UserService,private router: Router,public util:UtilityService,private datePipe: DatePipe, private formBuilder: FormBuilder)
    {
        this.otpvarification = this.formBuilder.group({
            mobilenumber: [null, [ Validators.required ]],
            otp: [null, [ Validators.required ]]
        });
        
    }

ngOnInit() {     
    this.userid = localStorage.getItem('gid');
    localStorage.setItem('teammebergid',this.userid);
    this.teammebergid = localStorage.getItem('teammebergid');
    // this.userTeam = JSON.parse(localStorage.getItem("profileteamimage"));
    this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
    // localStorage.setItem("teamleadlist", JSON.stringify(res));
    this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    // this.myTeamsMember = setInterval(() => { 
    //     this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    //     if(this.UserTeamimage == null){
            
    //     }else{
    //         this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
    //         this.userTeamMember = JSON.parse(localStorage.getItem("profileteamimage"));
    //         clearInterval(this.myTeamsMember)
    //     }
    // },500);
    
    
    this.userProfile = JSON.parse(localStorage.getItem("myProfile"));
    console.log(this.userProfile)
    this.userProfile = this.userProfile[0];
    // console.log(this.userProfile);
    console.log( _.isArray(this.userProfile))
        this.department = this.userProfile.department;
        this.branch = this.userProfile.branch;
        this.dob = this.userProfile.dob;
        this.adress = this.userProfile.AddressLine2;
        this.Mobile = this.userProfile.Mobile;
        this.otpvarification.controls['mobilenumber'].setValue(this.Mobile);
        this.officemobile = this.userProfile.officemobile;
        this.reportingto = this.userProfile.reporting_to;
        this.MyShift = this.userProfile.myshifttime;
        this.verifiedstatus = this.userProfile.isverified;
        if(this.verifiedstatus==1){
           this.mobileverified=true;
        }else{
            this.mobileverified=false;
        }
        // this.userService.getUserTeamimage()
        // .subscribe((res) =>{
        //     localStorage.setItem("teamimage",  JSON.stringify(res.data));
        //     this.UserTeamimage =  JSON.stringify(res.data);
        // }, err => {
        //     console.log('Error', err);
            
        // })
    
        this.getUserProfile();
        // //this.getUserTeamimageFunction();
        // this.getTeamImage();
        //wallet
        this.walletData = JSON.parse(localStorage.getItem("getwalletdata"));
        // this.walletbalance = this.walletData.credit - this.walletData.debit;
        // console.log(this.walletbalance);
        if(this.walletData.status==1){
            this.profilecredit = this.walletData.credit;
            if(!this.walletData){
                this.walletbalance =0;
            }else if(this.walletData.credit == 0 && this.walletData.credit == 0 && this.walletData.debit == 0){
            this.walletbalance =0;
            }else if(this.walletData.status == 0){
                this.walletbalance =0;
                this.walletData.credit = 0;
                this.walletData.debit = 0;
            }else{
                this.walletbalance = this.walletData.credit - this.walletData.debit;
            }
        }else{
            this.profilecredit = 0;
            this.walletbalance = 0;
        }

        //topsales
        this.gettopsales = JSON.parse(localStorage.getItem("topthreesales"));
        console.log(this.gettopsales)
        // this.gettopsales = [];
        var date = new Date(); 
        var firstDay = new Date(date.getFullYear(),date.getMonth(), 1);
        this.first_date = this.datePipe.transform(firstDay,"MMMM, yyyy");
        // this.current_date = this.datePipe.transform(salesdate,"MMMM d, yyyy");
        this.current_date = localStorage.getItem("salesdate");

        this.support=true;
        this.sendotpmobile=true;
        this.personalsendotp=true;
        this.personalnumber=true;
        this.officialnumber=true;
}


// getTeamImage(){
//     const postData = {
//         "bid":localStorage.getItem('bid'),
//         "empgid":localStorage.getItem('gid'),
//         "api-key":"steams"
//     };
//     this.userService.getProfileteam(postData)
//     .subscribe((res) =>{
//         this.ProfileTeamimage = res.data;
//         console.log(this.ProfileTeamimage);
//         localStorage.setItem("profileteamimage", JSON.stringify(this.ProfileTeamimage));
//     })
// }

getUserProfile() {
    const postData = {
        // "gid":usersession.gid,
        // "bid":usersession.bid,
        "gid":localStorage.getItem('gid'),
        "bid":localStorage.getItem('bid'),
        // "key":"getEmpData"
        "operation": btoa(localStorage.getItem('gid') + 'TXhfVjJ4amVHUXhTa2hTYWtKYVZWUXdPUT09'),
        // "secret": localStorage.getItem('secret')
        "secret": environment.ANOTHER_API_SECRET
        };
        // console.log(postData)
    this.userService.getUserProfile(postData)
    .subscribe((res) =>{
        // console.log(res)
        localStorage.setItem('userimage', res.data[0].image);
        localStorage.setItem('myprofileimg', res.data[0].image);
        localStorage.setItem('name', res.data[0].name);
        localStorage.setItem('mydepartment', res.data[0].department);
        localStorage.setItem('myname', res.data[0].name);
        localStorage.setItem('FatherName', res.data[0].FatherName);
        localStorage.setItem('Mobile', res.data[0].Mobile);
        localStorage.setItem('dob', res.data[0].dob);
        localStorage.setItem('personalemail', res.data[0].personalemail);
        localStorage.setItem('Gender', res.data[0].Gender);
        localStorage.setItem('MaritalStatus', res.data[0].MaritalStatus);
        localStorage.setItem('Nationality', res.data[0].Nationality);
        localStorage.setItem('LanguageKnown', res.data[0].LanguageKnown);
        localStorage.setItem('Blood', res.data[0].Blood);
        localStorage.setItem('aadhaar', res.data[0].aadhaar);
        localStorage.setItem('pan', res.data[0].pan);
        localStorage.setItem('AddressLine1', res.data[0].AddressLine1);
        localStorage.setItem('AddressLine2', res.data[0].AddressLine2);
        localStorage.setItem('ZipCode', res.data[0].ZipCode);
        localStorage.setItem('City', res.data[0].City);
        localStorage.setItem('State', res.data[0].State);
        localStorage.setItem('Country', res.data[0].Country);
        localStorage.setItem('employee_id', res.data[0].employee_id);
        localStorage.setItem('designation', res.data[0].designation);
        localStorage.setItem('doj', res.data[0].doj);
        localStorage.setItem('reporting_to', res.data[0].reporting_to);
        localStorage.setItem('extention', res.data[0].extention);
        localStorage.setItem('officeemail', res.data[0].officeemail);
        localStorage.setItem('personalmobile', res.data[0].personalmobile);
        localStorage.setItem('officemobile', res.data[0].officemobile);
        localStorage.setItem('shift', res.data[0].myshifttime);
        localStorage.setItem('branch', res.data[0].branch);
        localStorage.setItem('branch', res.data[0].branch);
        localStorage.setItem('accountnumber', res.data[0].accountnumber);
        localStorage.setItem('accountname', res.data[0].accountname);
        localStorage.setItem('bankname', res.data[0].bankname);
        localStorage.setItem('bankbranch', res.data[0].bankbranch);
        localStorage.setItem('ifsccode', res.data[0].ifsccode);
        localStorage.setItem('pfno', res.data[0].pfno);
        localStorage.setItem('uanno', res.data[0].uanno);
        localStorage.setItem('esino', res.data[0].esino);
        localStorage.setItem('following', res.following);
        localStorage.setItem('team', res.team.length);
        localStorage.setItem('teamgid', res.team.gid);
        
        this.userProfile = res.data;
        this.util.profileHeader('hai..');
        // this.userTeam = res.team;
        localStorage.setItem('teampagevalues', JSON.stringify(res.team));
        this.userTeam11 = JSON.parse(localStorage.getItem('teampagevalues'));
        
        this.following = res.following;
        this.userfollowingTeam = res.followingarray;
        this.usertotalemp = res.totalEmp;
        this.useratoff = res.atoffc;
        this.usernotoff = res.notoffc;
        this.leaveapproval = res.approvals;
        localStorage.setItem("myProfile", JSON.stringify(this.userProfile));
        localStorage.setItem("leaveapproval", JSON.stringify(this.leaveapproval));
        
        localStorage.setItem("userimgssec", JSON.stringify(this.userimgs));
  

// this.allMemberTeams = setInterval(() => { 
//     this.UserTeamimage = JSON.parse(localStorage.getItem('teamimage'));
//     if(this.UserTeamimage){
//         if(this.usertotalemp){
//         for(var i=0;i<this.usertotalemp.length;i++){
//             for(var j=0;j<this.UserTeamimage.length;j++){
//                 if(this.usertotalemp[i].gid == this.UserTeamimage[j].gid){
//                     this.usertotalemp[i]['profileImg'] = this.UserTeamimage[j].image
//                     this.usertotalemp[i]['gender'] = this.UserTeamimage[j].gender
//                 }
 
//             }
//          }
//         }
//          if(this.useratoff){
//          for(var i=0;i<this.useratoff.length;i++){
//              for(var j=0;j<this.UserTeamimage.length;j++){
//                  if(this.useratoff[i].gid == this.UserTeamimage[j].gid){
//                      this.useratoff[i]['profileImg'] = this.UserTeamimage[j].image
//                      this.useratoff[i]['gender'] = this.UserTeamimage[j].gender
//                  }
  
//              }
//           }
//         }
//         if(this.usernotoff){
//           for(var i=0;i<this.usernotoff.length;i++){
//              for(var j=0;j<this.UserTeamimage.length;j++){
//                  if(this.usernotoff[i].gid == this.UserTeamimage[j].gid){
//                      this.usernotoff[i]['profileImg'] = this.UserTeamimage[j].image
//                      this.usernotoff[i]['gender'] = this.UserTeamimage[j].gender
//                  }
  
//              }
//           }
//         }
//          localStorage.setItem("totalempls", JSON.stringify(this.usertotalemp));
//          localStorage.setItem("atoffice", JSON.stringify(this.useratoff));
//       localStorage.setItem("notoffice", JSON.stringify(this.usernotoff));
//       clearInterval(this.allMemberTeams);
//     }else{
       
//     }
// }, 500);


// localStorage.setItem("follweteam", JSON.stringify(this.userfollowingTeam));

// let myCompOneObj = new ModernLayoutComponent(null,null,null,null,null);
//     myCompOneObj.ChangeDoCheck();
        
    }, err => {
        console.log('Error', err);
        
    })
}

viewTeam(gid){
    //console.log(gid);
    localStorage.setItem("teammebergid", gid);
    // this.util.profileHeader('hai');
    this.router.navigate(['/ui/content-layouts/left-sidebar/fullheight/basic/team']);
    // let myCompOneObj = new TeamComponent(null,null,null);
    // myCompOneObj.hellofunction();   
}
teamsNAmeChange(names){
    var changedname = names.split(" ", 1);
    return changedname[0];
}
mobileUpdate(){
    this.support=false;
}
supportSave(){

}
sendotp(){
    this.sendotpmobile=false;
}
sendotppersonal(){
    this.personalsendotp=false;
    const postData = {
        "operation":"mobUpdate",
        "module":"otp", 
        "mobile":this.otpvarification.get('mobilenumber').value,
        "bid": localStorage.getItem('bid'),
        "gid": localStorage.getItem('gid')
     };
     this.userService.otpcheck(postData)
        .subscribe((res) =>{
            var result = res;
        });
}
saveotp(){
    const postData = {
        "operation":"mobUpdate",
        "module":"verify",
        "mobile":this.otpvarification.get('mobilenumber').value,
        "bid": localStorage.getItem('bid'),
        "gid": localStorage.getItem('gid'),
        "otp":this.otpvarification.get('otp').value
     };
     this.userService.otpcheck(postData)
        .subscribe((res) =>{
            var result = res.status;
            if(result==1){
                alert("Update Successfully");
            }else{
                alert("error");
            }
        });
}
closeform(){
    this.support=true;
}
editmobile(){
    this.personalnumber=false;
}
editofficial(){
    this.officialnumber=false;
}
closebutton(){
    this.otpverifyform.back();
}

}
