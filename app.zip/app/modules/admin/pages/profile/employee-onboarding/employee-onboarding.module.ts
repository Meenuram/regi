import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';
import { SharedModule } from 'app/shared/shared.module';
import { EmployeeOnboardingComponent } from './employee-onboarding.component';
import { EmployeeOnboardingRoutes } from './employee-onboarding.routing';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from "@angular/material/card";
import { NgxDropzoneModule } from 'ngx-dropzone';

// import { AgmCoreModule } from '@agm/core';
// import { BrowserModule } from '@angular/platform-browser';

@NgModule({
    declarations: [
        EmployeeOnboardingComponent
    ],
    imports     : [
        RouterModule.forChild(EmployeeOnboardingRoutes),
        MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatRadioModule,
        MatSelectModule,
        MatStepperModule,
        SharedModule,
        MaterialFileInputModule,
        MatDividerModule,
        MatCardModule,
        NgxDropzoneModule
        // BrowserModule,
        // AgmCoreModule.forRoot({
        //     apiKey: 'AIzaSyD0z9KLOLyCtmTMCosCO2N1JOD_JpjdaFo',
        //     libraries: ['places']
        // })
    ]
})
export class EmployeeOnboardingModule
{
}

