import { Route } from '@angular/router';
import { TimesheetComponent } from './timesheet.component';

export const timesheetRoutes: Route[] = [
    {
        path     : '',
        component: TimesheetComponent
    }
];
