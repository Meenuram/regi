import { Component, ViewEncapsulation, ElementRef, HostListener } from '@angular/core';
import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { UtilityService } from 'app/shared/services/utility.service';
import { FormControl, FormGroup ,FormBuilder,Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';

@Component({
    selector     : 'force-checkout',
    templateUrl  : './force-checkout.component.html',
    styleUrls    : ['./force-checkout.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ForceCheckoutComponent
{
    leftscrollvalue:any;
    @HostListener("window:scroll", ["$event"])
    onWindowScroll() {
        console.log('hai'+document.documentElement.scrollTop)
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
     if(pos == max )   {
     //Do your action here
     }
        if (document.documentElement.scrollTop > 400) {
            this.leftscrollvalue = "abcd" ;
        } else {
            this.leftscrollvalue = "" ;
        }
    }


    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */
    forcecheckoutform: FormGroup;
    changedRequestvalue:any;
    requesttype:any;
    date:any;
    exptime:any;
    actualtime:any;
    changetime:any;
    reason:any;
    current_date:any;
    form:any;
    actualcheckin:any;
    moduleid:any;
    Category = [
        {value: '1', viewValue: 'Late checkin'},
        {value: '2', viewValue: 'Force Checkout'}
      ];
      exptime_display:boolean;
      actualtime_display:boolean;
      changetime_display:boolean;
      reason_display:boolean;
      dates:any;
    constructor(private formBuilder: FormBuilder,private _treoMediaWatcherService: TreoMediaWatcherService,
        private userService:UserService,public util:UtilityService,private datePipe: DatePipe
        )
    {
        
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';

        this.forcecheckoutform = this.formBuilder.group({
            requesttype: [null, [ Validators.required ]],
            date: [null, [ Validators.required ]],
            exptime: [null, [ Validators.required ]],
            actualtime: [null, [ Validators.required ]],
            changetime: [null, [ Validators.required ]],
            reason: [null, [ Validators.required ]],
        });
        this.exptime_display = false;
        this.actualtime_display = false;
        this.changetime_display = false;
        this.reason_display = false;
    
    }
 getDates()
{
    this.changedRequestvalue = this.forcecheckoutform.get('requesttype').value;
    this.dates = this.forcecheckoutform.get('date').value;
    console.log(this.dates)
    const postData = {
        "bid":localStorage.getItem('bid'),
        "egid":localStorage.getItem('gid'),
        "hrgid":localStorage.getItem('gid'),
        "date":this.dates,
        "type":this.changedRequestvalue,
        "apiKey":"checkoutSelect",
        "description":"test"
    }
    this.userService.getForcecheck(postData)
        .subscribe((res) =>{
            var result = res.msg;
            console.log(result);
            this.forcecheckoutform.controls['exptime'].setValue(result.expected_checkin);
            this.forcecheckoutform.controls['actualtime'].setValue(result.actual_checkin);
            this.forcecheckoutform.controls['changetime'].setValue(result.actual_checkin);
            this.actualcheckin = result.actual_checkin;
            this.moduleid = result.id;
            })
    this.exptime_display = true;
    this.actualtime_display = true;
    this.changetime_display = true;
    this.reason_display = true;
}
forcesubmitbtn(){
    const postData = {
        "bid":localStorage.getItem('bid'),
        "egid":localStorage.getItem('gid'),
        "hrgid":localStorage.getItem('gid'),
        "apiKey":"checkOut",
        "moduleid":this.moduleid,
        "actualtime":this.actualcheckin,
        "changetime":this.forcecheckoutform.get('changetime').value,
        "date":this.dates,
        "description":this.forcecheckoutform.get('reason').value,
        "type":this.changedRequestvalue
    }
    console.log(postData);
    this.userService.getForcecheck(postData)
        .subscribe((res) =>{
            var result = res;
            console.log(result);
            
            })
}
clearbutton(){
    this.forcecheckoutform.reset();
}


    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        this.current_date = this.datePipe.transform(new Date(),"yyyy-MM-dd");
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
    changeRequest(e) {
        this.changedRequestvalue = this.forcecheckoutform.get('requesttype').value;
        // var changedRequest = this.forcecheckoutform.get('requesttype').value;
        // if(changedRequest == '1' || changedRequest == '2'){
        //     this.exptime_display = true;
        //     this.actualtime_display = true;
        //     this.changetime_display = true;
        //     this.reason_display = true;
        // } 
    };
}
