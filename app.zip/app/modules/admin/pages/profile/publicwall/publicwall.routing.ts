import { Route } from '@angular/router';
import { PublicwallComponent } from './publicwall.component';

export const publicwallRoutes: Route[] = [
    {
        path     : '',
        component: PublicwallComponent
    }
];
