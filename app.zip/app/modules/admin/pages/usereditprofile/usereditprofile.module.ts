import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TreoCardModule } from '@treo/components/card';
import { SharedModule } from 'app/shared/shared.module';
import { UsereditprofileComponent } from 'app/modules/admin/pages/usereditprofile/usereditprofile.component';
import { usereditprofileRoutes } from 'app/modules/admin/pages/usereditprofile/usereditprofile.routing';
import { PersondetailsComponent } from './persondetails/persondetails.component';

@NgModule({
    declarations: [
        UsereditprofileComponent,
        PersondetailsComponent
    ],
    imports     : [
        RouterModule.forChild(usereditprofileRoutes),
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatTooltipModule,
        TreoCardModule,
        SharedModule
    ]
})
export class UsereditprofileModule
{
}
