import { Component, OnInit, Inject } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { Router } from '@angular/router';
import { ModernLayoutComponent } from 'app/layout/layouts/horizontal/modern/modern.component';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { UtilityService } from 'app/shared/services/utility.service';
import { MatDialogRef } from '@angular/material/dialog';
import {WebcamImage} from 'ngx-webcam';
import { Subject, Observable } from 'rxjs';
import { ImageCroppedEvent } from 'ngx-image-cropper';

@Component({
  selector: 'app-profileimagecap',
  templateUrl: './profileimagecap.component.html',
  styleUrls: ['./profileimagecap.component.scss']
})
export class ProfileimagecapComponent implements OnInit {
  userwebcam:boolean;
  myprofileimg:any;
  fileToUpload: any;
  imageUrl: any;

  webcamSrc:any;
  fileSrc:any;

  imgTag:any;
  paraTag:any;

  imgcroperDiv:any;
  dropzoneDiv:any;
  iconDiv:any;

  imageChangedEvent: any = '';
  croppedImage: any = '';
  imageResult:any;


  activeColor: string = "green";
  baseColor: string = "#ccc";
  overlayColor: string = "rgba(255,255,255,0.5)";

  dragging: boolean = false;
  loaded: boolean = false;
  imagetagLoaded: boolean = false;
  imageSrc: string = "";
// imageurl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAOh0lEQVRoQ6Wa2W/c9hHHh9x7Ja3uW9YtH3LiuECdPKSA/9y+9K1A+9C8uEUeAjuFY8eXJOuwrPvWaqXd5ZIsPkMOTckyVDgECGq53B/nO+d35ifnIgxDERFXRBwRycRX8UX4xuVGfISOCA8HEl3tbIUi29vbcnh4KLVaTRqNhjSbTWm1WuI4jmSzWcnlcpLP56WtrU16e3tlaGhIsk70TjtNBkclio7AF3Fiwbjtx+9FBg4HAOkFrlskDcCE3z86kcOjI3m/siy+70sQBCosJ397nqdnGgDrxPpSUJlMRibHJ6S/r096uyoKRN+fAnCd8tIKdOopAMkC1ywCSn54eFyVj5sbsn9wILWLcxXehDIAfAZEGhTfpQ97lnvt5TYZHBiQW6Nj0tlRvhbEl6zvNGMAag40FIi4mDY2rymj7gWy9uGDrG9uyNHJsQrnZjJSLpUSYQ0MwrmuqydgDJC+I/Udfzc9T1qep9g6OyoyPjomkxMTUspHvqsyqeVEglDEcaPPak2+9019ia1in0s9dHB0KotLS7K1uyPNlieZbFZR6k+DMPLhlIa5b5+JA4DgLly5D1DOlu9LvljQN/leS4HkszkZHRqWO7dvS09Xh66diKYSXzKkOH4QhlesmzzhtURW1lbV13f29+S8fiFuNiO5fF5RYoVCNid+q6UBy2eOtLAWyAbI9AUY1mi0PI0HF2Cs0fKlmC9If0+vdHd1yez0jOSyl4VOA3LCIMpCapIUutp5U7Z3d+TN27cSom1HxA8D8fB53Mt1JZvJiLR81R6CIUi5XNaTjJPWOFmJDHVxcaHBrVbJZaUloSCCJhrHlSyuJ44CCVu+PPj2WxkaGJS2cj5BkQ7ySwBYRVNVIPLh44Ysr6zIyVlVBY5yraNgNNOAmxf7gZq9vb1d02N3d7eUSiUFhPZVu66rLgMAUu3x8bHU63VpBX4CgLU06HHJUCQDQMeVSlu7TE9NyfjYqGQwmjl/DOczCyDo+5UP8vrNG8kW8qr1RrMpnt9KfN8yDGZvL5ZleGhI+vv7NdfjPmgf4dE2h1kDEBq4zaZsbGzI6tqaSNaVeqOhCigWi1KrnkmIa+byEviRO3n1htyfn5fZ6Yko3lJp9jMAp7W6vHr9WjZ3ttXfyTQNr6kaR7gAkweBClUuljTg+np7VQAK2Pn5eVID+IzQWKRQKChAhOR6enqqqXh7b1dOqqe6Ns80641o/VxO3QhLcB0ZHJL5e/eks710PQDcpFb35PdXr3RRzEuQORlXvFYrCU4E4iDA0PpAX7+UikV9Ke6xv7+vroKfYwVOABAXXCuVip6AYF1qClW8dn6u9yztYiksgRtZfAwPDKol2oq5BIQTxGmB/PHm3ZK8W1pUd8kXCurz/pWCxKK8aHhwSMbGxjSQ8eejoyM5ODhQzeIi5mYsz/N2AqSnp0dPaMVptSrr6+uys7erwmuKhkIEgX4u5PMqbKNel1wmK3fnbsuduWktdhxaB3Cpk+q5/PLsqRapbC6nmsd91BJa4p2o1DuOdLS1y+joqIyOjKj/7uzsyObmppydnSWWMk0SxGkwuEpHR4cMDw9LX1+frrm5taUgqOy8G8ujRA6LhdAPtE50d3bJD39+JBVcCQBebIF3S8vy8vUrTY+kNwI3m8vqZ83hQagmLReK6jYELq5weHwk6x8/KgDcCx9HaAOA5nEjK15aOwoFGRwc1DVQRrValQ/r67K7v0f60XcagKg++GqJVtPTzPfNvXm5MzsdWQAqcXp2Lr+9eKFmzFEZKTBeMylIGrxeS/M9vj95a1x6uro1py2vruqLSY0IjnAIbxnHUqhxH2IDEKRb8vvo8LC4jisbW5uy8mFNqzPJo+lHTNZoCJZAgWSkwf4B+e7BA+nsaBMlc4vLK7KwuKg0QQNJoSk/0AXwPa/ZFL/pqfZnpqdVc5icmMGPEQztA9ayD2sZU7UYID6IGfyf7AX3waW2d3ZkYWlRXVILXFwwWQ/BcWBEwgq5bFbm5ubk7uyMOLUwDJ/8/LOcnJwkmiPQmo2GaoAXkxpLhaKmNDQP2SKNQsReLbyVs1pNAxcLmM/jNhqUWC+m2vydBgQR/NN3D9UtUNrTp09VcemMpHWLYC4UVA6SBlA6Ozvl8V9+FOcoDMInT55o6tMK2/KVYaJRBMYFGvWG5mW+B8D09LQueNGoy39f/KbFzrLGdawlzReNXigrdRz54dH3euX3z5490ysWQnH8bQrgM4VRLRKGasHHjx+Ls7i3Gz5//lw1qPTXD6RYKEQ0IH6YIOJvFgTA7OysLnB2XtPMRbYylpkmdLzMLGEguMdpmv3h++9VObjdr7/+qhZCeVbNsSj3uPIMMlohffjwoTi/vHsbrqysRPw+BoCPGQDNQPBwOJLvS1elUwFgwtp5TZ6/fCEX9XryEgSzAEYIpc1xIbT+gHcRLyhhfn5eAZCJXr58qcJb7TDSZwCMmpusU1NT4vz07GlIBTU/xQIaLLEFVGNuFEjco3uanJzUKoxG1tY/yNb2ttYAY6G4gKVLFMBzFk/WL0P8bt26JX39faq4vb09WV5eTsCicaPoBkDrUdwkcaUYOn//z79De6E2InH7YzGA75HmIFaWkWjIqcIIdVY7U1IGhUDjnAjJy/ktguCe1htblaaQzczMRDm/5WkhA0Ta1ay35spa1lNYV4cVnb/99C/NmoaWlElWUHNZ++e42myYi+E+BDIa54W7u7tajUkE1o3Z1YIu3cjgOiihb6Bf0+Vp9VTev3+vwWs+bnXD2lQUwT1zIz5rtv/rP/8R8sEKDPTVXAgAUUmIuiUNyqangpOHAcI9sgOEbGtrS4UgQ5kLIJD9zcv5LdrH/PlCXhukg8MDWVhYSHzfhE6DN4EtkK3C3whAs0tMa5XL1xv6ImIAPoQ2YZmYGRcwS5gQlt0wN34PhaBwqTb9luwdHMjm1qYSQQTmOaMdlnKt20OZnwG4yYU0jbX8T710EBUVBBkZGUl8G4GwIi/ACliFv3mWE8G4mosAmPpBCgYAFtS4i1OsZRqrL190oZuCmJe26O7jqtpWKktX3Atw9QNfiZ+lRkudVE1AAMz6ZJ6xnpjnNAhdV10Iy8GnjIZYDCSx+aUgvimNqv96LbUApoeA4QoIgED7hwdSPTtTs/M9oEzTaFvLf8xOSbX0CxYLdHGVzoquQwIgk1lDZClTLRUXsmvT6E2FTJsLP1A6i9swPePFCILm6N7OLy5UCGKBE3DWhVlXhltRrBDUUiyBSC2A4fI839MrE0vm68Zm00nhUiG7iUooH3Ez+hKCtre7R32VjAP9Pq2dRROyOGOlyZpZybSY5kTm2709PTpWJK3i/1gAELgTaxmj/SKVuInMYYFKR0VGhodlYGBAyR7+StDBhaoX55Ir5BPSZRVdB1cxrTDTp7OKAvV97bg6KxVNCKzPfZTDibVuJHNX6TSLJnRaHMnlc9r6TYxPqBXQ0NLSkjbwZBBfQsnmo2Y8zWOsOKYrKOBM81pNxdE2Metm1D0pjrgn71hbW9M+G6KdptMA4rdKp3/8MWpo3i29l8XFxcQ3jSnq9C2bldnbcwoC7bAwZd9choHr1x5KEGGecdM/Pj6ubgpIrPxuYSGiz8k4V1RJKIVCOgeZo6U8qda0pYQSWAahpcTkvX19Mj45kUwQVldX1X2sShYKxa+VP2K4WCDO/caxkIEYgCXT3KA44glLENy42oMHD6TSVo4AIMHC0rIOtBLWGPfE0zMzMjg8pGAASPNNOmTBiJtEU4uvOQAQBH7kSq2WugVWwNq0sAwKsDbfWX+Ade7fvy+3Z6YvTyVOaxfa0h0dH6uJ3Hiscm9+XheGMSI8GYK+1XJ7Npv7GtmT37AXwYFrkEphuWMjoyocsYBrKy2hoW96WmcePXokne3liKfZWIUPjFYgVUzMqJKsMjk1JcVSSbVA2iR4lWnG45Y/YgHemcm46uPGt5Qv9Q+owFh6e3NL30ePjtJuz87J3TuziQIuAbioe/LqzWsNICZyitB1NNswMYMGQMB0+MTLten4ehfS9Jp1k81A3RsoFKStXFbWi1UY5UBjNFMNDMg39+9LqfjJ6k4rVV0IhurZhbx++0YDFcHx/abHkCv3acyYcbVJIdj+SBbSbOdKtFZMTVgQGu81mlLM53U2CjCGYPfvzUtHe/HSiD0ZLZpNdLy+vKaWiAQMtaBQD3CbaM9TlHEWyyXxfebVX3/4EigAtG5TEdyHzY1Ke0fUyjaaMn/3nsxMj3+2g5nskaWF8EOR9fUNWV5dUT+0Aa8Nu6yiKhimBPFGnjFI4KQphRUw2yuz73kGF0p+hzlT+25uKAri0gbHFW3pdDq962e6rF00NRZe/P4yGjHGI5YgDJL40H0yUmEMwNpIK3LWiBgY9fk4+A1UqRQ1MGiag5qgI/W4N5+/c1eGBgelXMp/trmhMWqbfNeB8HzRXpWJNR2Tjv0ymWj6JqFmq1JbWwLAurA0kHQDE2WdKK7s8FvRfhm+rw1/vCEy2NevM6ipyUnJxf8tcHV3Bs0n+wMaUPF+bHork3tHJ1Ut6xAsxok6bchl9XkPzcU79LrGpz3DZE/YJtXp7/U5mqR4Qsdn+m7WHhwYlNuzs9IT796rpmMBr+6o6hZTeneSDT59KC4wZpmG5+v45OPHj3JyehqZO59L/nch7TZp+mwjELRsmjdAuIkLwSMWXFeLFFxoYnxc8sRGKjeoHDx/dZ848KN94jSItDulY4a/GcWzHwCtgE5TBQjy9BiFdxkIEzzdLySzH3GkmM0KbSoFDOG7uzqi+vN/JDbtQ67bJ74uHtS94kW5Hh6fyt7Bvmzu7Oho0YZjtlN5tRVUF4mHY4DiOTbJp8duSW9Xt/T2durqN6Xkq99f3ieON7t5iIzGyd5sEh8pAHaP3NEIQi18tv8LY6Rqc9p0zpp4+D4zITReyrjCeMr+o+c6xZlLm+tcBfA/FxH6ftBCagIAAAAASUVORK5CYII="
  constructor(public dialogRef: MatDialogRef<ProfileimagecapComponent>, private userService:UserService,public util:UtilityService) { 
    this.userwebcam = false; 
    this.webcamSrc = true;
    this.fileSrc = false;

    this.imgTag = false;
    this.paraTag = true;
    this.imageResult = false;

    this.imgcroperDiv = false;
    this.dropzoneDiv = true;
    this.iconDiv = true;
    this.util.profileHeader('hai..');
  }

//
  // public webcamImage: WebcamImage = null; 
  //   private trigger: Subject<void> = new Subject<void>(); 
  //   triggerSnapshot(): void {
  //       this.userwebcam = true; 
  //       this.trigger.next(); 
  //   } 
  //   handleImage(webcamImage: WebcamImage): void { 
  //     console.info('Saved webcam image', webcamImage.imageAsDataUrl); 
  //     var profile = webcamImage.imageAsDataUrl; 
  //     console.log(profile);
  //     const postData = profile;
  //     this.userService.profileImageupload(postData)
  //         .subscribe((res) =>{
  //         console.log(res);
  //         this.dialogRef.close();
  //         window.location.reload();
  //     })
  //   } 
//


///////////

handleDragEnter() {
  this.dragging = true;
}

handleDragLeave() {
  this.dragging = false;
}

handleDrop(e) {
  e.preventDefault();
  this.dragging = false;
  this.handleInputChange(e);
}

handleImageLoad() {
  this.imagetagLoaded = true;
}

handleInputChange(e: any): void {
  this.imageChangedEvent = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
  var pattern = /image-*/;
  var reader = new FileReader();
  if (!this.imageChangedEvent.type.match(pattern)) {
    alert("invalid format");
    return;
  }

  this.loaded = false;

  reader.onload = this._handleReaderLoaded.bind(this);
  reader.readAsDataURL(this.imageChangedEvent);
  this.iconDiv = false;
}

_handleReaderLoaded(e) {
  var reader = e.target;
  this.imageSrc = reader.result;
  this.loaded = true;
  this.imgcroperDiv = true;
  this.dropzoneDiv = false;
  this.iconDiv = false;
}
change(){
  this.imgcroperDiv = false;
  this.dropzoneDiv = true;
}
imageCropped(event: ImageCroppedEvent) {
  this.imgcroperDiv = true;
  this.dropzoneDiv = false;
  this.iconDiv = false;
  this.croppedImage = event.base64;
}

/////////////
// fileChangeEvent(event: any): void {
//   this.imageChangedEvent = event;
// }
// imageCropped(event: ImageCroppedEvent) {
//   this.imgTag = true;
//   this.paraTag = false;
//   this.imageResult = true;
//   this.croppedImage = event.base64;
//   console.log(this.croppedImage)
// }
saveImage(){
    this.userService.profileImageupload(this.croppedImage)
    .subscribe((res) =>{
      if(res.status == '1'){
        this.util.profileimageUpdate('hai');
        this.util.profileHeader('hai');
        this.dialogRef.close();
      }else if (res.status == '0'){
        alert('Error');
      }
    })
}
imageLoaded() {
  // show cropper
}
cropperReady() {
  // cropper ready
}
loadImageFailed() {
  // show message
}


//image upload

// handleFileInput(file: FileList) {
//   this.fileSrc = true;
//   this.webcamSrc = false;
//   this.userwebcam = true; 
//   this.fileToUpload = file.item(0);
//   //Show image preview
//   let reader = new FileReader();
//   reader.onload = (event: any) => {
//     this.imageUrl = event.target.result;
//     console.log(this.imageUrl)
//     this.userService.profileImageupload(this.imageUrl)
//         .subscribe((res) =>{
//         console.log(res);
//         this.dialogRef.close();
//         window.location.reload();
//     })
//   }
//   reader.readAsDataURL(this.fileToUpload);
// }

//image upload   
    // public get triggerObservable(): Observable<void> { 
    // return this.trigger.asObservable(); 
    // } 
    

  ngOnInit(): void {
  }
    actionFunction() {
      alert("You have logged out.");
      this.closeModal();
    }

    // If the user clicks the cancel button a.k.a. the go back button, then\
    // just close the modal
    closeModal() {
      this.dialogRef.close();
    }

}
