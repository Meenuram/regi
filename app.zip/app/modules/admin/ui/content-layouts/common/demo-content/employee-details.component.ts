import { Component, ViewEncapsulation, Inject } from '@angular/core';
//import { TreoNavigationItem } from '@treo/components/navigation/navigation.types';
import { Subject } from 'rxjs';
import { TreoMediaWatcherService } from '@treo/services/media-watcher';
import { takeUntil } from 'rxjs/operators';
import { UserService } from 'app/shared/services/user.service';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { UtilityService } from 'app/shared/services/utility.service';


@Component({
    selector     : 'employee-details',
    templateUrl  : './employee-details.component.html',
    styleUrls    : ['./employee-details.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class EmployeeDetailsComponent
{
    drawerMode: 'over' | 'side';
    drawerOpened: boolean;
    scrollMode: string;
    userempid:any;
    userdesignation:any;
    userdoj:any;
    userrepto:any;
    userextention:any;
    userofficeemail:any;
    userpersonalmobile:any;
    userofficemobile:any;
    usershift:any;
    userbranch:any;
    //menuData: TreoNavigationItem[];
     // Private
     private _unsubscribeAll: Subject<any>;
     /**
     * Constructor
     *
     * @param {TreoMediaWatcherService} _treoMediaWatcherService
     */
    
    constructor(private _treoMediaWatcherService: TreoMediaWatcherService,
        @Inject(SESSION_STORAGE) private storage: StorageService,
        private userService:UserService,public util:UtilityService
        )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();

        // Set the defaults
        this.drawerMode = 'side';
        this.drawerOpened = true;
        this.scrollMode = 'normal';
    }
    /**
     * On init
     */
    ngOnInit(): void
    {
        this.util.profileHeader('hai');
        // Subscribe to media changes
        this._treoMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Set the drawerMode and drawerOpened if 'lt-lg' breakpoint is active
                if ( matchingAliases.includes('lt-lg') )
                {
                    this.drawerMode = 'over';
                    this.drawerOpened = false;
                }
                else
                {
                    this.drawerMode = 'side';
                    this.drawerOpened = true;
                }
            });
            this.userempid = localStorage.getItem('employee_id');
            if(this.userempid != 0 || this.userempid != "null"){
                this.userempid = localStorage.getItem('employee_id');
            }else{
                this.userempid = '';
            }

            this.userdesignation = localStorage.getItem('designation');
            if(this.userdesignation == 0 || this.userdesignation == "null"){
                this.userdesignation = '';
            }else{
                this.userdesignation = localStorage.getItem('designation');
            }
            
            this.userdoj = localStorage.getItem('doj');
            if(this.userdoj == 0 || this.userdoj == "null"){
                this.userdoj = '';
            }else{
                this.userdoj = localStorage.getItem('doj');
            }
            
            this.userrepto = localStorage.getItem('reporting_to');
            if(this.userrepto == 0 || this.userrepto == "null"){
                this.userrepto = '';
            }else{
                this.userrepto = localStorage.getItem('reporting_to');
            }
            
            this.userextention = localStorage.getItem('extention');
            if(this.userextention == 0 || this.userextention == "null"){
                this.userextention = '';
            }else{
                this.userextention = localStorage.getItem('extention');
            }
            
            this.userofficeemail = localStorage.getItem('officeemail');
            if(this.userofficeemail == 0 || this.userofficeemail == "null"){
                this.userofficeemail = '';
            }else{
                this.userofficeemail = localStorage.getItem('officeemail');
            }

            this.userpersonalmobile = localStorage.getItem('personalmobile');
            if(this.userpersonalmobile == 0 || this.userpersonalmobile == "null"){
                this.userpersonalmobile = '';
            }else{
                this.userpersonalmobile = localStorage.getItem('personalmobile');
            }

            this.userofficemobile = localStorage.getItem('officemobile');
            if(this.userofficemobile == 0 || this.userofficemobile == "null"){
                this.userofficemobile = '';
            }else{
                this.userofficemobile = localStorage.getItem('officemobile');
            }

            this.usershift = localStorage.getItem('shift');
            if(this.usershift == 0 || this.usershift == "null"){
                this.usershift = '';
            }else{
                this.usershift = localStorage.getItem('shift');
            }

            this.userbranch = localStorage.getItem('branch');
            if(this.userbranch == 0 || this.userbranch == "null"){
                this.userbranch = '';
            }else{
                this.userbranch = localStorage.getItem('branch');
            }

    }
    editbio(){
        window.open("#/pages/bioforms");
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

    

}
