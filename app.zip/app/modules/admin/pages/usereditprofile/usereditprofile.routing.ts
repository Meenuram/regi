import { Route } from '@angular/router';
import { UsereditprofileComponent } from 'app/modules/admin/pages/usereditprofile/usereditprofile.component';

export const usereditprofileRoutes: Route[] = [
    {
        path     : '',
        component: UsereditprofileComponent
    }
];
